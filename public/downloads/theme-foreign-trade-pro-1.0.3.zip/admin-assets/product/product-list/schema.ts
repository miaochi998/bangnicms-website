/**
 * fttp 产品列表页 PanelSchemaV1 schema（阶段 2 节点 C · C-D3）
 * -----------------------------------------------------------------------------
 * 接管自原 ProductListPageConfigForm.tsx（1462 行手写）。
 *
 * Storage 形态（config.productListPage · 见 shared-types
 * `BangNiCmsThemeProductListPageConfig`）：
 *   {
 *     enabled,
 *     header: { enabled, background, title:LT, subtitle:LT,
 *               stats[]: { id, mode:'auto'|'manual', value?:str, label:LT } },
 *     quickChips: { enabled, label:LT,
 *                   fixed[]: { id, kind:'all'|'newest'|'featured', enabled, label:LT },
 *                   badges: { enabled, placement, maxCount, minOccurrence },
 *                   countLabelTemplate:LT },
 *     leftSidebar: { enabled, search/activeFilters/categoryFilter/capabilityFilter
 *                    /customSourcingCard 五段 nested object },
 *     toolbar: { enabled, resultLabelTemplate:LT,
 *                sortOptions[]:{id, enabled, label:LT}, defaultSort:select },
 *     featuredBanner: { enabled, background, title/subtitle/ctaLabel:LT, ctaHref,
 *                       leftImage:str(URL), rightImage:str(URL) },
 *     productCard: { columnsDesktop/Tablet/Mobile:number,
 *                    showBadge/CategoryTag/Capabilities/InquiryCta:bool,
 *                    inquiryCtaLabel/noCoverLabel/videoBadgeLabel:LT },
 *     pagination: { enabled, pageSizeOptions:number[], defaultPageSize,
 *                   showPageSizeSwitcher, pageLabelTemplate:LT, pageSizeLabel:LT },
 *     empty: { title/description/clearFiltersLabel:LT },
 *     subcategoryNav: { enabled, title:LT, showCount },
 *   }
 *
 * 形态特点：LocalizedText 全部是 `{ translations: { lang:str } }` 形态
 *   - 由 createFttpStorageAdapter default `read/write` 路径下 styled-localized-text
 *     双向 wrap/unwrap（schema 端用标准 localizedText{multiLang:true}）
 *
 * helper / 原语首实战登记（schema.ts 头注 + 完工汇报 §X）：
 *   - **tagInput 首实战**：`pagination.pageSizeOptions` 原 storage 是 `number[]`
 *     （如 [12, 24, 48]）。schema 用 `tagInput`（仅支持 string[]），adapter 双向
 *     `number[] ↔ string[]` 强转（同 news-list grid.perPage select number/string 转换模式）。
 *   - **categorySelector 不复用**：product-list 形态无运营手选分类需求
 *     （leftSidebar.categoryFilter 仅 UI 元数据 maxCount/minOccurrence 等，前台
 *     按聚合自动列出全部分类），与启动指令档预期不符 · 节点 C 完工汇报登记
 *     · 评估推迟到后续主题 / 节点 D 总收尾。
 *   - **createCtaLinkObjectField 不复用**：customSourcingCard.ctaHref /
 *     featuredBanner.ctaHref 全是裸 string，无 9 类 type 选择。
 *
 * adapter 行为（fttp.product-list-page · pre/postprocessProductListPageWrite）：
 *   - preprocessRead: pagination.pageSizeOptions: number[] → string[]
 *   - postprocessWrite: pagination.pageSizeOptions: string[] → number[]
 *                       · 3 ListField items[].id 兜底（stats/fixed/sortOptions）
 *                       · featuredBanner.leftImage/rightImage mediaPicker 字段级
 *                         {url} → string 降级（沿用 fttp.factory pattern）
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

const ITEM_ID_FIELD = {
  fieldKey: 'id',
  type: 'text',
  label: 'ID（系统生成 · 请勿修改）',
  placeholder: '保存时自动补齐',
  span: 'narrow',
} as const;

const STAT_MODE_OPTIONS = [
  { value: 'auto', label: 'Auto（前台自动计算）' },
  { value: 'manual', label: 'Manual（手填值）' },
];

const QUICK_CHIP_KIND_OPTIONS = [
  { value: 'all', label: '全部（all）' },
  { value: 'newest', label: '新品（newest）' },
  { value: 'featured', label: '热销（featured）' },
];

const SORT_OPTION_ID_OPTIONS = [
  { value: 'newest', label: '最新优先（newest）' },
  { value: 'oldest', label: '最早发布（oldest）' },
  { value: 'manual', label: '手动排序（manual）' },
];

const PLACEMENT_OPTIONS = [
  { value: 'after-fixed', label: '在固定 chip 后' },
  { value: 'before-fixed', label: '在固定 chip 前' },
];

export const PRODUCT_LIST_PAGE_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.product-list-page',
  version: 1,
  title: '产品列表页 · 配置',
  configPath: 'config.productListPage',
  tabs: [
    {
      tabKey: 'header',
      title: '页头',
      sections: [
        {
          sectionKey: 'master',
          title: '总开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用产品列表页自定义配置',
              defaultValue: true,
              controlsChildren: true,
              span: 'narrow',
            },
          ],
        },
        {
          sectionKey: 'header',
          title: '顶部深色横幅（含统计 3 项）',
          fields: [
            {
              fieldKey: 'header',
              type: 'object',
              label: '页头',
              span: 'full',
              fields: [
                { fieldKey: 'enabled', type: 'switch', label: '启用页头', defaultValue: true, span: 'narrow' },
                { fieldKey: 'background', type: 'color', label: '背景色', span: 'narrow' },
                { fieldKey: 'title', type: 'localizedText', label: '主标题', multiLang: true, span: 'wide' },
                {
                  fieldKey: 'subtitle',
                  type: 'localizedText',
                  label: '副标题（支持 {totalProducts} {totalCategories} {markets} 占位符）',
                  multiLang: true,
                  multiline: true,
                  span: 'full',
                },
                {
                  fieldKey: 'stats',
                  type: 'arrayOfObject',
                  label: '统计项（建议 3 项 · auto 模式由前台自动计算）',
                  minItems: 0,
                  maxItems: 6,
                  itemTitleField: 'label',
                  addLabel: '添加统计项',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      ITEM_ID_FIELD,
                      {
                        fieldKey: 'mode',
                        type: 'select',
                        label: '模式',
                        defaultValue: 'auto',
                        options: STAT_MODE_OPTIONS,
                        span: 'narrow',
                      },
                      {
                        fieldKey: 'value',
                        type: 'text',
                        label: '数值（仅 manual 模式 · 单语 · 如「60+」）',
                        span: 'narrow',
                      },
                      { fieldKey: 'label', type: 'localizedText', label: '说明文字', multiLang: true, span: 'wide' },
                    ],
                  },
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'quickChips',
      title: '快速筛选',
      sections: [
        {
          sectionKey: 'quickChips',
          title: '粘性快速筛选条',
          fields: [
            {
              fieldKey: 'quickChips',
              type: 'object',
              label: '快速筛选',
              span: 'full',
              fields: [
                { fieldKey: 'enabled', type: 'switch', label: '启用快速筛选', defaultValue: true, span: 'narrow' },
                { fieldKey: 'label', type: 'localizedText', label: '前缀文案（如「快速筛选：」）', multiLang: true, span: 'wide' },
                {
                  fieldKey: 'fixed',
                  type: 'arrayOfObject',
                  label: '固定 chip（建议 3 项 · all/newest/featured）',
                  minItems: 0,
                  maxItems: 6,
                  itemTitleField: 'label',
                  addLabel: '添加固定 chip',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      ITEM_ID_FIELD,
                      {
                        fieldKey: 'kind',
                        type: 'select',
                        label: '类型',
                        defaultValue: 'all',
                        options: QUICK_CHIP_KIND_OPTIONS,
                        span: 'narrow',
                      },
                      { fieldKey: 'enabled', type: 'switch', label: '启用此项', defaultValue: true, span: 'narrow' },
                      { fieldKey: 'label', type: 'localizedText', label: '显示文案', multiLang: true, span: 'wide' },
                    ],
                  },
                },
                {
                  fieldKey: 'badges',
                  type: 'object',
                  label: '动态徽章 chip（按出现频率自动从产品标签中提取）',
                  span: 'full',
                  fields: [
                    { fieldKey: 'enabled', type: 'switch', label: '启用动态徽章', defaultValue: true, span: 'narrow' },
                    {
                      fieldKey: 'placement',
                      type: 'select',
                      label: '位置',
                      defaultValue: 'after-fixed',
                      options: PLACEMENT_OPTIONS,
                      span: 'narrow',
                    },
                    { fieldKey: 'maxCount', type: 'number', label: '显示数量上限', min: 0, max: 30, step: 1, span: 'narrow' },
                    { fieldKey: 'minOccurrence', type: 'number', label: '最少出现次数门槛', min: 1, max: 20, step: 1, span: 'narrow' },
                  ],
                },
                {
                  fieldKey: 'countLabelTemplate',
                  type: 'localizedText',
                  label: '结果计数模板（支持 {total} {start} {end} 占位符）',
                  multiLang: true,
                  span: 'wide',
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'leftSidebar',
      title: '左侧筛选栏',
      sections: [
        {
          sectionKey: 'leftSidebar',
          title: '左侧筛选栏（搜索 / 当前筛选 / 分类 / 能力 / 定制搜源卡）',
          fields: [
            {
              fieldKey: 'leftSidebar',
              type: 'object',
              label: '左侧筛选栏',
              span: 'full',
              fields: [
                { fieldKey: 'enabled', type: 'switch', label: '启用左侧筛选栏', defaultValue: true, span: 'narrow' },
                {
                  fieldKey: 'search',
                  type: 'object',
                  label: '搜索框',
                  span: 'full',
                  fields: [
                    { fieldKey: 'enabled', type: 'switch', label: '启用', defaultValue: true, span: 'narrow' },
                    { fieldKey: 'placeholder', type: 'localizedText', label: '占位符', multiLang: true, span: 'wide' },
                  ],
                },
                {
                  fieldKey: 'activeFilters',
                  type: 'object',
                  label: '当前筛选',
                  span: 'full',
                  fields: [
                    { fieldKey: 'enabled', type: 'switch', label: '启用', defaultValue: true, span: 'narrow' },
                    { fieldKey: 'title', type: 'localizedText', label: '区标题', multiLang: true, span: 'wide' },
                    { fieldKey: 'clearAllLabel', type: 'localizedText', label: '清除全部按钮', multiLang: true, span: 'wide' },
                  ],
                },
                {
                  fieldKey: 'categoryFilter',
                  type: 'object',
                  label: '分类筛选',
                  span: 'full',
                  fields: [
                    { fieldKey: 'enabled', type: 'switch', label: '启用', defaultValue: true, span: 'narrow' },
                    { fieldKey: 'title', type: 'localizedText', label: '区标题', multiLang: true, span: 'wide' },
                    { fieldKey: 'defaultExpanded', type: 'switch', label: '默认展开', defaultValue: true, span: 'narrow' },
                    { fieldKey: 'showCount', type: 'switch', label: '显示每分类产品计数', defaultValue: true, span: 'narrow' },
                    { fieldKey: 'maxVisibleBeforeCollapse', type: 'number', label: '折叠前最大显示数', min: 1, max: 30, step: 1, span: 'narrow' },
                  ],
                },
                {
                  fieldKey: 'capabilityFilter',
                  type: 'object',
                  label: '能力筛选',
                  span: 'full',
                  fields: [
                    { fieldKey: 'enabled', type: 'switch', label: '启用', defaultValue: true, span: 'narrow' },
                    { fieldKey: 'title', type: 'localizedText', label: '区标题', multiLang: true, span: 'wide' },
                    { fieldKey: 'maxCount', type: 'number', label: '显示数量上限', min: 0, max: 30, step: 1, span: 'narrow' },
                    { fieldKey: 'minOccurrence', type: 'number', label: '最少出现次数门槛', min: 1, max: 20, step: 1, span: 'narrow' },
                    { fieldKey: 'defaultExpanded', type: 'switch', label: '默认展开', defaultValue: true, span: 'narrow' },
                    { fieldKey: 'showCount', type: 'switch', label: '显示出现次数', defaultValue: true, span: 'narrow' },
                  ],
                },
                {
                  fieldKey: 'customSourcingCard',
                  type: 'object',
                  label: '"定制搜源" 推广卡',
                  span: 'full',
                  fields: [
                    { fieldKey: 'enabled', type: 'switch', label: '启用', defaultValue: true, span: 'narrow' },
                    { fieldKey: 'title', type: 'localizedText', label: '标题', multiLang: true, span: 'wide' },
                    { fieldKey: 'description', type: 'localizedText', label: '描述', multiLang: true, multiline: true, span: 'full' },
                    { fieldKey: 'ctaLabel', type: 'localizedText', label: 'CTA 按钮文案', multiLang: true, span: 'wide' },
                    { fieldKey: 'ctaHref', type: 'text', label: 'CTA 链接（如 #inquiry）', placeholder: '#inquiry', span: 'wide' },
                  ],
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'toolbar',
      title: '工具栏',
      sections: [
        {
          sectionKey: 'toolbar',
          title: '工具栏（结果计数 + 排序）',
          fields: [
            {
              fieldKey: 'toolbar',
              type: 'object',
              label: '工具栏',
              span: 'full',
              fields: [
                { fieldKey: 'enabled', type: 'switch', label: '启用工具栏', defaultValue: true, span: 'narrow' },
                {
                  fieldKey: 'resultLabelTemplate',
                  type: 'localizedText',
                  label: '结果计数模板（支持 {appliedCount} {total} {start} {end}）',
                  multiLang: true,
                  span: 'wide',
                },
                {
                  fieldKey: 'sortOptions',
                  type: 'arrayOfObject',
                  label: '排序选项（建议 3 项 · newest/oldest/manual）',
                  minItems: 0,
                  maxItems: 6,
                  itemTitleField: 'label',
                  addLabel: '添加排序选项',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      {
                        fieldKey: 'id',
                        type: 'select',
                        label: 'ID（固定 3 值之一）',
                        defaultValue: 'newest',
                        options: SORT_OPTION_ID_OPTIONS,
                        span: 'narrow',
                      },
                      { fieldKey: 'enabled', type: 'switch', label: '启用此项', defaultValue: true, span: 'narrow' },
                      { fieldKey: 'label', type: 'localizedText', label: '显示文案', multiLang: true, span: 'wide' },
                    ],
                  },
                },
                {
                  fieldKey: 'defaultSort',
                  type: 'select',
                  label: '默认排序',
                  defaultValue: 'manual',
                  options: SORT_OPTION_ID_OPTIONS,
                  span: 'narrow',
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'featuredBanner',
      title: '推广横幅',
      sections: [
        {
          sectionKey: 'featuredBanner',
          title: '推广横幅（双图左右 + 中央文案）',
          fields: [
            {
              fieldKey: 'featuredBanner',
              type: 'object',
              label: '推广横幅',
              span: 'full',
              fields: [
                { fieldKey: 'enabled', type: 'switch', label: '启用推广横幅', defaultValue: true, span: 'narrow' },
                { fieldKey: 'background', type: 'color', label: '背景色', span: 'narrow' },
                { fieldKey: 'title', type: 'localizedText', label: '主标题', multiLang: true, span: 'wide' },
                { fieldKey: 'subtitle', type: 'localizedText', label: '副标题', multiLang: true, multiline: true, span: 'full' },
                { fieldKey: 'ctaLabel', type: 'localizedText', label: 'CTA 按钮文案', multiLang: true, span: 'wide' },
                { fieldKey: 'ctaHref', type: 'text', label: 'CTA 链接', placeholder: '/products?featured=1', span: 'wide' },
                { fieldKey: 'leftImage', type: 'mediaPicker', label: '左侧图片', accept: ['image'], span: 'wide' },
                { fieldKey: 'rightImage', type: 'mediaPicker', label: '右侧图片', accept: ['image'], span: 'wide' },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'productCard',
      title: '产品卡 & 空态',
      sections: [
        {
          sectionKey: 'productCard',
          title: '产品卡',
          fields: [
            {
              fieldKey: 'productCard',
              type: 'object',
              label: '产品卡',
              span: 'full',
              fields: [
                { fieldKey: 'columnsDesktop', type: 'number', label: '桌面端列数', min: 1, max: 6, step: 1, span: 'narrow' },
                { fieldKey: 'columnsTablet', type: 'number', label: '平板列数', min: 1, max: 4, step: 1, span: 'narrow' },
                { fieldKey: 'columnsMobile', type: 'number', label: '手机列数', min: 1, max: 2, step: 1, span: 'narrow' },
                { fieldKey: 'showBadge', type: 'switch', label: '显示徽章', defaultValue: true, span: 'narrow' },
                { fieldKey: 'showCategoryTag', type: 'switch', label: '显示分类标签', defaultValue: true, span: 'narrow' },
                { fieldKey: 'showCapabilities', type: 'switch', label: '显示能力标签', defaultValue: true, span: 'narrow' },
                { fieldKey: 'showInquiryCta', type: 'switch', label: '显示询价按钮', defaultValue: true, span: 'narrow' },
                { fieldKey: 'inquiryCtaLabel', type: 'localizedText', label: '询价按钮文案', multiLang: true, span: 'wide' },
                { fieldKey: 'noCoverLabel', type: 'localizedText', label: '无封面占位文案', multiLang: true, span: 'medium' },
                { fieldKey: 'videoBadgeLabel', type: 'localizedText', label: '视频徽章文案', multiLang: true, span: 'medium' },
              ],
            },
          ],
        },
        {
          sectionKey: 'empty',
          title: '空态',
          fields: [
            {
              fieldKey: 'empty',
              type: 'object',
              label: '空态文案',
              span: 'full',
              fields: [
                { fieldKey: 'title', type: 'localizedText', label: '标题', multiLang: true, span: 'wide' },
                { fieldKey: 'description', type: 'localizedText', label: '描述', multiLang: true, multiline: true, span: 'full' },
                { fieldKey: 'clearFiltersLabel', type: 'localizedText', label: '清除筛选按钮文案', multiLang: true, span: 'wide' },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'pagination',
      title: '分页 & 子分类',
      sections: [
        {
          sectionKey: 'pagination',
          title: '分页（pageSizeOptions 是 tagInput 首实战字段）',
          description:
            'pageSizeOptions 输入数字字符串后回车添加（如 "12" / "24" / "48"），存储时强转 number[]。',
          fields: [
            {
              fieldKey: 'pagination',
              type: 'object',
              label: '分页',
              span: 'full',
              fields: [
                { fieldKey: 'enabled', type: 'switch', label: '启用分页', defaultValue: true, span: 'narrow' },
                {
                  fieldKey: 'pageSizeOptions',
                  type: 'tagInput',
                  label: '每页可选数量（仅纯数字 · 回车添加 · 最多 6 项）',
                  inputPlaceholder: '输入数字后回车（如 12 / 24 / 48）',
                  maxItems: 6,
                },
                { fieldKey: 'defaultPageSize', type: 'number', label: '默认每页数量', min: 1, max: 200, step: 1, span: 'narrow' },
                { fieldKey: 'showPageSizeSwitcher', type: 'switch', label: '允许买家切换每页数量', defaultValue: true, span: 'narrow' },
                { fieldKey: 'pageLabelTemplate', type: 'localizedText', label: '页码模板（支持 {current} {total} {count}）', multiLang: true, span: 'wide' },
                { fieldKey: 'pageSizeLabel', type: 'localizedText', label: '每页显示文案', multiLang: true, span: 'wide' },
              ],
            },
          ],
        },
        {
          sectionKey: 'subcategoryNav',
          title: '子分类导航',
          fields: [
            {
              fieldKey: 'subcategoryNav',
              type: 'object',
              label: '子分类导航',
              span: 'full',
              fields: [
                { fieldKey: 'enabled', type: 'switch', label: '启用', defaultValue: true, span: 'narrow' },
                { fieldKey: 'title', type: 'localizedText', label: '标题', multiLang: true, span: 'wide' },
                { fieldKey: 'showCount', type: 'switch', label: '显示子孙产品计数', defaultValue: true, span: 'narrow' },
              ],
            },
          ],
        },
      ],
    },
  ],
};
