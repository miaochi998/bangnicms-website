/**
 * fttp 首页精选产品 PanelSchemaV1 schema（节点 C commit-1b-β · S2.3）
 * -----------------------------------------------------------------------------
 * 接管自原 FeaturedProductsConfigForm.tsx。fttp storage 形态 per-lang 反向
 * 嵌套 `translations: { [lang]: { sectionTag, ... } }` 由 fttp-storage-adapter
 * 的 preprocessRead/postprocessWrite 拍平/归并。
 *
 * 已知节点 C 退化（节点 D 入账 / 阶段 2 处理）：
 *   - 3 段 textStyle（sectionTag/sectionTitle/sectionDescription）不在新渲染器
 *     内可见可编辑（PanelSchemaV1 暂无 textStyle 原语），通过 prev merge 透传
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

export const FEATURED_PRODUCTS_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.featured-products',
  version: 1,
  previewAdapter: 'fttp.featured-products',
  title: '首页精选产品',
  configPath: 'config.featuredProducts',
  tabs: [
    {
      tabKey: 'text',
      title: '文案',
      sections: [
        {
          sectionKey: 'master',
          title: '整块开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用首页精选产品',
              defaultValue: true,
              controlsChildren: true,
              span: 'full',
            },
          ],
        },
        {
          sectionKey: 'copy',
          title: '区块文案',
          description: '5 个文本字段三语编辑（顶部小标 / 主标题 / 描述 / 查看全部 / CTA）',
          fields: [
            {
              fieldKey: 'sectionTag',
              type: 'localizedText',
              label: '顶部小标（sectionTag）',
              multiLang: true,
              placeholder: '精选产品',
              span: 'wide',
            },
            {
              fieldKey: 'sectionTitle',
              type: 'localizedText',
              label: '主标题 H2（sectionTitle）',
              multiLang: true,
              required: true,
              placeholder: '全球采购经理的首选爆款',
              span: 'wide',
            },
            {
              fieldKey: 'sectionDescription',
              type: 'localizedText',
              label: '描述段（sectionDescription）',
              multiLang: true,
              placeholder: '从 3000+ 在销品类中精选 ...',
              span: 'full',
            },
            {
              fieldKey: 'viewAllLabel',
              type: 'localizedText',
              label: '“查看全部”按钮文案（viewAllLabel）',
              multiLang: true,
              placeholder: '查看全部产品',
              span: 'wide',
            },
            {
              fieldKey: 'inquiryCtaLabel',
              type: 'localizedText',
              label: '卡片底部询盘 CTA（inquiryCtaLabel）',
              multiLang: true,
              placeholder: '获取报价 / 发起询盘',
              span: 'wide',
            },
          ],
        },
      ],
    },
    {
      tabKey: 'layout',
      title: '布局',
      sections: [
        {
          sectionKey: 'layout',
          title: '布局与展示',
          fields: [
            {
              fieldKey: 'layout',
              type: 'object',
              label: '布局',
              span: 'full',
              fields: [
                {
                  fieldKey: 'maxItems',
                  type: 'number',
                  label: '最大展示数',
                  min: 1,
                  max: 24,
                  step: 1,
                  defaultValue: 8,
                  span: 'narrow',
                },
                {
                  fieldKey: 'columnsDesktop',
                  type: 'number',
                  label: '桌面列数（2/3/4）',
                  min: 2,
                  max: 4,
                  step: 1,
                  defaultValue: 4,
                  span: 'narrow',
                },
                {
                  fieldKey: 'columnsTablet',
                  type: 'number',
                  label: '平板列数（2/3）',
                  min: 2,
                  max: 3,
                  step: 1,
                  defaultValue: 3,
                  span: 'narrow',
                },
                {
                  fieldKey: 'columnsMobile',
                  type: 'number',
                  label: '手机列数（1/2）',
                  min: 1,
                  max: 2,
                  step: 1,
                  defaultValue: 2,
                  span: 'narrow',
                },
                {
                  fieldKey: 'showViewAllLink',
                  type: 'switch',
                  label: '显示“查看全部”链接',
                  defaultValue: true,
                  span: 'narrow',
                },
                {
                  fieldKey: 'viewAllHref',
                  type: 'text',
                  label: '链接目标（viewAllHref）',
                  placeholder: '/products',
                  defaultValue: '/products',
                  span: 'wide',
                },
                {
                  fieldKey: 'showBadge',
                  type: 'switch',
                  label: '显示徽章',
                  defaultValue: true,
                  span: 'medium',
                },
                {
                  fieldKey: 'showCapabilities',
                  type: 'switch',
                  label: '显示能力标签',
                  defaultValue: true,
                  span: 'medium',
                },
                {
                  fieldKey: 'showInquiryCta',
                  type: 'switch',
                  label: '显示询盘 CTA',
                  defaultValue: true,
                  span: 'medium',
                },
              ],
            },
          ],
        },
      ],
    },
  ],
};
