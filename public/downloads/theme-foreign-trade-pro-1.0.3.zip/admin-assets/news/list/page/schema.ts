/**
 * fttp 新闻列表页 PanelSchemaV1 schema（阶段 2 节点 B · B-D3）
 * -----------------------------------------------------------------------------
 * 接管自原 NewsListPageConfigForm.tsx（740 行手写）。
 *
 * Storage 形态（config.newsListPage · 与 themes/.../NewsListPage.tsx 对齐）：
 *   {
 *     enabled,
 *     hero: { eyebrow, title, description, breadcrumbHome, breadcrumbCurrent } 5 LT,
 *     filter: { allLabel, searchPlaceholder, sortLabel, sortNewestLabel,
 *               sortOldestLabel, sortAlphaLabel } 6 LT,
 *     grid: { perPage:number, readMoreLabel, noCoverLabel,
 *             noMatch:{title, resetLabel}, prevLabel, nextLabel },
 *     sidebar: { enabled, popularTagsLabel, popularTagsSource:'categories'|'custom',
 *                popularTagsCustom: LocalizedText[],  // ← adapter 双向转换
 *                popularTagsLimit:number, recentLabel, recentLimit:number },
 *     empty: { title, description },
 *   }
 *
 * 启动指令档预期 categorySelector + tagInput 首场实战 → 实测发现 schema 不匹配：
 *   - 文章分类按钮由系统按已发布文章动态聚合，无 categorySelector 用例
 *   - popularTagsCustom 是 LocalizedText[] 多语言数组，非 string[]，不适合 tagInput
 * 节点 B 完工汇报 §X 登记此发现 · helper 复用度按实际 schema 评估。
 *
 * popularTagsCustom 通过 createFttpStorageAdapter('fttp.news-list-page') 双向 wrap：
 *   read:  storage `[lt0, lt1]` → render `[{id, value: lt0}, ...]`
 *   write: render `[{id, value: lt0}, ...]` → storage `[lt0, lt1]`
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

const ITEM_ID_FIELD = {
  fieldKey: 'id',
  type: 'text',
  label: 'ID（系统生成）',
  placeholder: '保存时自动补齐',
  span: 'narrow',
} as const;

export const NEWS_LIST_PAGE_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.news-list-page',
  version: 1,
  title: '新闻列表页',
  configPath: 'config.newsListPage',
  tabs: [
    {
      tabKey: 'hero',
      title: 'Hero 页头',
      sections: [
        {
          sectionKey: 'master',
          title: '总开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用新闻列表页',
              description: '关闭后前台 /news 渲染为空。',
              defaultValue: true,
              controlsChildren: true,
              span: 'narrow',
            },
          ],
        },
        {
          sectionKey: 'hero',
          title: 'Hero 头部文案',
          description: '访问 /news 时顶部深色横幅显示的内容。',
          fields: [
            {
              fieldKey: 'hero',
              type: 'object',
              label: 'Hero',
              span: 'full',
              fields: [
                { fieldKey: 'eyebrow', type: 'localizedText', label: '小标题（顶部高亮短句）', multiLang: true, span: 'wide' },
                { fieldKey: 'title', type: 'localizedText', label: '主标题', multiLang: true, span: 'wide' },
                { fieldKey: 'description', type: 'localizedText', label: '描述', multiLang: true, multiline: true, span: 'full' },
                { fieldKey: 'breadcrumbHome', type: 'localizedText', label: '面包屑「首页」文案', multiLang: true, span: 'wide' },
                { fieldKey: 'breadcrumbCurrent', type: 'localizedText', label: '面包屑「新闻」文案', multiLang: true, span: 'wide' },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'filter',
      title: '分类筛选 & 排序',
      sections: [
        {
          sectionKey: 'filter',
          title: '筛选 + 排序文案',
          description: '文章分类按钮由系统根据已发布文章自动生成，无需配置。',
          fields: [
            {
              fieldKey: 'filter',
              type: 'object',
              label: '筛选 + 排序',
              span: 'full',
              fields: [
                { fieldKey: 'allLabel', type: 'localizedText', label: '"全部" 按钮文案', multiLang: true, span: 'wide' },
                { fieldKey: 'searchPlaceholder', type: 'localizedText', label: '搜索框提示语', multiLang: true, span: 'wide' },
                { fieldKey: 'sortLabel', type: 'localizedText', label: '"排序：" 前缀文字', multiLang: true, span: 'wide' },
                { fieldKey: 'sortNewestLabel', type: 'localizedText', label: '排序选项 · 最新发布', multiLang: true, span: 'wide' },
                { fieldKey: 'sortOldestLabel', type: 'localizedText', label: '排序选项 · 最早发布', multiLang: true, span: 'wide' },
                { fieldKey: 'sortAlphaLabel', type: 'localizedText', label: '排序选项 · 按标题（A-Z）', multiLang: true, span: 'wide' },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'grid',
      title: '主网格 & 分页',
      sections: [
        {
          sectionKey: 'grid',
          title: '主网格 + 分页文案',
          fields: [
            {
              fieldKey: 'grid',
              type: 'object',
              label: '主网格 + 分页',
              span: 'full',
              fields: [
                {
                  fieldKey: 'perPage',
                  type: 'select',
                  label: '每页文章数',
                  defaultValue: '10',
                  options: [
                    { value: '10', label: '10 条' },
                    { value: '20', label: '20 条' },
                    { value: '50', label: '50 条' },
                  ],
                  span: 'narrow',
                },
                { fieldKey: 'readMoreLabel', type: 'localizedText', label: '"继续阅读" 按钮文案', multiLang: true, span: 'wide' },
                { fieldKey: 'noCoverLabel', type: 'localizedText', label: '无封面占位文案', multiLang: true, span: 'wide' },
                {
                  fieldKey: 'noMatch',
                  type: 'object',
                  label: '搜索 / 筛选无匹配',
                  span: 'full',
                  fields: [
                    { fieldKey: 'title', type: 'localizedText', label: '无匹配 · 标题', multiLang: true, span: 'wide' },
                    { fieldKey: 'resetLabel', type: 'localizedText', label: '"重置筛选" 按钮文案', multiLang: true, span: 'wide' },
                  ],
                },
                { fieldKey: 'prevLabel', type: 'localizedText', label: '"上一页" 按钮文案', multiLang: true, span: 'wide' },
                { fieldKey: 'nextLabel', type: 'localizedText', label: '"下一页" 按钮文案', multiLang: true, span: 'wide' },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'sidebar',
      title: '侧栏 & 空态',
      sections: [
        {
          sectionKey: 'sidebar',
          title: '侧栏配置',
          fields: [
            {
              fieldKey: 'sidebar',
              type: 'object',
              label: '侧栏',
              span: 'full',
              fields: [
                { fieldKey: 'enabled', type: 'switch', label: '显示侧栏', defaultValue: true, span: 'wide' },
                { fieldKey: 'popularTagsLabel', type: 'localizedText', label: '"热门标签" 标题', multiLang: true, span: 'wide' },
                {
                  fieldKey: 'popularTagsSource',
                  type: 'select',
                  label: '热门标签来源',
                  defaultValue: 'categories',
                  options: [
                    { value: 'categories', label: '来自文章分类（自动）' },
                    { value: 'custom', label: '自定义（手填）' },
                  ],
                  span: 'wide',
                },
                {
                  fieldKey: 'popularTagsCustom',
                  type: 'arrayOfObject',
                  label: '自定义标签列表（多语言 · 仅 popularTagsSource=custom 时使用）',
                  description: '每项为多语言文本；adapter 双向转换为 storage 裸 LocalizedText[]。',
                  minItems: 0,
                  maxItems: 50,
                  itemTitleField: 'value',
                  addLabel: '新增标签',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      ITEM_ID_FIELD,
                      { fieldKey: 'value', type: 'localizedText', label: '标签文字（多语言）', multiLang: true, span: 'wide' },
                    ],
                  },
                },
                {
                  fieldKey: 'popularTagsLimit',
                  type: 'number',
                  label: '最多显示标签数（仅 popularTagsSource=categories 时使用）',
                  defaultValue: 12,
                  min: 1,
                  max: 50,
                  span: 'narrow',
                },
                { fieldKey: 'recentLabel', type: 'localizedText', label: '"最新文章" 标题', multiLang: true, span: 'wide' },
                {
                  fieldKey: 'recentLimit',
                  type: 'number',
                  label: '最多显示最新文章数',
                  defaultValue: 4,
                  min: 1,
                  max: 50,
                  span: 'narrow',
                },
              ],
            },
          ],
        },
        {
          sectionKey: 'empty',
          title: '空态（暂无文章时）',
          fields: [
            {
              fieldKey: 'empty',
              type: 'object',
              label: '空态文案',
              span: 'full',
              fields: [
                { fieldKey: 'title', type: 'localizedText', label: '标题', multiLang: true, span: 'wide' },
                { fieldKey: 'description', type: 'localizedText', label: '描述', multiLang: true, multiline: true, span: 'full' },
              ],
            },
          ],
        },
      ],
    },
  ],
};
