'use client';

/**
 * TermsPagePanelClient · 节点 A D-A1（S2.4）
 * -----------------------------------------------------------------------------
 * 与 PrivacyPagePanelClient 同构，仅 panelKey / configPath / title 不同。
 * 复用 createLegalPagePanel 工厂 + createFttpStorageAdapter（terms-page 分支）。
 */

import { PanelRenderer } from '@/components/panel-renderer';
import { createFttpStorageAdapter } from '@bangnicms-theme/foreign-trade-pro/admin-assets/_storage-adapter';
import { createLegalPagePanel } from '../../privacy/page/schema';

const TERMS_PAGE_PANEL = createLegalPagePanel({
  panelKey: 'fttp.terms-page',
  configPath: 'config.termsPage',
  title: '服务条款页',
});

interface LangOption {
  code: string;
  name: string;
}

export function TermsPagePanelClient({
  apiBase,
  extensionId,
  themeKey,
  themeName,
  initialData,
  languages,
  defaultLang,
  aiAvailable,
}: {
  apiBase: string;
  extensionId: string;
  themeKey: string;
  themeName: string;
  initialData: Record<string, unknown> | undefined;
  languages: LangOption[];
  defaultLang: string;
  aiAvailable: boolean;
}) {
  return (
    <PanelRenderer
      apiBase={apiBase}
      extensionId={extensionId}
      themeKey={themeKey}
      themeName={themeName}
      panel={TERMS_PAGE_PANEL}
      initialData={initialData}
      languages={languages}
      defaultLang={defaultLang}
      aiAvailable={aiAvailable}
      dataAdapter={createFttpStorageAdapter(TERMS_PAGE_PANEL.panelKey)}
    />
  );
}
