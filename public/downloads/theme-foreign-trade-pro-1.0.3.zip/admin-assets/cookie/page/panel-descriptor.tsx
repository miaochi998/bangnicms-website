import { Cookie } from 'lucide-react';
import type { PanelDescriptor } from '../../_types';
import { iconHint } from '../../_helpers';
import { CookiePagePanelClient } from './CookiePagePanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'cookie/page',
  configKey: 'cookiePage',
  title: 'Cookie 政策页',
  description: '配置 /cookie 法律页：Hero 页头 + 文件信息卡 + 异构正文 sections + TOC + 底部联系 + 相关法律文件卡。所有文案多语言。',
  dataPage: 'theme-config-fttp-cookie-page',
  notApplicableTestId: 'cookie-page-not-applicable',
  guardMode: 'theme-key',
  PanelClient: CookiePagePanelClient,
  hint: iconHint(
    <Cookie className="h-4 w-4 shrink-0 mt-0.5" />,
    <>
      <p>
        <strong>提示</strong>：Cookie 政策 8 节默认覆盖「定义/类别/具体清单/第三方/管理/影响/更新/联系」。第三章节「具体使用的 Cookie 清单」为 4 列表格（名称/提供方/用途/有效期），运营每季度更新。
      </p>
      <p className="mt-1">
        段落文本支持简单内联标签{' '}
        <code className="px-1 py-0.5 rounded bg-muted text-foreground">&lt;b&gt;</code>{' '}
        <code className="px-1 py-0.5 rounded bg-muted text-foreground">&lt;a href&gt;</code>{' '}
        <code className="px-1 py-0.5 rounded bg-muted text-foreground">&lt;br/&gt;</code>。表格 cell 同样支持。
      </p>
      <p className="mt-1">
        若关闭「启用」开关，前台{' '}
        <code className="px-1 py-0.5 rounded bg-muted text-foreground">/cookie</code> 将渲染为空。
      </p>
    </>,
  ),
};
