import type { PanelDescriptor } from '../../_types';
import { CertificationsPanelClient } from './CertificationsPanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'homepage/certifications',
  configKey: 'certifications',
  title: '首页 · 资质认证 / 服务承诺',
  description: '配置首页「资质认证 / 服务承诺」区块：标题 / 描述 / 资质证书网格 / 行动按钮。',
  dataPage: 'theme-config-fttp-certifications',
  notApplicableTestId: 'certifications-not-applicable',
  guardMode: 'theme-key',
  PanelClient: CertificationsPanelClient,
};
