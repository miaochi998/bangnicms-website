/**
 * fttp 产品详情页 PanelSchemaV1 schema（阶段 2 节点 C · C-D7）
 * -----------------------------------------------------------------------------
 * 接管自原 ProductDetailPageConfigForm.tsx（502 行手写）。
 *
 * Storage 形态（config.productDetailPage）：纯 LocalizedText 9 段 nested object：
 *   {
 *     enabled,
 *     breadcrumb: { homeLabel/productsLabel: LT × 2 },
 *     cta: { inquireLabel/addToCartLabel/addedToCartLabel/shareLabel: LT × 4 },
 *     bottomCta: { eyebrow/titleTemplate/description/certificateNote
 *                  /submitInquiryLabel/addToCartLabel: LT × 6 },
 *     tabs: { description/specs/packaging/certifications/faqLabel: LT × 5 },
 *     sectionTitles: { fullSpecs/packagingDetails/shippingLogistics
 *                      /certifications/faqHeading/relatedProducts/relatedEyebrow: LT × 7 },
 *     emptyStates: { noGallery/noSpecs/noPackaging/noCertifications/noFaq: LT × 5 },
 *     certifications: { requestCertLabel/requestCertNote: LT × 2 },
 *     faq: { askMoreLabel/askMoreCta: LT × 2 },
 *     missing: { title/backLabel: LT × 2 },
 *   }
 *
 * 形态特点：
 *   - 无 ListField · 纯 LocalizedText（35 段） + 1 bool（enabled）
 *   - LocalizedText 兼容两种形态（裸 / { translations }）· styled-localized-text-adapter passthrough
 *   - storage 1:1 对齐 schema · adapter 走 default 分支
 *
 * S3 节点 D 偏离 #8 闭环（启动指令档 §1.1 #7 · 验收门槛 #9）：
 *   - 旧 spec `theme-config-fttp-product-detail-page.spec.ts:187` flaky 通过
 *     **整体删除该 spec** 一并清理（接管后该 spec testid 守护对象 `tab-basic` 等
 *     已不存在，综合 spec `theme-config-fttp-panels.spec.ts` 已覆盖入口断言）。
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

export const PRODUCT_DETAIL_PAGE_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.product-detail-page',
  version: 1,
  title: '产品详情页 · 配置',
  configPath: 'config.productDetailPage',
  tabs: [
    {
      tabKey: 'basic',
      title: '基础',
      sections: [
        {
          sectionKey: 'master',
          title: '总开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用产品详情页',
              defaultValue: true,
              controlsChildren: true,
              span: 'narrow',
            },
          ],
        },
        {
          sectionKey: 'breadcrumb',
          title: '面包屑导航',
          fields: [
            {
              fieldKey: 'breadcrumb',
              type: 'object',
              label: '面包屑',
              span: 'full',
              fields: [
                { fieldKey: 'homeLabel', type: 'localizedText', label: '面包屑「首页」', multiLang: true, span: 'medium' },
                { fieldKey: 'productsLabel', type: 'localizedText', label: '面包屑「产品」', multiLang: true, span: 'medium' },
              ],
            },
          ],
        },
        {
          sectionKey: 'missing',
          title: '产品不存在兜底面板',
          fields: [
            {
              fieldKey: 'missing',
              type: 'object',
              label: '兜底面板',
              span: 'full',
              fields: [
                { fieldKey: 'title', type: 'localizedText', label: '标题', multiLang: true, span: 'wide' },
                { fieldKey: 'backLabel', type: 'localizedText', label: '返回按钮文案', multiLang: true, span: 'wide' },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'cta',
      title: 'CTA & 底部 CTA',
      sections: [
        {
          sectionKey: 'cta',
          title: '主信息区 4 CTA 按钮',
          fields: [
            {
              fieldKey: 'cta',
              type: 'object',
              label: 'CTA 按钮',
              span: 'full',
              fields: [
                { fieldKey: 'inquireLabel', type: 'localizedText', label: '立即询盘', multiLang: true, span: 'medium' },
                { fieldKey: 'addToCartLabel', type: 'localizedText', label: '加入询价车', multiLang: true, span: 'medium' },
                { fieldKey: 'addedToCartLabel', type: 'localizedText', label: '已加入提示', multiLang: true, span: 'medium' },
                { fieldKey: 'shareLabel', type: 'localizedText', label: '分享', multiLang: true, span: 'medium' },
              ],
            },
          ],
        },
        {
          sectionKey: 'bottomCta',
          title: '底部 CTA 模块（含 {productKey} 占位符）',
          fields: [
            {
              fieldKey: 'bottomCta',
              type: 'object',
              label: '底部 CTA',
              span: 'full',
              fields: [
                { fieldKey: 'eyebrow', type: 'localizedText', label: '小标题（顶部一行）', multiLang: true, span: 'wide' },
                {
                  fieldKey: 'titleTemplate',
                  type: 'localizedText',
                  label: '主标题模板（含 {productKey}）',
                  multiLang: true,
                  span: 'wide',
                },
                { fieldKey: 'description', type: 'localizedText', label: '描述', multiLang: true, multiline: true, span: 'full' },
                { fieldKey: 'certificateNote', type: 'localizedText', label: '证书附注', multiLang: true, span: 'wide' },
                { fieldKey: 'submitInquiryLabel', type: 'localizedText', label: '主按钮：立即提交询价', multiLang: true, span: 'medium' },
                { fieldKey: 'addToCartLabel', type: 'localizedText', label: '次按钮：加入询价车', multiLang: true, span: 'medium' },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'tabs-titles',
      title: 'Tab & 章节标题',
      sections: [
        {
          sectionKey: 'tabs',
          title: '5 个 Tab 标签',
          fields: [
            {
              fieldKey: 'tabs',
              type: 'object',
              label: 'Tab 标签',
              span: 'full',
              fields: [
                { fieldKey: 'descriptionLabel', type: 'localizedText', label: 'Tab · 描述', multiLang: true, span: 'medium' },
                { fieldKey: 'specsLabel', type: 'localizedText', label: 'Tab · 规格', multiLang: true, span: 'medium' },
                { fieldKey: 'packagingLabel', type: 'localizedText', label: 'Tab · 包装', multiLang: true, span: 'medium' },
                { fieldKey: 'certificationsLabel', type: 'localizedText', label: 'Tab · 认证', multiLang: true, span: 'medium' },
                { fieldKey: 'faqLabel', type: 'localizedText', label: 'Tab · FAQ', multiLang: true, span: 'medium' },
              ],
            },
          ],
        },
        {
          sectionKey: 'sectionTitles',
          title: '章节标题（7 段）',
          fields: [
            {
              fieldKey: 'sectionTitles',
              type: 'object',
              label: '章节标题',
              span: 'full',
              fields: [
                { fieldKey: 'fullSpecs', type: 'localizedText', label: '完整技术规格', multiLang: true, span: 'wide' },
                { fieldKey: 'packagingDetails', type: 'localizedText', label: '包装详情', multiLang: true, span: 'wide' },
                { fieldKey: 'shippingLogistics', type: 'localizedText', label: '运输与物流', multiLang: true, span: 'wide' },
                { fieldKey: 'certifications', type: 'localizedText', label: '资质认证与合规', multiLang: true, span: 'wide' },
                { fieldKey: 'faqHeading', type: 'localizedText', label: '常见问题', multiLang: true, span: 'wide' },
                { fieldKey: 'relatedProducts', type: 'localizedText', label: '相关产品（主标题）', multiLang: true, span: 'wide' },
                { fieldKey: 'relatedEyebrow', type: 'localizedText', label: '相关产品（小标题）', multiLang: true, span: 'wide' },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'emptyStates',
      title: '空态文案',
      sections: [
        {
          sectionKey: 'emptyStates',
          title: '字段空态文案（5 段）',
          description: '产品数据中对应字段为空时显示的友好提示。',
          fields: [
            {
              fieldKey: 'emptyStates',
              type: 'object',
              label: '空态文案',
              span: 'full',
              fields: [
                { fieldKey: 'noGallery', type: 'localizedText', label: '无产品图片', multiLang: true, span: 'wide' },
                { fieldKey: 'noSpecs', type: 'localizedText', label: '无规格信息', multiLang: true, span: 'wide' },
                { fieldKey: 'noPackaging', type: 'localizedText', label: '无包装与运输信息', multiLang: true, span: 'wide' },
                { fieldKey: 'noCertifications', type: 'localizedText', label: '无认证信息', multiLang: true, span: 'wide' },
                { fieldKey: 'noFaq', type: 'localizedText', label: '无 FAQ', multiLang: true, span: 'wide' },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'cert-faq',
      title: '认证 & FAQ',
      sections: [
        {
          sectionKey: 'certifications',
          title: '资质认证 Tab 通用文案',
          fields: [
            {
              fieldKey: 'certifications',
              type: 'object',
              label: '资质认证',
              span: 'full',
              fields: [
                { fieldKey: 'requestCertLabel', type: 'localizedText', label: '索取证书按钮文案', multiLang: true, span: 'wide' },
                { fieldKey: 'requestCertNote', type: 'localizedText', label: '索取证书附注（如 NDA 说明）', multiLang: true, multiline: true, span: 'full' },
              ],
            },
          ],
        },
        {
          sectionKey: 'faq',
          title: 'FAQ Tab 通用文案',
          fields: [
            {
              fieldKey: 'faq',
              type: 'object',
              label: 'FAQ',
              span: 'full',
              fields: [
                { fieldKey: 'askMoreLabel', type: 'localizedText', label: '还有疑问标语', multiLang: true, span: 'wide' },
                { fieldKey: 'askMoreCta', type: 'localizedText', label: '咨询销售按钮文案', multiLang: true, span: 'wide' },
              ],
            },
          ],
        },
      ],
    },
  ],
};
