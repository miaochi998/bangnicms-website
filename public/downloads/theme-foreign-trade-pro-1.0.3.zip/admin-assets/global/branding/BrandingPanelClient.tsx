'use client';

/**
 * BrandingPanelClient · 阶段 5 节点 B · D-γ 迁主题包
 * -----------------------------------------------------------------------------
 * 薄壳：把 server 层取到的 active theme 完整 config 传给 PanelRenderer，
 * 由 PanelRenderer + useThemeConfigSave「根合并模式」处理保存
 * （`configPath: 'config'` → `nextConfig = {...prevConfig, ...draft}`）。
 *
 * adapter：`createBuiltinThemeAdapter('theme-export-basic.branding')` —— branding
 * 无 LocalizedText 字段，本质走 identity；保留工厂调用以保命名空间一致。
 */

import { PanelRenderer } from '@/components/panel-renderer';
import { createBuiltinThemeAdapter } from '@/components/theme-config/builtin-panel-factories';
import { BRANDING_PANEL } from './schema';

interface LangOption {
  code: string;
  name: string;
}

export function BrandingPanelClient({
  apiBase,
  extensionId,
  themeKey,
  themeName,
  initialData,
  languages,
  defaultLang,
  aiAvailable,
}: {
  apiBase: string;
  extensionId: string;
  themeKey: string;
  themeName: string;
  initialData: Record<string, unknown> | undefined;
  languages: LangOption[];
  defaultLang: string;
  aiAvailable: boolean;
}) {
  return (
    <PanelRenderer
      apiBase={apiBase}
      extensionId={extensionId}
      themeKey={themeKey}
      themeName={themeName}
      panel={BRANDING_PANEL}
      initialData={initialData}
      languages={languages}
      defaultLang={defaultLang}
      aiAvailable={aiAvailable}
      dataAdapter={createBuiltinThemeAdapter(BRANDING_PANEL.panelKey)}
    />
  );
}
