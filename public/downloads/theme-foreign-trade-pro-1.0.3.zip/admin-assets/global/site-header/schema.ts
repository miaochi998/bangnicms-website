/**
 * fttp 网站页头 PanelSchemaV1 schema（阶段 2 节点 B · B-D1）
 * -----------------------------------------------------------------------------
 * 接管自原 SiteHeaderConfigForm.tsx（656 行手写）。
 *
 * Storage 形态（BangNiCmsThemeSiteHeaderConfig · config.siteHeader）：
 *   {
 *     enabled,
 *     utilityBar: {
 *       enabled,
 *       showLanguageSwitcher,
 *       contactItems: [{id, type, icon?, label, labelTranslations?, href?, hiddenOnMobile?, enabled}, ...],
 *       quickLinks:   [{id, icon?, label?, labelTranslations?, labelI18nKey?, link, highlight?, hiddenOnMobile?, enabled}, ...],
 *     },
 *     mainBar: {
 *       search: { enabled, actionHref?, paramName? },
 *       inquiryCartLink: BangNiCmsCtaLink,
 *       showInquiryCount,
 *     },
 *     navRow: {
 *       showAllCategoriesButton,
 *       trustBadges: [{id, label, labelTranslations?, icon?, enabled}, ...],
 *     },
 *   }
 *
 * 形态特点：
 *   - 三个 ListField（contactItems / quickLinks / trustBadges）每项有 `label` 兜底字符串
 *     + `labelTranslations` 多语言 map。schema **仅暴露 labelTranslations**（保留原
 *     ConfigForm 单一编辑入口的 UX），label 由 fttp-storage-adapter 的
 *     postprocessSiteHeaderWrite 同步 = labelTranslations[defaultLang]。
 *   - 2 处 CtaLink：utilityBar.quickLinks[].link + mainBar.inquiryCartLink，
 *     复用阶段 2 节点 A 抽出的 createCtaLinkObjectField。
 *   - tab[0] section[0] 的 enabled 用 controlsChildren=true 作为整面板 master 开关。
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';
import { createCtaLinkObjectField } from '@/components/panel-renderer/field-factories';

const ITEM_ID_FIELD = {
  fieldKey: 'id',
  type: 'text',
  label: 'ID（系统生成 · 请勿修改）',
  placeholder: '保存时自动补齐',
  span: 'narrow',
} as const;

export const SITE_HEADER_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.site-header',
  version: 1,
  title: '网站页头 · 配置',
  configPath: 'config.siteHeader',
  tabs: [
    {
      tabKey: 'utility',
      title: '顶部实用栏',
      sections: [
        {
          sectionKey: 'master',
          title: '总开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用站点页头',
              description: '关闭后整个站点页头不显示。',
              defaultValue: true,
              controlsChildren: true,
              span: 'narrow',
            },
          ],
        },
        {
          sectionKey: 'utilityBar',
          title: '顶部实用栏（联系方式 / 快捷链接 / 语言切换器）',
          fields: [
            {
              fieldKey: 'utilityBar',
              type: 'object',
              label: '顶部实用栏',
              span: 'full',
              fields: [
                {
                  fieldKey: 'enabled',
                  type: 'switch',
                  label: '整块启用顶部实用栏',
                  defaultValue: true,
                  span: 'wide',
                },
                {
                  fieldKey: 'showLanguageSwitcher',
                  type: 'switch',
                  label: '显示语言切换器（需 ≥2 种启用语言才会真正渲染）',
                  defaultValue: true,
                  span: 'wide',
                },
                {
                  fieldKey: 'contactItems',
                  type: 'arrayOfObject',
                  label: '联系方式',
                  description: '邮箱 / 电话 / WhatsApp / 微信 / 自定义；至多 6 项。',
                  minItems: 0,
                  maxItems: 6,
                  itemTitleField: 'labelTranslations',
                  addLabel: '添加一项联系方式',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      ITEM_ID_FIELD,
                      {
                        fieldKey: 'type',
                        type: 'select',
                        label: '类型',
                        defaultValue: 'custom',
                        options: [
                          { value: 'email', label: 'Email' },
                          { value: 'phone', label: '电话' },
                          { value: 'whatsapp', label: 'WhatsApp' },
                          { value: 'wechat', label: '微信' },
                          { value: 'custom', label: '自定义' },
                        ],
                        span: 'narrow',
                      },
                      {
                        fieldKey: 'labelTranslations',
                        type: 'localizedText',
                        label: '显示文字（多语言）',
                        description: '邮箱 / 电话号码通常各语言相同；客服时间等说明文字可翻译。',
                        multiLang: true,
                        span: 'wide',
                      },
                      {
                        fieldKey: 'href',
                        type: 'text',
                        label: '点击后跳转（mailto: / tel: / https: / 留空 = 纯展示）',
                        placeholder: 'mailto:sales@example.com',
                        span: 'wide',
                      },
                      {
                        fieldKey: 'icon',
                        type: 'icon',
                        label: '图标（Lucide 名称）',
                        span: 'narrow',
                      },
                      {
                        fieldKey: 'hiddenOnMobile',
                        type: 'switch',
                        label: '移动端隐藏',
                        defaultValue: false,
                        span: 'narrow',
                      },
                      {
                        fieldKey: 'enabled',
                        type: 'switch',
                        label: '启用此项',
                        defaultValue: true,
                        span: 'narrow',
                      },
                    ],
                  },
                },
                {
                  fieldKey: 'quickLinks',
                  type: 'arrayOfObject',
                  label: '快捷链接',
                  description: '顶部实用栏右侧按钮；至多 4 项。CtaLink 9 类跳转目标。',
                  minItems: 0,
                  maxItems: 4,
                  itemTitleField: 'labelTranslations',
                  addLabel: '添加一项快捷链接',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      ITEM_ID_FIELD,
                      {
                        fieldKey: 'icon',
                        type: 'icon',
                        label: '图标（Lucide 名称）',
                        span: 'narrow',
                      },
                      {
                        fieldKey: 'labelTranslations',
                        type: 'localizedText',
                        label: '按钮文字（多语言）',
                        description: '在不同语言的网站页面上会按语言显示。',
                        multiLang: true,
                        span: 'wide',
                      },
                      {
                        fieldKey: 'labelI18nKey',
                        type: 'text',
                        label: '系统语言包 key（高级 · 仅内置预置项使用）',
                        description: '当上面"按钮文字"全部留空时，按语言包查找。例如 nav.downloadCatalog。',
                        placeholder: 'nav.downloadCatalog',
                        span: 'wide',
                      },
                      createCtaLinkObjectField({
                        fieldKey: 'link',
                        label: '点击跳转目标（CtaLink）',
                        defaultType: 'url',
                      }),
                      {
                        fieldKey: 'highlight',
                        type: 'switch',
                        label: '高亮按钮样式（突出主 CTA）',
                        defaultValue: false,
                        span: 'narrow',
                      },
                      {
                        fieldKey: 'hiddenOnMobile',
                        type: 'switch',
                        label: '移动端隐藏',
                        defaultValue: false,
                        span: 'narrow',
                      },
                      {
                        fieldKey: 'enabled',
                        type: 'switch',
                        label: '启用此项',
                        defaultValue: true,
                        span: 'narrow',
                      },
                    ],
                  },
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'main',
      title: '主导航栏',
      sections: [
        {
          sectionKey: 'mainBar',
          title: '主导航栏（搜索框 + 询盘车）',
          fields: [
            {
              fieldKey: 'mainBar',
              type: 'object',
              label: '主导航栏',
              span: 'full',
              fields: [
                {
                  fieldKey: 'search',
                  type: 'object',
                  label: '搜索框',
                  span: 'full',
                  fields: [
                    {
                      fieldKey: 'enabled',
                      type: 'switch',
                      label: '启用搜索框',
                      defaultValue: true,
                      span: 'narrow',
                    },
                    {
                      fieldKey: 'actionHref',
                      type: 'text',
                      label: '搜索提交到的网址',
                      placeholder: '/search（留空则默认 /search）',
                      span: 'wide',
                    },
                    {
                      fieldKey: 'paramName',
                      type: 'text',
                      label: '搜索关键词参数名',
                      placeholder: 'q（留空则默认 q）',
                      span: 'narrow',
                    },
                  ],
                },
                {
                  fieldKey: 'showInquiryCount',
                  type: 'switch',
                  label: '在询盘车按钮上显示商品数量徽标',
                  defaultValue: true,
                  span: 'wide',
                },
                createCtaLinkObjectField({
                  fieldKey: 'inquiryCartLink',
                  label: '询盘车按钮跳转目标（CtaLink）',
                  defaultType: 'inquiry-cart',
                }),
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'nav',
      title: '导航行',
      sections: [
        {
          sectionKey: 'navRow',
          title: '导航行（全部分类按钮 + 信任徽章）',
          fields: [
            {
              fieldKey: 'navRow',
              type: 'object',
              label: '导航行',
              span: 'full',
              fields: [
                {
                  fieldKey: 'showAllCategoriesButton',
                  type: 'switch',
                  label: '显示左侧的全部分类弹出菜单按钮',
                  defaultValue: true,
                  span: 'wide',
                },
                {
                  fieldKey: 'trustBadges',
                  type: 'arrayOfObject',
                  label: '信任徽章',
                  description: 'ISO 9001 / CE / FCC 等认证编号原样展示；至多 6 项。',
                  minItems: 0,
                  maxItems: 6,
                  itemTitleField: 'labelTranslations',
                  addLabel: '添加一项信任徽章',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      ITEM_ID_FIELD,
                      {
                        fieldKey: 'labelTranslations',
                        type: 'localizedText',
                        label: '徽章文字（多语言）',
                        description: '认证编号通常原样不翻译；说明文字可翻译。',
                        multiLang: true,
                        span: 'wide',
                      },
                      {
                        fieldKey: 'icon',
                        type: 'icon',
                        label: '图标（Lucide 名称）',
                        span: 'narrow',
                      },
                      {
                        fieldKey: 'enabled',
                        type: 'switch',
                        label: '启用此项',
                        defaultValue: true,
                        span: 'narrow',
                      },
                    ],
                  },
                },
              ],
            },
          ],
        },
      ],
    },
  ],
};
