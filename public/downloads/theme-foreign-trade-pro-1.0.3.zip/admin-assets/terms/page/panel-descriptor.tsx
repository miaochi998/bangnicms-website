import { ScrollText } from 'lucide-react';
import type { PanelDescriptor } from '../../_types';
import { iconHint } from '../../_helpers';
import { TermsPagePanelClient } from './TermsPagePanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'terms/page',
  configKey: 'termsPage',
  title: '服务条款页',
  description: '配置 /terms 法律页：Hero 页头 + 文件信息卡 + 异构正文 sections（段落/列表/Callout/表格）+ TOC 目录 + 底部联系 + 相关法律文件卡。所有文案多语言。',
  dataPage: 'theme-config-fttp-terms-page',
  notApplicableTestId: 'terms-page-not-applicable',
  guardMode: 'theme-key',
  PanelClient: TermsPagePanelClient,
  hint: iconHint(
    <ScrollText className="h-4 w-4 shrink-0 mt-0.5" />,
    <>
      <p>
        <strong>提示</strong>：服务条款 12 节默认覆盖「接受/定义/目录定价/下单/付款/发运/质保/IP/责任/不可抗力/法律/联系」全流程。运营按需新增 / 删除章节。
      </p>
      <p className="mt-1">
        段落文本支持简单内联标签{' '}
        <code className="px-1 py-0.5 rounded bg-muted text-foreground">&lt;b&gt;</code>{' '}
        <code className="px-1 py-0.5 rounded bg-muted text-foreground">&lt;a href&gt;</code>{' '}
        <code className="px-1 py-0.5 rounded bg-muted text-foreground">&lt;br/&gt;</code>。表格 cell 同样支持。
      </p>
      <p className="mt-1">
        若关闭「启用」开关，前台{' '}
        <code className="px-1 py-0.5 rounded bg-muted text-foreground">/terms</code> 将渲染为空。
      </p>
    </>,
  ),
};
