'use client';

/**
 * HeroPanelClient · 节点 C commit-1b-β
 * -----------------------------------------------------------------------------
 * page.tsx 是 Server Component；adapter 工厂函数对象不能跨 server→client，
 * 故在 client 侧 createFttpStorageAdapter('fttp.hero') 后渲染。
 */

import { PanelRenderer } from '@/components/panel-renderer';
import { createFttpStorageAdapter } from '@bangnicms-theme/foreign-trade-pro/admin-assets/_storage-adapter';
import { HERO_PANEL } from './schema';

interface LangOption {
  code: string;
  name: string;
}

export function HeroPanelClient({
  apiBase,
  extensionId,
  themeKey,
  themeName,
  initialData,
  languages,
  defaultLang,
  aiAvailable,
}: {
  apiBase: string;
  extensionId: string;
  themeKey: string;
  themeName: string;
  initialData: Record<string, unknown> | undefined;
  languages: LangOption[];
  defaultLang: string;
  aiAvailable: boolean;
}) {
  return (
    <PanelRenderer
      apiBase={apiBase}
      extensionId={extensionId}
      themeKey={themeKey}
      themeName={themeName}
      panel={HERO_PANEL}
      initialData={initialData}
      languages={languages}
      defaultLang={defaultLang}
      aiAvailable={aiAvailable}
      dataAdapter={createFttpStorageAdapter(HERO_PANEL.panelKey)}
    />
  );
}
