'use client';

/**
 * ProductListPagePanelClient · 阶段 2 节点 C · C-D3
 */

import { PanelRenderer } from '@/components/panel-renderer';
import { createFttpStorageAdapter } from '@bangnicms-theme/foreign-trade-pro/admin-assets/_storage-adapter';
import { PRODUCT_LIST_PAGE_PANEL } from './schema';

interface LangOption {
  code: string;
  name: string;
}

export function ProductListPagePanelClient({
  apiBase,
  extensionId,
  themeKey,
  themeName,
  initialData,
  languages,
  defaultLang,
  aiAvailable,
}: {
  apiBase: string;
  extensionId: string;
  themeKey: string;
  themeName: string;
  initialData: Record<string, unknown> | undefined;
  languages: LangOption[];
  defaultLang: string;
  aiAvailable: boolean;
}) {
  return (
    <PanelRenderer
      apiBase={apiBase}
      extensionId={extensionId}
      themeKey={themeKey}
      themeName={themeName}
      panel={PRODUCT_LIST_PAGE_PANEL}
      initialData={initialData}
      languages={languages}
      defaultLang={defaultLang}
      aiAvailable={aiAvailable}
      dataAdapter={createFttpStorageAdapter(PRODUCT_LIST_PAGE_PANEL.panelKey, { defaultLang })}
    />
  );
}
