'use client';

/**
 * ClientsPanelClient · 节点 B D-B3（S2.4）
 */

import { PanelRenderer } from '@/components/panel-renderer';
import { createFttpStorageAdapter } from '@bangnicms-theme/foreign-trade-pro/admin-assets/_storage-adapter';
import { CLIENTS_PANEL } from './schema';

interface LangOption {
  code: string;
  name: string;
}

export function ClientsPanelClient({
  apiBase,
  extensionId,
  themeKey,
  themeName,
  initialData,
  languages,
  defaultLang,
  aiAvailable,
}: {
  apiBase: string;
  extensionId: string;
  themeKey: string;
  themeName: string;
  initialData: Record<string, unknown> | undefined;
  languages: LangOption[];
  defaultLang: string;
  aiAvailable: boolean;
}) {
  return (
    <PanelRenderer
      apiBase={apiBase}
      extensionId={extensionId}
      themeKey={themeKey}
      themeName={themeName}
      panel={CLIENTS_PANEL}
      initialData={initialData}
      languages={languages}
      defaultLang={defaultLang}
      aiAvailable={aiAvailable}
      dataAdapter={createFttpStorageAdapter(CLIENTS_PANEL.panelKey)}
    />
  );
}
