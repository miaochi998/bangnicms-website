import type { PanelDescriptor } from '../../../_types';
import { DownloadsDetailPagePanelClient } from './DownloadsDetailPagePanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'downloads/detail/page',
  configKey: 'downloadsDetailPage',
  title: '下载详情页',
  description: '配置 /downloads/:slug 详情页：Hero（深色面包屑 + 标题 + 摘要）+ 正文（描述 + Tab：详情/规格/版本/FAQ）+ 文件下载列表 + 表单弹窗 + 相关下载。所有文案多语言。',
  dataPage: 'theme-config-fttp-downloads-detail-page',
  notApplicableTestId: 'downloads-detail-page-not-applicable',
  guardMode: 'theme-key',
  PanelClient: DownloadsDetailPagePanelClient,
};
