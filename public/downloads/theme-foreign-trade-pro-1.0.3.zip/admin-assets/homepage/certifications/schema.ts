/**
 * fttp 首页「资质认证 / 服务承诺」PanelSchemaV1 schema（节点 B D-B2 · S2.4）
 * -----------------------------------------------------------------------------
 * 接管自原 CertificationsConfigForm.tsx（563 行）。
 *
 * Storage 形态 BangNiCmsThemeCertificationsConfig（标准形态 · 无特殊包装）：
 *   {
 *     enabled,
 *     header: { eyebrow, title, description },
 *     items: [{ id, code, body }],
 *     boxStyle: { border, borderRadius, hoverBg },
 *     style: { 5 段 TextStyle }
 *   }
 *
 * 节点 B 范围降级：
 *   - `boxStyle` / `style` 不暴露（UI 优化类，留节点 D）→ adapter 默认 merge
 *     从 prev 透传保留
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

export const CERTIFICATIONS_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.certifications',
  version: 1,
  previewAdapter: 'fttp.certifications',
  title: '首页 · 资质认证',
  configPath: 'config.certifications',
  tabs: [
    {
      tabKey: 'overview',
      title: '总开关 · 头部',
      sections: [
        {
          sectionKey: 'master',
          title: '整块开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用本区块',
              description: '关闭后首页不渲染「资质认证」区块。',
              defaultValue: true,
              controlsChildren: true,
              span: 'narrow',
            },
          ],
        },
        {
          sectionKey: 'header',
          title: '区块头部',
          fields: [
            {
              fieldKey: 'header',
              type: 'object',
              label: '头部文案',
              span: 'full',
              fields: [
                {
                  fieldKey: 'eyebrow',
                  type: 'localizedText',
                  label: '小眉题',
                  multiLang: true,
                  placeholder: '资质认证与合规',
                  span: 'wide',
                },
                {
                  fieldKey: 'title',
                  type: 'localizedText',
                  label: '主标题',
                  multiLang: true,
                  required: true,
                  placeholder: '兼容全球标准的品质背书',
                  span: 'wide',
                },
                {
                  fieldKey: 'description',
                  type: 'localizedText',
                  label: '描述',
                  multiLang: true,
                  span: 'full',
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'items',
      title: '徽章项',
      sections: [
        {
          sectionKey: 'items',
          title: '徽章列表',
          description: '大字代号（code）+ 小字说明（body），全部多语言。',
          fields: [
            {
              fieldKey: 'items',
              type: 'arrayOfObject',
              label: '徽章',
              minItems: 0,
              maxItems: 20,
              itemTitleField: 'code.zh-CN',
              addLabel: '添加一个徽章',
              span: 'full',
              itemSchema: {
                fields: [
                  {
                    fieldKey: 'id',
                    type: 'text',
                    label: 'ID（稳定唯一）',
                    placeholder: 'iso9001',
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'code',
                    type: 'localizedText',
                    label: '大字代号（code）',
                    multiLang: true,
                    required: true,
                    placeholder: 'ISO 9001',
                    span: 'wide',
                  },
                  {
                    fieldKey: 'body',
                    type: 'localizedText',
                    label: '小字说明（body）',
                    multiLang: true,
                    placeholder: '质量管理体系',
                    span: 'full',
                  },
                ],
              },
            },
          ],
        },
      ],
    },
  ],
};
