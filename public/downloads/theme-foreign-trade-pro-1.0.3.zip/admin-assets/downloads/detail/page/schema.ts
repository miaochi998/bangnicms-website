/**
 * fttp 下载详情页 PanelSchemaV1 schema（阶段 2 节点 C · C-D6）
 * -----------------------------------------------------------------------------
 * 接管自原 DownloadsDetailPageConfigForm.tsx（617 行手写）。
 *
 * Storage 形态（config.downloadsDetailPage）：
 *   {
 *     enabled,
 *     hero: { breadcrumbHome:LT, breadcrumbList:LT },
 *     meta: { enabled, showCategories/showPublishedAt/showDownloadCount: bool,
 *             downloadCountTemplate: LT },
 *     content: { proseStyle:'default'|'minimal', emptyLabel:LT },
 *     download: { 9 段 LT },
 *     related: { enabled, title:LT, strategy:'same-category'|'latest', limit:number, emptyHint:LT },
 *     missing: { title/description/backLabel: LT },
 *   }
 *
 * 形态特点：
 *   - 无 ListField（纯 LocalizedText + bool/select/number）
 *   - storage 1:1 对齐 schema · adapter 走 default 分支（仅顶层浅 merge 保 prev）
 *   - LocalizedText 裸 { lang: str } 形态由 styled-localized-text-adapter passthrough
 *
 * helper 复用偏离登记（schema.ts 头注 + 完工汇报 §X）：
 *   - createCtaLinkObjectField 不复用：missing.backLabel 等无 9 类 type 选择
 *   - 不需要专属 adapter 分支（与节点 B inquiry-form 同款 default 分支）
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

const PROSE_STYLE_OPTIONS = [
  { value: 'default', label: 'Default（默认 prose 排版）' },
  { value: 'minimal', label: 'Minimal（极简）' },
];

const RELATED_STRATEGY_OPTIONS = [
  { value: 'same-category', label: '同分类优先' },
  { value: 'latest', label: '最新优先' },
];

export const DOWNLOADS_DETAIL_PAGE_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.downloads-detail-page',
  version: 1,
  title: '下载详情页 · 配置',
  configPath: 'config.downloadsDetailPage',
  tabs: [
    {
      tabKey: 'basic',
      title: '基础',
      sections: [
        {
          sectionKey: 'master',
          title: '总开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用下载详情页',
              defaultValue: true,
              controlsChildren: true,
              span: 'narrow',
            },
          ],
        },
        {
          sectionKey: 'hero',
          title: 'Hero · 面包屑',
          fields: [
            {
              fieldKey: 'hero',
              type: 'object',
              label: 'Hero',
              span: 'full',
              fields: [
                { fieldKey: 'breadcrumbHome', type: 'localizedText', label: '面包屑「首页」', multiLang: true, span: 'medium' },
                { fieldKey: 'breadcrumbList', type: 'localizedText', label: '面包屑「资料下载」', multiLang: true, span: 'medium' },
              ],
            },
          ],
        },
        {
          sectionKey: 'meta',
          title: 'Meta（分类 / 发布时间 / 累计下载）',
          fields: [
            {
              fieldKey: 'meta',
              type: 'object',
              label: 'Meta',
              span: 'full',
              fields: [
                { fieldKey: 'enabled', type: 'switch', label: '启用 Meta 区块', defaultValue: true, span: 'narrow' },
                { fieldKey: 'showCategories', type: 'switch', label: '显示分类', defaultValue: true, span: 'narrow' },
                { fieldKey: 'showPublishedAt', type: 'switch', label: '显示发布时间', defaultValue: true, span: 'narrow' },
                { fieldKey: 'showDownloadCount', type: 'switch', label: '显示累计下载次数', defaultValue: true, span: 'narrow' },
                {
                  fieldKey: 'downloadCountTemplate',
                  type: 'localizedText',
                  label: '下载计数模板（含 {count}）',
                  multiLang: true,
                  span: 'wide',
                },
              ],
            },
          ],
        },
        {
          sectionKey: 'content',
          title: '左栏正文（富文本介绍）',
          fields: [
            {
              fieldKey: 'content',
              type: 'object',
              label: '正文',
              span: 'full',
              fields: [
                {
                  fieldKey: 'proseStyle',
                  type: 'select',
                  label: 'Prose 排版风格',
                  defaultValue: 'default',
                  options: PROSE_STYLE_OPTIONS,
                  span: 'narrow',
                },
                { fieldKey: 'emptyLabel', type: 'localizedText', label: '暂无介绍占位文案', multiLang: true, span: 'wide' },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'download',
      title: '下载模块',
      sections: [
        {
          sectionKey: 'download',
          title: '右上「下载」模块（9 段文案）',
          fields: [
            {
              fieldKey: 'download',
              type: 'object',
              label: '下载模块',
              span: 'full',
              fields: [
                { fieldKey: 'title', type: 'localizedText', label: '模块标题', multiLang: true, span: 'wide' },
                { fieldKey: 'multiFilesLabel', type: 'localizedText', label: '多文件分组标题', multiLang: true, span: 'wide' },
                { fieldKey: 'primaryButtonLabel', type: 'localizedText', label: '主按钮文案', multiLang: true, span: 'medium' },
                { fieldKey: 'rowButtonLabel', type: 'localizedText', label: '行按钮文案', multiLang: true, span: 'medium' },
                { fieldKey: 'metaSizeLabel', type: 'localizedText', label: '"文件大小" 标签', multiLang: true, span: 'medium' },
                { fieldKey: 'metaUpdatedLabel', type: 'localizedText', label: '"更新时间" 标签', multiLang: true, span: 'medium' },
                { fieldKey: 'metaDownloadCountLabel', type: 'localizedText', label: '"累计下载" 标签', multiLang: true, span: 'medium' },
                { fieldKey: 'metaCategoryLabel', type: 'localizedText', label: '"分类" 标签', multiLang: true, span: 'medium' },
                { fieldKey: 'noFilesHint', type: 'localizedText', label: '无文件提示', multiLang: true, span: 'wide' },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'related',
      title: '相关资料',
      sections: [
        {
          sectionKey: 'related',
          title: '右下「相关下载」',
          fields: [
            {
              fieldKey: 'related',
              type: 'object',
              label: '相关资料',
              span: 'full',
              fields: [
                { fieldKey: 'enabled', type: 'switch', label: '启用相关资料', defaultValue: true, span: 'narrow' },
                { fieldKey: 'title', type: 'localizedText', label: '区标题', multiLang: true, span: 'wide' },
                {
                  fieldKey: 'strategy',
                  type: 'select',
                  label: '推荐策略',
                  defaultValue: 'same-category',
                  options: RELATED_STRATEGY_OPTIONS,
                  span: 'narrow',
                },
                { fieldKey: 'limit', type: 'number', label: '数量上限', min: 1, max: 20, step: 1, span: 'narrow' },
                { fieldKey: 'emptyHint', type: 'localizedText', label: '空态文案', multiLang: true, span: 'wide' },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'missing',
      title: '缺失态',
      sections: [
        {
          sectionKey: 'missing',
          title: '404 / 缺失态',
          fields: [
            {
              fieldKey: 'missing',
              type: 'object',
              label: '缺失态',
              span: 'full',
              fields: [
                { fieldKey: 'title', type: 'localizedText', label: '标题', multiLang: true, span: 'wide' },
                { fieldKey: 'description', type: 'localizedText', label: '描述', multiLang: true, multiline: true, span: 'full' },
                { fieldKey: 'backLabel', type: 'localizedText', label: '返回链接文案', multiLang: true, span: 'wide' },
              ],
            },
          ],
        },
      ],
    },
  ],
};
