'use client';

/**
 * InquiryCtaPanelClient · 节点 C commit-1b-β
 * -----------------------------------------------------------------------------
 * inquiry-cta 数据形态是标准 PanelSchemaV1 LocalizedString。fttp adapter 默认
 * 分支：preprocessRead identity / postprocessWrite 浅 merge prev（保留 style 等
 * 非渲染字段）；字段级 read/write 走 standard 形态 passthrough。
 */

import { PanelRenderer } from '@/components/panel-renderer';
import { createFttpStorageAdapter } from '@bangnicms-theme/foreign-trade-pro/admin-assets/_storage-adapter';
import { INQUIRY_CTA_PANEL } from './schema';

interface LangOption {
  code: string;
  name: string;
}

export function InquiryCtaPanelClient({
  apiBase,
  extensionId,
  themeKey,
  themeName,
  initialData,
  languages,
  defaultLang,
  aiAvailable,
}: {
  apiBase: string;
  extensionId: string;
  themeKey: string;
  themeName: string;
  initialData: Record<string, unknown> | undefined;
  languages: LangOption[];
  defaultLang: string;
  aiAvailable: boolean;
}) {
  return (
    <PanelRenderer
      apiBase={apiBase}
      extensionId={extensionId}
      themeKey={themeKey}
      themeName={themeName}
      panel={INQUIRY_CTA_PANEL}
      initialData={initialData}
      languages={languages}
      defaultLang={defaultLang}
      aiAvailable={aiAvailable}
      dataAdapter={createFttpStorageAdapter(INQUIRY_CTA_PANEL.panelKey)}
    />
  );
}
