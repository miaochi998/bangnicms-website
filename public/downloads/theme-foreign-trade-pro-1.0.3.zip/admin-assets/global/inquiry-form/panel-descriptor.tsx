import type { PanelDescriptor } from '../../_types';
import { InquiryFormPanelClient } from './InquiryFormPanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'global/inquiry-form',
  configKey: 'inquiryForm',
  title: '全站通用 · 询盘表单文案',
  description: '本面板配置全站通用询盘表单的所有文字（5 字段标签 / 占位符 / 错误提示 / 提交反馈 / 同意条款 / 安全提示）。**首页「免费索取报价」/ 联系页 / 产品详情询盘弹窗共用同一份配置**，运营改一处，三处同时生效。',
  dataPage: 'theme-config-fttp-inquiry-form',
  notApplicableTestId: 'inquiry-form-not-applicable',
  guardMode: 'theme-key',
  PanelClient: InquiryFormPanelClient,
};
