import type { PanelDescriptor } from '../../../_types';
import { DownloadsListPagePanelClient } from './DownloadsListPagePanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'downloads/list/page',
  configKey: 'downloadsListPage',
  title: '下载中心列表页',
  description: '配置 /downloads 列表页：Hero（深色面包屑 + 标题 + 描述 + 计数）+ 分类侧栏 + 卡片网格 + 分页。所有文案多语言。',
  dataPage: 'theme-config-fttp-downloads-list-page',
  notApplicableTestId: 'downloads-list-page-not-applicable',
  guardMode: 'theme-key',
  PanelClient: DownloadsListPagePanelClient,
};
