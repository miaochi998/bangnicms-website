import type { PanelDescriptor } from '../../_types';
import { TrustStripPanelClient } from './TrustStripPanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'homepage/trust-strip',
  configKey: 'trustStrip',
  title: '首页信任条 · 配置',
  description: '这里改的内容会展示在首页 Hero 下方的数字展示区（行业经验、出口国家、质量认证等 6 项）。',
  dataPage: 'theme-config-trust-strip',
  guardMode: 'theme-key',
  PanelClient: TrustStripPanelClient,
};
