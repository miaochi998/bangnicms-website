/**
 * fttp 首页信任条 PanelSchemaV1 schema（节点 C commit-1a · S2.3）
 * -----------------------------------------------------------------------------
 * 接管自原 TrustStripConfigForm.tsx（fttp 现有数据形态映射规则见
 * `apps/admin/src/components/theme-config/fttp-storage-adapter.ts`）。
 *
 * 落地策略（节点 C commit-1a 试点）：
 *   - inline TS const 形态 schema，由薄壳 page.tsx 直接 import
 *   - **TODO**（节点 C commit-1b 末尾或后续 commit）：把 fttp 6 schema 抽到
 *     `themes/theme-foreign-trade-pro/manifest.json#marketingMeta.configPanels[i].schema`
 *     字段，admin 通过 server API `/extensions/active-theme` 读取，彻底消除
 *     admin 内 fttp 专属 schema 文件
 *
 * 节点 C commit-2 删除 TrustStripConfigForm.tsx 时本文件保留作为过渡；
 * commit-1b 末尾或 schema 落 manifest 后整文件删除。
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

const FREQUENT_ICONS = [
  'Sparkles', 'Award', 'BadgeCheck', 'ShieldCheck', 'Globe2', 'Truck',
  'Users', 'Factory', 'Building2', 'Cpu', 'Trophy', 'Medal',
];

export const TRUST_STRIP_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.trust-strip',
  version: 1,
  previewAdapter: 'fttp.trust-strip',
  title: '首页信任条',
  configPath: 'config.trustStrip',
  tabs: [
    {
      tabKey: 'items',
      title: '项列表',
      sections: [
        {
          sectionKey: 'master',
          title: '整块开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用首页信任条',
              defaultValue: true,
              controlsChildren: true,
              span: 'full',
            },
          ],
        },
        {
          sectionKey: 'list',
          title: '项列表',
          description:
            '至少 3 项 / 最多 12 项；每项含图标 + 数值（大字）+ 主标签 + 副标题（可选）。',
          fields: [
            {
              fieldKey: 'items',
              type: 'arrayOfObject',
              label: '信任条项',
              minItems: 3,
              maxItems: 12,
              itemTitleField: 'label.zh-CN',
              defaultCollapsed: false,
              span: 'full',
              itemSchema: {
                fields: [
                  {
                    fieldKey: 'id',
                    type: 'text',
                    label: '稳定标识 ID',
                    description: '用于前台数据钩子（如 e2e 断言、锚点定位）；保留默认值，新建项可留空。',
                    placeholder: 'years',
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'icon',
                    type: 'object',
                    label: '图标',
                    span: 'full',
                    fields: [
                      {
                        fieldKey: 'kind',
                        type: 'select',
                        label: '类型',
                        options: [
                          { value: 'lucide', label: 'Lucide 图标库' },
                          { value: 'upload', label: '上传自定义' },
                        ],
                        defaultValue: 'lucide',
                        span: 'narrow',
                      },
                      {
                        fieldKey: 'name',
                        type: 'icon',
                        label: 'Lucide 图标名',
                        frequentIcons: FREQUENT_ICONS,
                        span: 'wide',
                      },
                      {
                        fieldKey: 'url',
                        type: 'mediaPicker',
                        label: '上传图片 URL（kind=upload 时使用）',
                        accept: ['image'],
                        span: 'wide',
                      },
                      {
                        fieldKey: 'size',
                        type: 'text',
                        label: '尺寸',
                        placeholder: '28px',
                        defaultValue: '28px',
                        span: 'narrow',
                      },
                      {
                        fieldKey: 'color',
                        type: 'color',
                        label: '颜色',
                        defaultValue: '#ff6b35',
                        span: 'narrow',
                      },
                    ],
                  },
                  {
                    fieldKey: 'value',
                    type: 'localizedText',
                    label: '数值 / 大字（value）',
                    description: '第一眼看到的核心信息，如 15+ / ISO 9001 / 80+',
                    multiLang: true,
                    span: 'wide',
                  },
                  {
                    fieldKey: 'label',
                    type: 'localizedText',
                    label: '主标签（label）',
                    description: '说明数值的含义，如：年行业深耕 / 出口国家与地区',
                    multiLang: true,
                    required: true,
                    span: 'wide',
                  },
                  {
                    fieldKey: 'sub',
                    type: 'localizedText',
                    label: '副标题（sub · 可选）',
                    description: '小字补充说明；全语言留空则不渲染',
                    multiLang: true,
                    span: 'wide',
                  },
                ],
              },
            },
          ],
        },
      ],
    },
    {
      tabKey: 'layout',
      title: '整体样式',
      sections: [
        {
          sectionKey: 'layout-group',
          title: '样式与列数',
          fields: [
            {
              fieldKey: 'layout',
              type: 'object',
              label: '整体样式',
              span: 'full',
              fields: [
                {
                  fieldKey: 'background',
                  type: 'color',
                  label: 'section 背景色',
                  defaultValue: '#ffffff',
                  span: 'narrow',
                },
                {
                  fieldKey: 'paddingY',
                  type: 'text',
                  label: '纵向内边距',
                  placeholder: '48px',
                  defaultValue: '48px',
                  span: 'narrow',
                },
                {
                  fieldKey: 'itemGap',
                  type: 'text',
                  label: '项间距',
                  placeholder: '32px',
                  defaultValue: '32px',
                  span: 'narrow',
                },
                {
                  fieldKey: 'columnsDesktop',
                  type: 'number',
                  label: '桌面列数',
                  min: 1,
                  max: 12,
                  step: 1,
                  defaultValue: 6,
                  span: 'narrow',
                },
                {
                  fieldKey: 'columnsTablet',
                  type: 'number',
                  label: '平板列数',
                  min: 1,
                  max: 12,
                  step: 1,
                  defaultValue: 3,
                  span: 'narrow',
                },
                {
                  fieldKey: 'columnsMobile',
                  type: 'number',
                  label: '移动端列数',
                  min: 1,
                  max: 12,
                  step: 1,
                  defaultValue: 2,
                  span: 'narrow',
                },
              ],
            },
          ],
        },
      ],
    },
  ],
};
