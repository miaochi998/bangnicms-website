/**
 * fttp 下载中心列表页 PanelSchemaV1 schema（阶段 2 节点 C · C-D5）
 * -----------------------------------------------------------------------------
 * 接管自原 DownloadsListPageConfigForm.tsx（837 行手写）。
 *
 * Storage 形态（config.downloadsListPage）：
 *   {
 *     enabled,
 *     hero: { eyebrow/title/description/breadcrumbHome/breadcrumbCurrent: LT × 5 },
 *     tiles: { enabled, maxCount:number(3-6),
 *              categoryVisuals[]: { categoryKey:str, iconName:str, accent:str(color) } },
 *     filter: { allLabel/searchPlaceholder/leadingLabel: LT × 3 },
 *     table: { columnFile/Size/Updated/Actions/previewLabel/downloadLabel/
 *              downloadCountTemplate/totalTemplate: LT × 8,
 *              emptyMatch: { title:LT, resetLabel:LT } },
 *     infoPanels: { enabled, items[]: { iconName, title:LT, description:LT } },
 *     empty: { title:LT, description:LT },
 *   }
 *
 * helper 复用偏离登记（schema.ts 头注 + 完工汇报 §X）：
 *   - createCtaLinkObjectField 不复用：downloads-list 形态无 CTA 字段
 *     （启动指令档预期"Hero CtaLink"实测不匹配 · hero 无 buttonHref 字段）
 *
 * adapter 行为（fttp.downloads-list-page · postprocessDownloadsListPageWrite）：
 *   - 2 ListField items[].id 兜底（tiles.categoryVisuals / infoPanels.items）
 *   - 顶层浅 + section 嵌套 merge
 *   - LocalizedText 裸 { lang: str } 形态由 styled-localized-text-adapter passthrough
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

const ITEM_ID_FIELD = {
  fieldKey: 'id',
  type: 'text',
  label: 'ID（系统生成 · 请勿修改）',
  placeholder: '保存时自动补齐',
  span: 'narrow',
} as const;

export const DOWNLOADS_LIST_PAGE_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.downloads-list-page',
  version: 1,
  title: '下载中心列表页 · 配置',
  configPath: 'config.downloadsListPage',
  tabs: [
    {
      tabKey: 'hero',
      title: 'Hero',
      sections: [
        {
          sectionKey: 'master',
          title: '总开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用下载中心列表页',
              defaultValue: true,
              controlsChildren: true,
              span: 'narrow',
            },
          ],
        },
        {
          sectionKey: 'hero',
          title: 'Hero（标题 / 描述 / 面包屑）',
          fields: [
            {
              fieldKey: 'hero',
              type: 'object',
              label: 'Hero',
              span: 'full',
              fields: [
                { fieldKey: 'eyebrow', type: 'localizedText', label: '小标题', multiLang: true, span: 'wide' },
                { fieldKey: 'title', type: 'localizedText', label: '主标题', multiLang: true, span: 'wide' },
                {
                  fieldKey: 'description',
                  type: 'localizedText',
                  label: '描述（含 {total} 占位符）',
                  multiLang: true,
                  multiline: true,
                  span: 'full',
                },
                { fieldKey: 'breadcrumbHome', type: 'localizedText', label: '面包屑「首页」', multiLang: true, span: 'medium' },
                { fieldKey: 'breadcrumbCurrent', type: 'localizedText', label: '面包屑「资料下载」', multiLang: true, span: 'medium' },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'tiles',
      title: '分类大卡片',
      sections: [
        {
          sectionKey: 'tiles',
          title: '分类大卡片（动态聚合 · 最多 6 张）',
          fields: [
            {
              fieldKey: 'tiles',
              type: 'object',
              label: '分类大卡片',
              span: 'full',
              fields: [
                { fieldKey: 'enabled', type: 'switch', label: '启用分类卡', defaultValue: true, span: 'narrow' },
                {
                  fieldKey: 'maxCount',
                  type: 'number',
                  label: '最多显示几张（3-6）',
                  min: 3,
                  max: 6,
                  step: 1,
                  span: 'narrow',
                },
                {
                  fieldKey: 'categoryVisuals',
                  type: 'arrayOfObject',
                  label: '分类外观（按 categoryKey 配图标 + 强调色）',
                  description: 'categoryKey 必须与下载分类的 key 完全一致；accent 是 hex 或 CSS token。',
                  minItems: 0,
                  maxItems: 12,
                  itemTitleField: 'categoryKey',
                  addLabel: '添加分类外观',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      ITEM_ID_FIELD,
                      {
                        fieldKey: 'categoryKey',
                        type: 'text',
                        label: '分类 key（与下载分类的 key 一致）',
                        placeholder: 'datasheets',
                        span: 'narrow',
                      },
                      { fieldKey: 'iconName', type: 'icon', label: '图标（Lucide）', span: 'narrow' },
                      { fieldKey: 'accent', type: 'color', label: '强调色', span: 'narrow' },
                    ],
                  },
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'filterTable',
      title: '筛选 & 表格',
      sections: [
        {
          sectionKey: 'filter',
          title: 'Sticky 筛选条',
          fields: [
            {
              fieldKey: 'filter',
              type: 'object',
              label: '筛选',
              span: 'full',
              fields: [
                { fieldKey: 'allLabel', type: 'localizedText', label: '"全部" 按钮文案', multiLang: true, span: 'medium' },
                { fieldKey: 'searchPlaceholder', type: 'localizedText', label: '搜索框占位符', multiLang: true, span: 'wide' },
                { fieldKey: 'leadingLabel', type: 'localizedText', label: '前缀文字（如 "筛选："）', multiLang: true, span: 'medium' },
              ],
            },
          ],
        },
        {
          sectionKey: 'table',
          title: '4 列文件表格',
          fields: [
            {
              fieldKey: 'table',
              type: 'object',
              label: '表格',
              span: 'full',
              fields: [
                { fieldKey: 'columnFile', type: 'localizedText', label: '"文件"列', multiLang: true, span: 'medium' },
                { fieldKey: 'columnSize', type: 'localizedText', label: '"大小"列', multiLang: true, span: 'medium' },
                { fieldKey: 'columnUpdated', type: 'localizedText', label: '"更新"列', multiLang: true, span: 'medium' },
                { fieldKey: 'columnActions', type: 'localizedText', label: '"操作"列', multiLang: true, span: 'medium' },
                { fieldKey: 'previewLabel', type: 'localizedText', label: '"预览" 按钮', multiLang: true, span: 'medium' },
                { fieldKey: 'downloadLabel', type: 'localizedText', label: '"下载" 按钮', multiLang: true, span: 'medium' },
                {
                  fieldKey: 'downloadCountTemplate',
                  type: 'localizedText',
                  label: '下载计数模板（含 {count}）',
                  multiLang: true,
                  span: 'wide',
                },
                {
                  fieldKey: 'totalTemplate',
                  type: 'localizedText',
                  label: '汇总模板（含 {total}/{filtered}）',
                  multiLang: true,
                  span: 'wide',
                },
                {
                  fieldKey: 'emptyMatch',
                  type: 'object',
                  label: '无匹配空态',
                  span: 'full',
                  fields: [
                    { fieldKey: 'title', type: 'localizedText', label: '标题', multiLang: true, span: 'wide' },
                    { fieldKey: 'resetLabel', type: 'localizedText', label: '"重置筛选" 按钮', multiLang: true, span: 'wide' },
                  ],
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'infoEmpty',
      title: '信息面板 & 空态',
      sections: [
        {
          sectionKey: 'infoPanels',
          title: '底部 3 张 InfoPanel',
          fields: [
            {
              fieldKey: 'infoPanels',
              type: 'object',
              label: '信息面板',
              span: 'full',
              fields: [
                { fieldKey: 'enabled', type: 'switch', label: '启用底部信息面板', defaultValue: true, span: 'narrow' },
                {
                  fieldKey: 'items',
                  type: 'arrayOfObject',
                  label: '信息面板项（建议 3 项）',
                  minItems: 0,
                  maxItems: 6,
                  itemTitleField: 'title',
                  addLabel: '添加信息面板',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      ITEM_ID_FIELD,
                      { fieldKey: 'iconName', type: 'icon', label: '图标（Lucide）', span: 'narrow' },
                      { fieldKey: 'title', type: 'localizedText', label: '标题', multiLang: true, span: 'wide' },
                      { fieldKey: 'description', type: 'localizedText', label: '描述', multiLang: true, multiline: true, span: 'full' },
                    ],
                  },
                },
              ],
            },
          ],
        },
        {
          sectionKey: 'empty',
          title: '整页空态（无任何下载时）',
          fields: [
            {
              fieldKey: 'empty',
              type: 'object',
              label: '空态',
              span: 'full',
              fields: [
                { fieldKey: 'title', type: 'localizedText', label: '标题', multiLang: true, span: 'wide' },
                { fieldKey: 'description', type: 'localizedText', label: '描述', multiLang: true, multiline: true, span: 'full' },
              ],
            },
          ],
        },
      ],
    },
  ],
};
