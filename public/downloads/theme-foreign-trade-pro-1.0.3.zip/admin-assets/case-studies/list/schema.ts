/**
 * fttp 解决方案 · 列表页 PanelSchemaV1 schema（阶段 2 节点 A · A-D4 试水 1）
 * -----------------------------------------------------------------------------
 * 接管自原 CaseStudiesListConfigForm.tsx（422 行手写）。
 *
 * Storage 形态（FttpCaseStudiesListPageConfig · config.caseStudiesListPage）：
 *   {
 *     enabled,
 *     hero: { title, subtitle, ctaLabel },        // 全部 LocalizedText
 *     heroStats: [{ n, l }, ...]                  // 1-8 项 · n/l 都是 LocalizedText
 *     featuredEyebrow,                            // LocalizedText
 *     featuredBadge,                              // LocalizedText
 *     featuredReadMoreLabel,                      // LocalizedText
 *     countLabelTemplate,                         // LocalizedText（含 {n} 占位）
 *     cardReadMoreLabel,                          // LocalizedText
 *   }
 *
 * 形态特点：
 *   - **全标准 PanelSchemaV1 LocalizedString 形态**（`{ [lang]: string }`）
 *   - 无 fttp 历史污染（无 per-field { translations, style } / per-lang 反向嵌套）
 *   - createFttpStorageAdapter('fttp.case-studies-list') 走 default 分支
 *     （preprocessRead passthrough + postprocessWrite 浅 merge 保留 prev）
 *
 * 节点 A 试水范围：
 *   - 不暴露任何 TextStyle / 颜色字段（原 ConfigForm 也未暴露 · 形态确实简单）
 *   - heroStats arrayOfObject 用 itemTitleField='l'（标签作为 itemRow 标题）
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

export const CASE_STUDIES_LIST_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.case-studies-list',
  version: 1,
  previewAdapter: 'fttp.case-studies-list',
  title: '解决方案 · 列表页',
  configPath: 'config.caseStudiesListPage',
  tabs: [
    {
      tabKey: 'hero',
      title: 'Hero · 总开关',
      sections: [
        {
          sectionKey: 'master',
          title: '整块开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用本页面',
              description: '关闭后前台 /case-studies 渲染为空。',
              defaultValue: true,
              controlsChildren: true,
              span: 'narrow',
            },
          ],
        },
        {
          sectionKey: 'hero',
          title: 'Hero 头部文案',
          description: '主标题中可使用 {n} 占位符 → 前台自动替换为案例总数。',
          fields: [
            {
              fieldKey: 'hero',
              type: 'object',
              label: 'Hero',
              span: 'full',
              fields: [
                {
                  fieldKey: 'title',
                  type: 'localizedText',
                  label: '主标题（含 {n} 占位）',
                  multiLang: true,
                  required: true,
                  multiline: true,
                  span: 'wide',
                },
                {
                  fieldKey: 'subtitle',
                  type: 'localizedText',
                  label: '副标题',
                  multiLang: true,
                  multiline: true,
                  span: 'full',
                },
                {
                  fieldKey: 'ctaLabel',
                  type: 'localizedText',
                  label: 'Hero CTA 按钮文字',
                  multiLang: true,
                  span: 'wide',
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'stats',
      title: '顶部数字',
      sections: [
        {
          sectionKey: 'stats',
          title: '4 大数字 heroStats',
          description: '1-8 项；前 4 项前台横排；超出可在前台改版后扩展。',
          fields: [
            {
              fieldKey: 'heroStats',
              type: 'arrayOfObject',
              label: '数据项',
              minItems: 1,
              maxItems: 8,
              itemTitleField: 'l',
              addLabel: '添加一项数据',
              span: 'full',
              itemSchema: {
                fields: [
                  {
                    fieldKey: 'n',
                    type: 'localizedText',
                    label: '数字',
                    placeholder: '120+',
                    multiLang: true,
                    required: true,
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'l',
                    type: 'localizedText',
                    label: '标签',
                    placeholder: '已交付国家',
                    multiLang: true,
                    required: true,
                    span: 'wide',
                  },
                ],
              },
            },
          ],
        },
      ],
    },
    {
      tabKey: 'featured',
      title: '精选块',
      sections: [
        {
          sectionKey: 'featured',
          title: '精选案例块文案',
          fields: [
            {
              fieldKey: 'featuredEyebrow',
              type: 'localizedText',
              label: '精选块小标签',
              multiLang: true,
              span: 'wide',
            },
            {
              fieldKey: 'featuredBadge',
              type: 'localizedText',
              label: '精选块大图右上角徽章',
              multiLang: true,
              span: 'wide',
            },
            {
              fieldKey: 'featuredReadMoreLabel',
              type: 'localizedText',
              label: '精选块"阅读完整案例"按钮',
              multiLang: true,
              span: 'wide',
            },
          ],
        },
      ],
    },
    {
      tabKey: 'list',
      title: '列表卡',
      sections: [
        {
          sectionKey: 'list',
          title: '列表卡文案',
          description: 'countLabelTemplate 中 {n} 占位符 → 前台自动替换为案例总数。',
          fields: [
            {
              fieldKey: 'countLabelTemplate',
              type: 'localizedText',
              label: '总数文案模板（含 {n}）',
              placeholder: '共 {n} 个案例',
              multiLang: true,
              span: 'wide',
            },
            {
              fieldKey: 'cardReadMoreLabel',
              type: 'localizedText',
              label: '列表卡 CTA 文字',
              placeholder: '查看案例',
              multiLang: true,
              span: 'wide',
            },
          ],
        },
      ],
    },
  ],
};
