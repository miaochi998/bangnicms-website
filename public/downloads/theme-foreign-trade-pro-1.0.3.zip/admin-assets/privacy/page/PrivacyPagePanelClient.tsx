'use client';

/**
 * PrivacyPagePanelClient · 节点 C commit-1b-β
 * -----------------------------------------------------------------------------
 * page.tsx 是 Server Component；adapter 工厂函数对象不能跨 server→client，
 * 故在 client 侧 createFttpStorageAdapter('fttp.privacy-page') 后渲染。
 */

import { PanelRenderer } from '@/components/panel-renderer';
import { createFttpStorageAdapter } from '@bangnicms-theme/foreign-trade-pro/admin-assets/_storage-adapter';
import { PRIVACY_PAGE_PANEL } from './schema';

interface LangOption {
  code: string;
  name: string;
}

export function PrivacyPagePanelClient({
  apiBase,
  extensionId,
  themeKey,
  themeName,
  initialData,
  languages,
  defaultLang,
  aiAvailable,
}: {
  apiBase: string;
  extensionId: string;
  themeKey: string;
  themeName: string;
  initialData: Record<string, unknown> | undefined;
  languages: LangOption[];
  defaultLang: string;
  aiAvailable: boolean;
}) {
  return (
    <PanelRenderer
      apiBase={apiBase}
      extensionId={extensionId}
      themeKey={themeKey}
      themeName={themeName}
      panel={PRIVACY_PAGE_PANEL}
      initialData={initialData}
      languages={languages}
      defaultLang={defaultLang}
      aiAvailable={aiAvailable}
      dataAdapter={createFttpStorageAdapter(PRIVACY_PAGE_PANEL.panelKey)}
    />
  );
}
