import type { PanelDescriptor } from '../../_types';
import { QualityPagePanelClient } from './QualityPagePanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'quality/page',
  configKey: 'qualityPage',
  title: '质量管控页',
  description: '配置 /quality 质量管控页：Hero 页头 + 4 个关键指标横幅 + 7 阶段 QC 流程时间线（含工具列表）+ 检测设备网格。所有文案多语言；运营可改字号、颜色、背景。',
  dataPage: 'theme-config-fttp-quality-page',
  notApplicableTestId: 'quality-page-not-applicable',
  guardMode: 'theme-key',
  PanelClient: QualityPagePanelClient,
};
