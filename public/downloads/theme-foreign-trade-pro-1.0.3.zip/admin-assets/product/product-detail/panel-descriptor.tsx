import type { PanelDescriptor } from '../../_types';
import { ProductDetailPagePanelClient } from './ProductDetailPagePanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'product/product-detail',
  configKey: 'productDetailPage',
  title: '产品详情页',
  description: '配置 /products/:slug 产品详情页：面包屑 + 主图廊 + 主信息 + CTA 按钮 + 5 Tab（描述 / 规格 / 包装 / 认证 / FAQ）+ 底部 CTA + 相关产品。所有「框架文案」多语言。产品本身数据（标题/描述/图片/规格/认证/FAQ）来自产品编辑页（含 fttp-product-detail 模型包扩展字段）。',
  dataPage: 'theme-config-fttp-product-detail-page',
  notApplicableTestId: 'product-detail-page-not-applicable',
  guardMode: 'theme-key',
  PanelClient: ProductDetailPagePanelClient,
};
