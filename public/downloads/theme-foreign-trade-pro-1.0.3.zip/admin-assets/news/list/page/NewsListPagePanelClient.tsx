'use client';

/**
 * NewsListPagePanelClient · 阶段 2 节点 B · B-D3
 * 薄壳 client wrapper；page.tsx 是 Server Component。
 */

import { PanelRenderer } from '@/components/panel-renderer';
import { createFttpStorageAdapter } from '@bangnicms-theme/foreign-trade-pro/admin-assets/_storage-adapter';
import { NEWS_LIST_PAGE_PANEL } from './schema';

interface LangOption {
  code: string;
  name: string;
}

export function NewsListPagePanelClient({
  apiBase,
  extensionId,
  themeKey,
  themeName,
  initialData,
  languages,
  defaultLang,
  aiAvailable,
}: {
  apiBase: string;
  extensionId: string;
  themeKey: string;
  themeName: string;
  initialData: Record<string, unknown> | undefined;
  languages: LangOption[];
  defaultLang: string;
  aiAvailable: boolean;
}) {
  return (
    <PanelRenderer
      apiBase={apiBase}
      extensionId={extensionId}
      themeKey={themeKey}
      themeName={themeName}
      panel={NEWS_LIST_PAGE_PANEL}
      initialData={initialData}
      languages={languages}
      defaultLang={defaultLang}
      aiAvailable={aiAvailable}
      dataAdapter={createFttpStorageAdapter(NEWS_LIST_PAGE_PANEL.panelKey, { defaultLang })}
    />
  );
}
