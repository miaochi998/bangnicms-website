import type { PanelDescriptor } from '../../_types';
import { AboutPagePanelClient } from './AboutPagePanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'about/page',
  configKey: 'aboutPage',
  title: '关于我们页',
  description: '配置 /about 关于我们页：Hero（深色面包屑 + 标题/副标题 + 关键数据卡）+ 公司故事 + 核心价值观（4 卡）+ 时间线（关键里程碑）+ 团队（4 卡）+ CTA 卡。所有文案多语言。',
  dataPage: 'theme-config-fttp-about-page',
  notApplicableTestId: 'about-page-not-applicable',
  guardMode: 'theme-key',
  PanelClient: AboutPagePanelClient,
};
