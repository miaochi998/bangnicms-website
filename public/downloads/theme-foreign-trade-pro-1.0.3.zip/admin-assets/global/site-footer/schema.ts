/**
 * fttp 网站页脚 PanelSchemaV1 schema（阶段 2 节点 B · B-D2）
 * -----------------------------------------------------------------------------
 * 接管自原 SiteFooterConfigForm.tsx（732 行手写）。
 *
 * Storage 形态（BangNiCmsThemeSiteFooterConfig · config.siteFooter）：
 *   {
 *     enabled,
 *     newsletter: { enabled, submitMode:'inquiry'|'external', externalAction?, fieldName, successRedirectUrl? },
 *     contact: {
 *       enabled,
 *       items:        [{id, icon, type?, text, localizedText?, href?, enabled}, ...],
 *       socialLinks:  [{id, platform, url, label?, icon?, openInNewTab?, enabled}, ...],
 *     },
 *     bottomStrip: {
 *       enabled,
 *       legalLinks: [{id, labelTranslations?, labelI18nKey?, label?, link:CtaLink, enabled}, ...],
 *       showTradeTerms,
 *       tradeTerms: string[],
 *     },
 *     style: { newsletterBg, mainFooterBg, bottomStripBg, primaryTextColor?, mutedTextColor? },
 *   }
 *
 * helper 复用：
 *   - createCtaLinkObjectField × 1（legalLinks[].link）
 *   - tagInput 原语首场实战（bottomStrip.tradeTerms · maxItems=12）
 *
 * 与 site-header 命名差异：
 *   - contact.items[].text + localizedText（footer）vs 头部 label + labelTranslations
 *     adapter 内 syncSiteFooterContactText 处理 footer 命名 · 不能复用 site-header sync。
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';
import { createCtaLinkObjectField } from '@/components/panel-renderer/field-factories';

const ITEM_ID_FIELD = {
  fieldKey: 'id',
  type: 'text',
  label: 'ID（系统生成 · 请勿修改）',
  placeholder: '保存时自动补齐',
  span: 'narrow',
} as const;

export const SITE_FOOTER_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.site-footer',
  version: 1,
  title: '网站页脚 · 配置',
  configPath: 'config.siteFooter',
  tabs: [
    {
      tabKey: 'newsletter',
      title: '订阅',
      sections: [
        {
          sectionKey: 'master',
          title: '总开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用站点页脚',
              description: '关闭后整个站点页脚不显示。',
              defaultValue: true,
              controlsChildren: true,
              span: 'narrow',
            },
          ],
        },
        {
          sectionKey: 'newsletter',
          title: '订阅表单（newsletter）',
          fields: [
            {
              fieldKey: 'newsletter',
              type: 'object',
              label: '订阅设置',
              span: 'full',
              fields: [
                {
                  fieldKey: 'enabled',
                  type: 'switch',
                  label: '启用订阅表单',
                  defaultValue: false,
                  span: 'wide',
                },
                {
                  fieldKey: 'submitMode',
                  type: 'select',
                  label: '订阅数据的提交方式',
                  defaultValue: 'inquiry',
                  options: [
                    { value: 'inquiry', label: '存入本系统询盘模块（默认推荐）' },
                    { value: 'external', label: '提交到外部邮件服务（如 Mailchimp / SendGrid）' },
                  ],
                  span: 'wide',
                },
                {
                  fieldKey: 'externalAction',
                  type: 'text',
                  label: '外部邮件服务的提交网址（仅 submitMode=external 时使用）',
                  placeholder: 'https://example.mailchimp.com/subscribe/post',
                  span: 'full',
                },
                {
                  fieldKey: 'fieldName',
                  type: 'text',
                  label: '外部服务要求的 Email 表单字段名',
                  placeholder: 'email（默认）/ EMAIL / mce-EMAIL（Mailchimp）',
                  defaultValue: 'email',
                  span: 'wide',
                },
                {
                  fieldKey: 'successRedirectUrl',
                  type: 'text',
                  label: '订阅成功后跳转到的网址（可留空）',
                  placeholder: '留空则就地显示成功提示，不跳转',
                  span: 'wide',
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'contact',
      title: '联系 & 社交',
      sections: [
        {
          sectionKey: 'contact',
          title: '联系方式 + 社交媒体',
          fields: [
            {
              fieldKey: 'contact',
              type: 'object',
              label: '联系方式块',
              span: 'full',
              fields: [
                {
                  fieldKey: 'enabled',
                  type: 'switch',
                  label: '显示联系方式区块',
                  defaultValue: true,
                  span: 'wide',
                },
                {
                  fieldKey: 'items',
                  type: 'arrayOfObject',
                  label: '联系方式列表',
                  description: '地址 / 电话 / 邮箱 / 自定义；至多 6 项。',
                  minItems: 0,
                  maxItems: 6,
                  itemTitleField: 'localizedText',
                  addLabel: '添加一项联系方式',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      ITEM_ID_FIELD,
                      {
                        fieldKey: 'type',
                        type: 'select',
                        label: '类型',
                        defaultValue: 'custom',
                        options: [
                          { value: 'address', label: '地址' },
                          { value: 'phone', label: '电话' },
                          { value: 'email', label: 'Email' },
                          { value: 'custom', label: '自定义' },
                        ],
                        span: 'narrow',
                      },
                      {
                        fieldKey: 'icon',
                        type: 'icon',
                        label: '图标（Lucide 名称）',
                        span: 'narrow',
                      },
                      {
                        fieldKey: 'localizedText',
                        type: 'localizedText',
                        label: '显示文字（多语言）',
                        description: '地址、电话通常各语言相同；客服时间等说明文字可翻译。',
                        multiLang: true,
                        span: 'wide',
                      },
                      {
                        fieldKey: 'href',
                        type: 'text',
                        label: '点击跳转（mailto: / tel: / https: / 留空 = 纯展示）',
                        placeholder: 'mailto:sales@example.com',
                        span: 'wide',
                      },
                      {
                        fieldKey: 'enabled',
                        type: 'switch',
                        label: '启用此项',
                        defaultValue: true,
                        span: 'narrow',
                      },
                    ],
                  },
                },
                {
                  fieldKey: 'socialLinks',
                  type: 'arrayOfObject',
                  label: '社交媒体',
                  description: '至多 10 项；platform=custom 时需填 icon + label。',
                  minItems: 0,
                  maxItems: 10,
                  itemTitleField: 'platform',
                  addLabel: '添加一项社交媒体',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      ITEM_ID_FIELD,
                      {
                        fieldKey: 'platform',
                        type: 'select',
                        label: '平台',
                        defaultValue: 'custom',
                        options: [
                          { value: 'facebook', label: 'Facebook' },
                          { value: 'twitter', label: 'Twitter / X' },
                          { value: 'linkedin', label: 'LinkedIn' },
                          { value: 'youtube', label: 'YouTube' },
                          { value: 'instagram', label: 'Instagram' },
                          { value: 'tiktok', label: 'TikTok' },
                          { value: 'wechat', label: '微信' },
                          { value: 'whatsapp', label: 'WhatsApp' },
                          { value: 'telegram', label: 'Telegram' },
                          { value: 'custom', label: '自定义' },
                        ],
                        span: 'narrow',
                      },
                      {
                        fieldKey: 'url',
                        type: 'text',
                        label: '主页网址',
                        placeholder: 'https://facebook.com/yourbrand',
                        span: 'wide',
                      },
                      {
                        fieldKey: 'icon',
                        type: 'icon',
                        label: '图标（custom 时必填，来自 Lucide）',
                        span: 'narrow',
                      },
                      {
                        fieldKey: 'label',
                        type: 'text',
                        label: '无障碍说明文字（custom 时必填）',
                        placeholder: '如：我们的小红书',
                        span: 'wide',
                      },
                      {
                        fieldKey: 'openInNewTab',
                        type: 'switch',
                        label: '点击后在新窗口打开',
                        defaultValue: true,
                        span: 'narrow',
                      },
                      {
                        fieldKey: 'enabled',
                        type: 'switch',
                        label: '启用此项',
                        defaultValue: true,
                        span: 'narrow',
                      },
                    ],
                  },
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'bottom',
      title: '底部条',
      sections: [
        {
          sectionKey: 'bottomStrip',
          title: '版权条（合规链接 + 贸易方式）',
          fields: [
            {
              fieldKey: 'bottomStrip',
              type: 'object',
              label: '底部条',
              span: 'full',
              fields: [
                {
                  fieldKey: 'enabled',
                  type: 'switch',
                  label: '显示最底部的版权条',
                  defaultValue: true,
                  span: 'wide',
                },
                {
                  fieldKey: 'legalLinks',
                  type: 'arrayOfObject',
                  label: '合规 / 法律链接',
                  description: '至多 6 项；CtaLink 9 类跳转目标。',
                  minItems: 0,
                  maxItems: 6,
                  itemTitleField: 'labelTranslations',
                  addLabel: '添加一项合规链接',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      ITEM_ID_FIELD,
                      {
                        fieldKey: 'labelTranslations',
                        type: 'localizedText',
                        label: '链接文字（多语言）',
                        description: '例如「隐私政策」/「Privacy Policy」；点 AI 翻译可补齐其他语言。',
                        multiLang: true,
                        span: 'wide',
                      },
                      {
                        fieldKey: 'labelI18nKey',
                        type: 'text',
                        label: '系统语言包 key（高级 · 仅内置预置项使用）',
                        description: '当上面文字全部留空时按语言包查找。例如 footer.privacyPolicy。',
                        placeholder: 'footer.privacyPolicy',
                        span: 'wide',
                      },
                      createCtaLinkObjectField({
                        fieldKey: 'link',
                        label: '点击跳转目标（CtaLink）',
                        defaultType: 'url',
                      }),
                      {
                        fieldKey: 'enabled',
                        type: 'switch',
                        label: '启用此项',
                        defaultValue: true,
                        span: 'narrow',
                      },
                    ],
                  },
                },
                {
                  fieldKey: 'showTradeTerms',
                  type: 'switch',
                  label: '显示贸易方式徽章（如 T/T、L/C、FOB 等外贸结算方式）',
                  defaultValue: true,
                  span: 'wide',
                },
                {
                  fieldKey: 'tradeTerms',
                  type: 'tagInput',
                  label: '贸易方式（自由标签输入）',
                  description: '回车 / 逗号分隔每一项。最多 12 项。',
                  inputPlaceholder: '如：T/T, L/C, FOB...',
                  maxItems: 12,
                  span: 'full',
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'style',
      title: '样式',
      sections: [
        {
          sectionKey: 'style',
          title: '页脚配色',
          fields: [
            {
              fieldKey: 'style',
              type: 'object',
              label: '页脚配色',
              span: 'full',
              fields: [
                {
                  fieldKey: 'newsletterBg',
                  type: 'color',
                  label: '订阅区背景色',
                  span: 'narrow',
                },
                {
                  fieldKey: 'mainFooterBg',
                  type: 'color',
                  label: '主页脚背景色',
                  span: 'narrow',
                },
                {
                  fieldKey: 'bottomStripBg',
                  type: 'color',
                  label: '底部条背景色',
                  span: 'narrow',
                },
                {
                  fieldKey: 'primaryTextColor',
                  type: 'color',
                  label: '主文字色（可选 · 留空用默认）',
                  span: 'narrow',
                },
                {
                  fieldKey: 'mutedTextColor',
                  type: 'color',
                  label: '次文字色（可选 · 留空用默认）',
                  span: 'narrow',
                },
              ],
            },
          ],
        },
      ],
    },
  ],
};
