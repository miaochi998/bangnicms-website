/**
 * fttp 新闻详情页 PanelSchemaV1 schema（阶段 2 节点 B · B-D4）
 * -----------------------------------------------------------------------------
 * 接管自原 NewsDetailPageConfigForm.tsx（639 行手写）。
 *
 * Storage 形态（config.newsDetailPage · 与 themes/.../NewsDetailPage.tsx 对齐）：
 *   {
 *     enabled, categoriesAsTags,
 *     hero: { breadcrumbHome, breadcrumbList } 2 LT,
 *     meta: { enabled, showCategories, shareLabel, shareTwitter, shareLinkedin,
 *             shareFacebook, shareCopy } 5 LT + 2 bool,
 *     body: { tocEnabled, tocLabel, emptyLabel, style:'default'|'minimal' },
 *     shareSidebar: { enabled, label, shareTwitter, shareLinkedin, shareFacebook,
 *                     shareMail, shareCopy },
 *     related: { enabled, eyebrow, title, readLabel,
 *                strategy:'same-category'|'latest', limit:number },
 *     missing: { title, backLabel },
 *   }
 *
 * 启动指令档预期 richText.multiLang=true 首场实战 → 实测 schema 不匹配：
 *   - 文章 body 由文章数据本身提供（HTML），面板只配置 toc / share / 相关文章 UI
 *   - 无需 richText 字段
 * 节点 B 完工汇报 §X 登记此发现。
 *
 * 形态特点：纯 LocalizedText + bool + select，storage 与 schema 1:1 对齐，
 * createFttpStorageAdapter 走 default 分支（仅浅 merge 保留 prev）。
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

export const NEWS_DETAIL_PAGE_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.news-detail-page',
  version: 1,
  title: '新闻详情页',
  configPath: 'config.newsDetailPage',
  tabs: [
    {
      tabKey: 'basic',
      title: '基础',
      sections: [
        {
          sectionKey: 'master',
          title: '总开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用新闻详情页',
              description: '关闭后前台 /news/:slug 渲染为空。',
              defaultValue: true,
              controlsChildren: true,
              span: 'narrow',
            },
          ],
        },
        {
          sectionKey: 'tags',
          title: '底部展示文章分类标签',
          fields: [
            {
              fieldKey: 'categoriesAsTags',
              type: 'switch',
              label: '在正文末尾以 #标签 形式展示文章分类',
              description: '关闭则隐藏。',
              defaultValue: true,
              span: 'wide',
            },
          ],
        },
        {
          sectionKey: 'missing',
          title: '文章不存在时的提示面板',
          description: '当用户访问的文章 ID 不存在或已下架时，页面显示的友好提示。',
          fields: [
            {
              fieldKey: 'missing',
              type: 'object',
              label: '错误提示',
              span: 'full',
              fields: [
                { fieldKey: 'title', type: 'localizedText', label: '标题', multiLang: true, span: 'wide' },
                { fieldKey: 'backLabel', type: 'localizedText', label: '返回按钮文案', multiLang: true, span: 'wide' },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'hero-meta',
      title: 'Hero & Meta',
      sections: [
        {
          sectionKey: 'hero',
          title: '面包屑导航',
          description: '文章标题与摘要由系统自动从文章数据获取；这里只配置面包屑链接的多语言文案。',
          fields: [
            {
              fieldKey: 'hero',
              type: 'object',
              label: 'Hero',
              span: 'full',
              fields: [
                { fieldKey: 'breadcrumbHome', type: 'localizedText', label: '面包屑「首页」文案', multiLang: true, span: 'wide' },
                { fieldKey: 'breadcrumbList', type: 'localizedText', label: '面包屑「新闻」文案', multiLang: true, span: 'wide' },
              ],
            },
          ],
        },
        {
          sectionKey: 'meta',
          title: 'Meta 信息条 · 顶部分享',
          fields: [
            {
              fieldKey: 'meta',
              type: 'object',
              label: 'Meta',
              span: 'full',
              fields: [
                { fieldKey: 'enabled', type: 'switch', label: '显示 Meta 信息条', defaultValue: true, span: 'wide' },
                { fieldKey: 'showCategories', type: 'switch', label: '在 Meta 条中显示分类标签', defaultValue: true, span: 'wide' },
                { fieldKey: 'shareLabel', type: 'localizedText', label: '"分享：" 前缀文字', multiLang: true, span: 'wide' },
                { fieldKey: 'shareTwitter', type: 'localizedText', label: 'Twitter 按钮文案', multiLang: true, span: 'medium' },
                { fieldKey: 'shareLinkedin', type: 'localizedText', label: 'LinkedIn 按钮文案', multiLang: true, span: 'medium' },
                { fieldKey: 'shareFacebook', type: 'localizedText', label: 'Facebook 按钮文案', multiLang: true, span: 'medium' },
                { fieldKey: 'shareCopy', type: 'localizedText', label: '复制链接按钮文案', multiLang: true, span: 'medium' },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'body',
      title: '正文 & 目录',
      sections: [
        {
          sectionKey: 'body',
          title: '文章目录',
          description: '开启后系统自动从二级标题（H2）生成目录。',
          fields: [
            {
              fieldKey: 'body',
              type: 'object',
              label: '正文 & 目录',
              span: 'full',
              fields: [
                { fieldKey: 'tocEnabled', type: 'switch', label: '启用文章目录', defaultValue: true, span: 'wide' },
                { fieldKey: 'tocLabel', type: 'localizedText', label: '目录标题', multiLang: true, span: 'wide' },
                { fieldKey: 'emptyLabel', type: 'localizedText', label: '正文为空时的提示', multiLang: true, span: 'wide' },
                {
                  fieldKey: 'style',
                  type: 'select',
                  label: '正文排版风格',
                  defaultValue: 'default',
                  options: [
                    { value: 'default', label: '标准（标题带左侧装饰条 + 引用块带背景）' },
                    { value: 'minimal', label: '极简（无装饰条 + 引用块斜体）' },
                  ],
                  span: 'wide',
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'related',
      title: '相关文章 & 侧栏分享',
      sections: [
        {
          sectionKey: 'related',
          title: '相关文章',
          fields: [
            {
              fieldKey: 'related',
              type: 'object',
              label: '相关文章',
              span: 'full',
              fields: [
                { fieldKey: 'enabled', type: 'switch', label: '启用相关文章', defaultValue: true, span: 'wide' },
                { fieldKey: 'eyebrow', type: 'localizedText', label: '小标题（顶部高亮短句）', multiLang: true, span: 'wide' },
                { fieldKey: 'title', type: 'localizedText', label: '主标题', multiLang: true, span: 'wide' },
                { fieldKey: 'readLabel', type: 'localizedText', label: '阅读按钮文案', multiLang: true, span: 'wide' },
                {
                  fieldKey: 'strategy',
                  type: 'select',
                  label: '推荐方式',
                  defaultValue: 'same-category',
                  options: [
                    { value: 'same-category', label: '同分类优先（数量不足时补最新）' },
                    { value: 'latest', label: '推荐最新文章' },
                  ],
                  span: 'wide',
                },
                {
                  fieldKey: 'limit',
                  type: 'number',
                  label: '显示数量',
                  defaultValue: 3,
                  min: 1,
                  max: 50,
                  span: 'narrow',
                },
              ],
            },
          ],
        },
        {
          sectionKey: 'shareSidebar',
          title: '侧栏 · 分享本文',
          fields: [
            {
              fieldKey: 'shareSidebar',
              type: 'object',
              label: '侧栏分享',
              span: 'full',
              fields: [
                { fieldKey: 'enabled', type: 'switch', label: '启用侧栏分享', defaultValue: true, span: 'wide' },
                { fieldKey: 'label', type: 'localizedText', label: '"分享本文" 标题', multiLang: true, span: 'wide' },
                { fieldKey: 'shareTwitter', type: 'localizedText', label: 'Twitter 按钮文案', multiLang: true, span: 'medium' },
                { fieldKey: 'shareLinkedin', type: 'localizedText', label: 'LinkedIn 按钮文案', multiLang: true, span: 'medium' },
                { fieldKey: 'shareFacebook', type: 'localizedText', label: 'Facebook 按钮文案', multiLang: true, span: 'medium' },
                { fieldKey: 'shareMail', type: 'localizedText', label: '邮件按钮文案', multiLang: true, span: 'medium' },
                { fieldKey: 'shareCopy', type: 'localizedText', label: '复制链接按钮文案', multiLang: true, span: 'medium' },
              ],
            },
          ],
        },
      ],
    },
  ],
};
