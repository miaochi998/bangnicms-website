import type { PanelDescriptor } from '../../_types';
import { ClientsPanelClient } from './ClientsPanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'homepage/clients',
  configKey: 'clients',
  title: '首页 · 全球客户与品牌信任',
  description: '复合区：左栏（头部 A + 地区占比 B + 底部数据 C）+ 右栏（头部 D + Logo 墙 E + 额外 Logo F + 证言 G）。',
  dataPage: 'theme-config-fttp-clients',
  notApplicableTestId: 'clients-not-applicable',
  guardMode: 'theme-key',
  PanelClient: ClientsPanelClient,
};
