import type { PanelDescriptor } from '../../_types';
import { SiteFooterPanelClient } from './SiteFooterPanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'global/site-footer',
  configKey: 'siteFooter',
  title: '全站 · 网站页脚（Site Footer）',
  description: '配置 4 区块 Footer：① 订阅卡片 ② 联系/链接 4 列 ③ 底部条带 ④ 整体样式。所有文案多语言；启用语言由「语言管理」决定。',
  dataPage: 'theme-config-fttp-site-footer',
  notApplicableTestId: 'site-footer-not-applicable',
  guardMode: 'theme-key',
  PanelClient: SiteFooterPanelClient,
};
