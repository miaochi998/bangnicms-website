import Link from 'next/link';
import { Package } from 'lucide-react';
import type { PanelDescriptor } from '../../_types';
import { FeaturedProductsPanelClient } from './FeaturedProductsPanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'homepage/featured-products',
  configKey: 'featuredProducts',
  title: '首页精选产品 · 配置',
  description: '本页只配置区块外观（标题/样式/布局/按钮文案）。要指定哪些产品上首页、产品徽章/能力标签，请到「产品管理 → 产品编辑 → 首页展示」字段组设置。',
  dataPage: 'theme-config-featured-products',
  guardMode: 'theme-key',
  PanelClient: FeaturedProductsPanelClient,
  breadcrumbExtras: (
    <Link
      href="/products"
      className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
    >
      <Package className="h-3.5 w-3.5" />
      到产品管理页挑选推荐产品
    </Link>
  ),
};
