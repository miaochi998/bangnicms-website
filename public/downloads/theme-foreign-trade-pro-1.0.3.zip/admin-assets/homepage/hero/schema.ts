/**
 * fttp 首页 Hero 大图 PanelSchemaV1 schema（节点 C commit-1b-β · S2.3）
 * -----------------------------------------------------------------------------
 * 接管自原 HeroConfigForm.tsx。fttp hero 数据形态是 fttp 私有 v2 扁平结构
 * （非 shared-types BangNiCmsThemeHeroConfig 的 v3 slides[] 形态）：
 *   {
 *     enabled, backgroundImage, backgroundImageOpacity, backgroundOverlayStrength,
 *     eyebrow / titlePrimary / titleAccent / description: { [lang]: string },  // 标准 LocalizedString
 *     bullets: [{ id, text: { [lang]: string } }],
 *     primaryCta / secondaryCta: { label: { [lang]: string }, href },
 *     trustStats: [{ id, value, label: { [lang]: string } }],
 *     featuredCard: { enabled, sourceBadge, fallbackStrategy, showPlayButton, detailsLabel, inquireLabel },
 *     sideSlides: [{ id, enabled, sourceBadge, subtitleSource, ..., ctaLabel: { [lang]: string } }],
 *   }
 *
 * 适配：fttp adapter `postprocessHeroWrite` 给 bullets/trustStats/sideSlides
 * 数组项补 id 兜底；其它字段走 identity（标准 LocalizedString 直通）。
 *
 * 已知节点 C 退化（节点 D 入账 / 阶段 2 处理）：
 *   - sideSlides.bgPreset 用文本输入而非 select（主题 preset 列表未沉淀）
 *   - 不暴露 textStyle 子字段（PanelSchemaV1 暂无 textStyle 原语）
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

export const HERO_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.hero',
  version: 1,
  previewAdapter: 'fttp.hero',
  title: '首页 · Hero 大图',
  configPath: 'config.hero',
  tabs: [
    {
      tabKey: 'background',
      title: '总开关 · 背景',
      sections: [
        {
          sectionKey: 'master',
          title: '整块开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用首页 Hero 大图',
              defaultValue: true,
              controlsChildren: true,
              span: 'full',
            },
          ],
        },
        {
          sectionKey: 'background',
          title: '背景视觉',
          description: '背景图片 + 蒙层强度调节，影响整屏视觉氛围。',
          fields: [
            {
              fieldKey: 'backgroundImage',
              type: 'mediaPicker',
              label: '背景图片',
              accept: ['image'],
              span: 'full',
            },
            {
              fieldKey: 'backgroundImageOpacity',
              type: 'number',
              label: '背景图片透明度（0-100）',
              description: '数字越小图片越淡，叠加在主背景色之上。',
              min: 0,
              max: 100,
              step: 5,
              defaultValue: 25,
              span: 'narrow',
            },
            {
              fieldKey: 'backgroundOverlayStrength',
              type: 'number',
              label: '蒙层暗度（0-100）',
              description: '数字越大图片越暗，便于文字阅读。',
              min: 0,
              max: 100,
              step: 5,
              defaultValue: 90,
              span: 'narrow',
            },
          ],
        },
      ],
    },
    {
      tabKey: 'copy',
      title: '文案 · 要点',
      sections: [
        {
          sectionKey: 'copy',
          title: '主文案',
          description: '4 段三语文本：小眉题 / 主标前段 / 主标重点段 / 描述。',
          fields: [
            {
              fieldKey: 'eyebrow',
              type: 'localizedText',
              label: '小眉题（eyebrow）',
              multiLang: true,
              placeholder: '值得信赖的全球制造商',
              span: 'wide',
            },
            {
              fieldKey: 'titlePrimary',
              type: 'localizedText',
              label: '主标题前段（titlePrimary）',
              multiLang: true,
              required: true,
              placeholder: '精品出口，',
              span: 'wide',
            },
            {
              fieldKey: 'titleAccent',
              type: 'localizedText',
              label: '主标题重点段（titleAccent）',
              description: '用品牌强调色高亮显示。',
              multiLang: true,
              required: true,
              placeholder: '工厂直供',
              span: 'wide',
            },
            {
              fieldKey: 'description',
              type: 'localizedText',
              label: '描述段（description）',
              multiLang: true,
              placeholder: '服务 60+ 国家与地区的 500+ 进口商……',
              span: 'full',
            },
          ],
        },
        {
          sectionKey: 'bullets',
          title: '要点列表（bullets）',
          description: '主文案下方的"勾"式要点；至少 1 项 / 最多 8 项。',
          fields: [
            {
              fieldKey: 'bullets',
              type: 'arrayOfObject',
              label: '要点项',
              minItems: 1,
              maxItems: 8,
              itemTitleField: 'text.zh-CN',
              addLabel: '添加一个要点',
              span: 'full',
              itemSchema: {
                fields: [
                  {
                    fieldKey: 'id',
                    type: 'text',
                    label: '稳定标识 ID',
                    description: '用于前台数据钩子；保留默认值，新建项可留空。',
                    placeholder: 'b-experience',
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'text',
                    type: 'localizedText',
                    label: '要点文案',
                    multiLang: true,
                    required: true,
                    placeholder: '20+ 年制造行业经验',
                    span: 'full',
                  },
                ],
              },
            },
          ],
        },
      ],
    },
    {
      tabKey: 'cta',
      title: '行动按钮 · 信任数据',
      sections: [
        {
          sectionKey: 'cta',
          title: '行动按钮（CTA）',
          description: '主按钮通常引导询盘、副按钮引导下载或视频。href 为相对路径或锚点（如 /products / #inquiry）。',
          fields: [
            {
              fieldKey: 'primaryCta',
              type: 'object',
              label: '主按钮',
              span: 'full',
              fields: [
                {
                  fieldKey: 'label',
                  type: 'localizedText',
                  label: '按钮文字',
                  multiLang: true,
                  required: true,
                  placeholder: '免费获取报价',
                  span: 'wide',
                },
                {
                  fieldKey: 'href',
                  type: 'text',
                  label: '跳转目标',
                  placeholder: '#inquiry',
                  defaultValue: '#inquiry',
                  span: 'wide',
                },
              ],
            },
            {
              fieldKey: 'secondaryCta',
              type: 'object',
              label: '副按钮（可选；按钮文字全空则不渲染）',
              span: 'full',
              fields: [
                {
                  fieldKey: 'label',
                  type: 'localizedText',
                  label: '按钮文字',
                  multiLang: true,
                  placeholder: '下载产品目录',
                  span: 'wide',
                },
                {
                  fieldKey: 'href',
                  type: 'text',
                  label: '跳转目标',
                  placeholder: '/downloads',
                  span: 'wide',
                },
              ],
            },
          ],
        },
        {
          sectionKey: 'trustStats',
          title: '信任数据（trustStats）',
          description: '主按钮下方的数据条；最多 8 项，每项含数字（单语）+ 标签（三语）。',
          fields: [
            {
              fieldKey: 'trustStats',
              type: 'arrayOfObject',
              label: '数据项',
              minItems: 0,
              maxItems: 8,
              itemTitleField: 'value',
              addLabel: '添加一项数据',
              span: 'full',
              itemSchema: {
                fields: [
                  {
                    fieldKey: 'id',
                    type: 'text',
                    label: '稳定标识 ID',
                    description: '用于前台数据钩子；保留默认值，新建项可留空。',
                    placeholder: 'years',
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'value',
                    type: 'text',
                    label: '数字 / 大字（value · 单语）',
                    placeholder: '60+',
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'label',
                    type: 'localizedText',
                    label: '标签（label）',
                    multiLang: true,
                    required: true,
                    placeholder: '国家',
                    span: 'wide',
                  },
                ],
              },
            },
          ],
        },
      ],
    },
    {
      tabKey: 'cards',
      title: '旗舰产品 · 侧栏推广',
      sections: [
        {
          sectionKey: 'featuredCard',
          title: '旗舰产品卡（featuredCard）',
          description: '右侧主推产品卡片，按 badge 字符串自动从产品库读取。',
          fields: [
            {
              fieldKey: 'featuredCard',
              type: 'object',
              label: '旗舰产品卡',
              span: 'full',
              fields: [
                {
                  fieldKey: 'enabled',
                  type: 'switch',
                  label: '启用旗舰产品卡',
                  defaultValue: true,
                  span: 'narrow',
                },
                {
                  fieldKey: 'sourceBadge',
                  type: 'text',
                  label: '匹配标签（sourceBadge）',
                  description: '产品「customFields.badge」等于此值的会被选中作为旗舰卡。',
                  placeholder: '旗舰产品',
                  defaultValue: '旗舰产品',
                  span: 'wide',
                },
                {
                  fieldKey: 'fallbackStrategy',
                  type: 'select',
                  label: '兜底策略（标签无匹配时）',
                  options: [
                    { value: 'isFeatured-first', label: '取「精选产品」中的第一条' },
                    { value: 'latest', label: '取最新发布的产品' },
                    { value: 'none', label: '不显示卡片' },
                  ],
                  defaultValue: 'isFeatured-first',
                  span: 'wide',
                },
                {
                  fieldKey: 'showPlayButton',
                  type: 'switch',
                  label: '显示播放按钮装饰',
                  defaultValue: true,
                  span: 'narrow',
                },
                {
                  fieldKey: 'detailsLabel',
                  type: 'localizedText',
                  label: '详情按钮文字',
                  multiLang: true,
                  placeholder: '详情',
                  span: 'wide',
                },
                {
                  fieldKey: 'inquireLabel',
                  type: 'localizedText',
                  label: '询价按钮文字',
                  multiLang: true,
                  placeholder: '立即询价',
                  span: 'wide',
                },
              ],
            },
          ],
        },
        {
          sectionKey: 'sideSlides',
          title: '侧栏推广卡（sideSlides）',
          description: '旗舰产品卡下方的小推广卡列表；每张按 badge 自动从产品库匹配。',
          fields: [
            {
              fieldKey: 'sideSlides',
              type: 'arrayOfObject',
              label: '推广卡',
              minItems: 0,
              maxItems: 4,
              itemTitleField: 'sourceBadge',
              addLabel: '添加一张推广卡',
              span: 'full',
              itemSchema: {
                fields: [
                  {
                    fieldKey: 'id',
                    type: 'text',
                    label: '稳定标识 ID',
                    description: '用于前台数据钩子；保留默认值，新建项可留空。',
                    placeholder: 'new-coffee',
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'enabled',
                    type: 'switch',
                    label: '启用',
                    defaultValue: true,
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'sourceBadge',
                    type: 'text',
                    label: '匹配标签',
                    placeholder: '新品上线',
                    span: 'wide',
                  },
                  {
                    fieldKey: 'subtitleSource',
                    type: 'select',
                    label: '副标题来源',
                    options: [
                      { value: 'capabilities', label: '产品能力标签' },
                      { value: 'description', label: '产品描述' },
                      { value: 'none', label: '不显示副标题' },
                    ],
                    defaultValue: 'capabilities',
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'capabilitiesSeparator',
                    type: 'text',
                    label: '能力标签分隔符',
                    placeholder: ' · ',
                    defaultValue: ' · ',
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'capabilitiesMaxCount',
                    type: 'number',
                    label: '能力标签最多展示数',
                    min: 1,
                    max: 8,
                    step: 1,
                    defaultValue: 2,
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'bgPreset',
                    type: 'text',
                    label: '背景预设（bgPreset）',
                    description: '主题内置预设：navy / accent / orange 等；具体可用值见主题文档。',
                    placeholder: 'navy',
                    defaultValue: 'navy',
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'overlayOpacity',
                    type: 'number',
                    label: '遮罩透明度 0-1',
                    min: 0,
                    max: 1,
                    step: 0.05,
                    defaultValue: 0.5,
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'overlayDirection',
                    type: 'select',
                    label: '遮罩方向',
                    options: [
                      { value: 'left-to-right', label: '从左到右' },
                      { value: 'right-to-left', label: '从右到左' },
                      { value: 'top-to-bottom', label: '从上到下' },
                      { value: 'bottom-to-top', label: '从下到上' },
                    ],
                    defaultValue: 'left-to-right',
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'ctaLabel',
                    type: 'localizedText',
                    label: 'CTA 按钮文字',
                    multiLang: true,
                    placeholder: '查看详情',
                    span: 'wide',
                  },
                ],
              },
            },
          ],
        },
      ],
    },
  ],
};
