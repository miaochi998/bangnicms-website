/**
 * fttp 首页「我们的工厂」PanelSchemaV1 schema（节点 B D-B1 · S2.4）
 * -----------------------------------------------------------------------------
 * 接管自原 FactoryConfigForm.tsx（783 行手写）。
 *
 * Storage 形态（BangNiCmsThemeFactoryConfig · config.factory）：
 *   {
 *     enabled,
 *     header: { eyebrow, title, description }（全多语言）,
 *     hero: {
 *       media: { type:'image'|'video', image, video, poster },
 *       alt, videoTagline, videoDuration,
 *       overlayBadge: { value, label }
 *     },
 *     stats: [{ id, value, label }],
 *     thumbnails: string[],
 *     style: { 9 段 TextStyle }
 *   }
 *
 * 节点 B 范围降级（已在节点 C / 阶段 2 入账）：
 *   - `thumbnails` 存储形态 `string[]` vs PanelSchemaV1 仅支持对象数组 →
 *     通过 adapter preprocessRead/postprocessWrite 做 `string[] ↔ [{id,url}]` 互转
 *   - `hero.media.{image,video,poster}` 前台消费纯 string URL；mediaPicker 默认
 *     onChange 产生 `{url,focalPoint?}` 对象 → 通过 adapter write 字段级降级为 string
 *   - `style` 9 段（eyebrow/title/description/videoTagline/videoDuration/
 *     badgeValue/badgeLabel/statValue/statLabel）**不暴露**（UI 优化类，留节点 D）；
 *     从 prev 透传保留
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

export const FACTORY_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.factory',
  version: 1,
  previewAdapter: 'fttp.factory',
  title: '首页 · 我们的工厂',
  configPath: 'config.factory',
  tabs: [
    {
      tabKey: 'overview',
      title: '总开关 · 头部',
      sections: [
        {
          sectionKey: 'master',
          title: '整块开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用本区块',
              description: '关闭后首页不渲染「我们的工厂」区块。',
              defaultValue: true,
              controlsChildren: true,
              span: 'narrow',
            },
          ],
        },
        {
          sectionKey: 'header',
          title: '区块头部（小眉题 / 标题 / 描述）',
          fields: [
            {
              fieldKey: 'header',
              type: 'object',
              label: '头部文案',
              span: 'full',
              fields: [
                {
                  fieldKey: 'eyebrow',
                  type: 'localizedText',
                  label: '小眉题',
                  multiLang: true,
                  placeholder: '我们的工厂',
                  span: 'wide',
                },
                {
                  fieldKey: 'title',
                  type: 'localizedText',
                  label: '主标题',
                  multiLang: true,
                  required: true,
                  placeholder: '一流生产基地 · 品质由源头护航',
                  span: 'wide',
                },
                {
                  fieldKey: 'description',
                  type: 'localizedText',
                  label: '描述',
                  multiLang: true,
                  placeholder: '占地 80,000㎡ 的现代化园区……',
                  span: 'full',
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'hero',
      title: '主视觉 Hero',
      sections: [
        {
          sectionKey: 'hero',
          title: '主视觉（图片 / 视频）',
          description: '「图片或视频」二选一；选择视频时请同步上传封面 poster。',
          fields: [
            {
              fieldKey: 'hero',
              type: 'object',
              label: 'Hero',
              span: 'full',
              fields: [
                {
                  fieldKey: 'media',
                  type: 'object',
                  label: '媒体',
                  span: 'full',
                  fields: [
                    {
                      fieldKey: 'type',
                      type: 'select',
                      label: '媒体类型',
                      options: [
                        { value: 'image', label: '图片' },
                        { value: 'video', label: '视频' },
                      ],
                      defaultValue: 'image',
                      span: 'narrow',
                    },
                    {
                      fieldKey: 'image',
                      type: 'mediaPicker',
                      label: '图片（type=image 时使用）',
                      accept: ['image'],
                      span: 'wide',
                    },
                    {
                      fieldKey: 'video',
                      type: 'mediaPicker',
                      label: '视频（type=video 时使用）',
                      accept: ['video'],
                      span: 'wide',
                    },
                    {
                      fieldKey: 'poster',
                      type: 'mediaPicker',
                      label: '视频封面 poster',
                      accept: ['image'],
                      span: 'wide',
                    },
                  ],
                },
                {
                  fieldKey: 'alt',
                  type: 'localizedText',
                  label: 'Alt 文案（无障碍）',
                  multiLang: true,
                  placeholder: '工厂全景',
                  span: 'wide',
                },
                {
                  fieldKey: 'videoTagline',
                  type: 'localizedText',
                  label: '视频标语（小字）',
                  multiLang: true,
                  placeholder: '360° 工厂漫游',
                  span: 'wide',
                },
                {
                  fieldKey: 'videoDuration',
                  type: 'localizedText',
                  label: '视频时长说明',
                  multiLang: true,
                  placeholder: '观看 2 分钟视频',
                  span: 'wide',
                },
                {
                  fieldKey: 'overlayBadge',
                  type: 'object',
                  label: '浮动数据徽章（右下角）',
                  span: 'full',
                  fields: [
                    {
                      fieldKey: 'value',
                      type: 'text',
                      label: '数值（不翻译）',
                      placeholder: 'ISO 9001',
                      span: 'narrow',
                    },
                    {
                      fieldKey: 'label',
                      type: 'localizedText',
                      label: '说明文案',
                      multiLang: true,
                      placeholder: '国际质量认证',
                      span: 'wide',
                    },
                  ],
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'stats',
      title: '数据统计',
      sections: [
        {
          sectionKey: 'stats',
          title: '数据列表',
          fields: [
            {
              fieldKey: 'stats',
              type: 'arrayOfObject',
              label: '数据项',
              minItems: 0,
              maxItems: 8,
              itemTitleField: 'value',
              addLabel: '添加一项',
              span: 'full',
              itemSchema: {
                fields: [
                  {
                    fieldKey: 'id',
                    type: 'text',
                    label: 'ID（稳定唯一）',
                    placeholder: 'stat-xxx',
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'value',
                    type: 'text',
                    label: '数值（不翻译 · 如 "80,000㎡"）',
                    placeholder: '80,000㎡',
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'label',
                    type: 'localizedText',
                    label: '标签',
                    multiLang: true,
                    required: true,
                    placeholder: '园区占地面积',
                    span: 'wide',
                  },
                ],
              },
            },
          ],
        },
      ],
    },
    {
      tabKey: 'thumbnails',
      title: '缩略图墙',
      sections: [
        {
          sectionKey: 'thumbnails',
          title: '缩略图（前台点击放大）',
          description: '纯 URL 数组；adapter 自动拍平为对象数组渲染，保存时归并回 URL 数组。',
          fields: [
            {
              fieldKey: 'thumbnails',
              type: 'arrayOfObject',
              label: '缩略图',
              minItems: 0,
              maxItems: 8,
              itemTitleField: 'url',
              addLabel: '添加一张缩略图',
              span: 'full',
              itemSchema: {
                fields: [
                  {
                    fieldKey: 'id',
                    type: 'text',
                    label: 'ID',
                    placeholder: 'thumb-xxx',
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'url',
                    type: 'mediaPicker',
                    label: '图片',
                    accept: ['image'],
                    span: 'wide',
                  },
                ],
              },
            },
          ],
        },
      ],
    },
  ],
};
