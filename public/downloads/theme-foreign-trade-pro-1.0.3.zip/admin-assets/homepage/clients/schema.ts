/**
 * fttp 首页「全球客户与品牌信任」PanelSchemaV1 schema（节点 B D-B3 · S2.4）
 * -----------------------------------------------------------------------------
 * 接管自原 ClientsConfigForm.tsx（1442 行）。
 *
 * Storage 形态 BangNiCmsThemeClientsConfig（标准形态 · 无特殊包装）：
 *   { enabled, header, rightHeader, regions[], bottomStats[],
 *     logos[], extraLogos[], testimonials[],
 *     regionBarStyle, logoWallStyle, testimonialStyle, style }
 *
 * 节点 B 范围降级：
 *   - `regionBarStyle` / `logoWallStyle` / `testimonialStyle` / `style`（4 段样式）
 *     **不暴露**（UI 优化类，留节点 D）→ adapter 默认 merge 从 prev 透传保留
 *   - `logos[i].image` 暂用 `text` 字段存 URL（不提供上传按钮；阶段 2 / 节点 D
 *     升级为 mediaPicker + adapter 降级）
 *   - `testimonialStyle.carousel*` 等轮播参数不暴露（同样 prev 透传）
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

export const CLIENTS_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.clients',
  version: 1,
  previewAdapter: 'fttp.clients',
  title: '首页 · 全球客户与品牌信任',
  configPath: 'config.clients',
  tabs: [
    {
      tabKey: 'overview',
      title: '总开关 · 头部',
      sections: [
        {
          sectionKey: 'master',
          title: '整块开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用本区块',
              defaultValue: true,
              controlsChildren: true,
              span: 'narrow',
            },
          ],
        },
        {
          sectionKey: 'header',
          title: '左栏头部（A）',
          fields: [
            {
              fieldKey: 'header',
              type: 'object',
              label: '左头部',
              span: 'full',
              fields: [
                {
                  fieldKey: 'eyebrow',
                  type: 'localizedText',
                  label: '小眉题',
                  multiLang: true,
                  placeholder: '全球覆盖',
                  span: 'wide',
                },
                {
                  fieldKey: 'title',
                  type: 'localizedText',
                  label: '主标题',
                  multiLang: true,
                  required: true,
                  span: 'wide',
                },
                {
                  fieldKey: 'description',
                  type: 'localizedText',
                  label: '描述',
                  multiLang: true,
                  span: 'full',
                },
              ],
            },
          ],
        },
        {
          sectionKey: 'rightHeader',
          title: '右栏头部（D）',
          fields: [
            {
              fieldKey: 'rightHeader',
              type: 'object',
              label: '右头部',
              span: 'full',
              fields: [
                {
                  fieldKey: 'title',
                  type: 'localizedText',
                  label: '右标题',
                  multiLang: true,
                  span: 'wide',
                },
                {
                  fieldKey: 'description',
                  type: 'localizedText',
                  label: '右描述',
                  multiLang: true,
                  span: 'full',
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'regions',
      title: '地区分布（B）',
      sections: [
        {
          sectionKey: 'regions',
          title: '地区占比列表',
          fields: [
            {
              fieldKey: 'regions',
              type: 'arrayOfObject',
              label: '地区项',
              minItems: 0,
              maxItems: 12,
              itemTitleField: 'area.zh-CN',
              addLabel: '添加一个地区',
              span: 'full',
              itemSchema: {
                fields: [
                  { fieldKey: 'id', type: 'text', label: 'ID', span: 'narrow' },
                  {
                    fieldKey: 'area',
                    type: 'localizedText',
                    label: '地区名',
                    multiLang: true,
                    required: true,
                    span: 'wide',
                  },
                  {
                    fieldKey: 'pct',
                    type: 'number',
                    label: '占比（0-100）',
                    min: 0,
                    max: 100,
                    step: 1,
                    defaultValue: 0,
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'countries',
                    type: 'localizedText',
                    label: '国家描述',
                    multiLang: true,
                    placeholder: '美国 · 加拿大 · 墨西哥',
                    span: 'full',
                  },
                ],
              },
            },
          ],
        },
      ],
    },
    {
      tabKey: 'bottomStats',
      title: '底部小数据（C）',
      sections: [
        {
          sectionKey: 'bottomStats',
          title: '底部统计项',
          description: '图标字段暂采用 object 形态（kind + name / url）；留 kind="none" 则不显示。',
          fields: [
            {
              fieldKey: 'bottomStats',
              type: 'arrayOfObject',
              label: '统计项',
              minItems: 0,
              maxItems: 12,
              itemTitleField: 'value',
              addLabel: '添加一项',
              span: 'full',
              itemSchema: {
                fields: [
                  { fieldKey: 'id', type: 'text', label: 'ID', span: 'narrow' },
                  { fieldKey: 'value', type: 'text', label: '数值（不翻译）', span: 'narrow' },
                  {
                    fieldKey: 'label',
                    type: 'localizedText',
                    label: '标签',
                    multiLang: true,
                    required: true,
                    span: 'wide',
                  },
                  {
                    fieldKey: 'icon',
                    type: 'object',
                    label: '图标',
                    span: 'full',
                    fields: [
                      {
                        fieldKey: 'kind',
                        type: 'select',
                        label: '类型',
                        options: [
                          { value: 'lucide', label: 'Lucide 图标' },
                          { value: 'image', label: '图片 URL' },
                          { value: 'none', label: '不显示' },
                        ],
                        defaultValue: 'lucide',
                        span: 'narrow',
                      },
                      {
                        fieldKey: 'name',
                        type: 'text',
                        label: 'Lucide 图标名（kind=lucide 时）',
                        placeholder: 'Globe',
                        span: 'narrow',
                      },
                      {
                        fieldKey: 'url',
                        type: 'text',
                        label: '图片 URL（kind=image 时）',
                        span: 'wide',
                      },
                    ],
                  },
                ],
              },
            },
          ],
        },
      ],
    },
    {
      tabKey: 'logos',
      title: 'Logo 墙（E）',
      sections: [
        {
          sectionKey: 'logos',
          title: '主 Logo 列表',
          description: 'image 为 URL（可留空则渲染 textFallback）。节点 B 暂用文本输入；阶段 2 升级为上传器。',
          fields: [
            {
              fieldKey: 'logos',
              type: 'arrayOfObject',
              label: 'Logo',
              minItems: 0,
              maxItems: 20,
              itemTitleField: 'textFallback.zh-CN',
              addLabel: '添加一个 Logo',
              span: 'full',
              itemSchema: {
                fields: [
                  { fieldKey: 'id', type: 'text', label: 'ID', span: 'narrow' },
                  { fieldKey: 'image', type: 'text', label: '图片 URL（可留空）', span: 'wide' },
                  {
                    fieldKey: 'textFallback',
                    type: 'localizedText',
                    label: '文字降级',
                    multiLang: true,
                    required: true,
                    span: 'wide',
                  },
                  { fieldKey: 'href', type: 'text', label: '品牌官网链接（可留空）', span: 'wide' },
                ],
              },
            },
          ],
        },
        {
          sectionKey: 'extraLogos',
          title: '额外 Logo 标签条（F）',
          fields: [
            {
              fieldKey: 'extraLogos',
              type: 'arrayOfObject',
              label: '额外标签',
              minItems: 0,
              maxItems: 20,
              itemTitleField: 'label.zh-CN',
              addLabel: '添加一个标签',
              span: 'full',
              itemSchema: {
                fields: [
                  { fieldKey: 'id', type: 'text', label: 'ID', span: 'narrow' },
                  {
                    fieldKey: 'label',
                    type: 'localizedText',
                    label: '标签',
                    multiLang: true,
                    required: true,
                    span: 'wide',
                  },
                ],
              },
            },
          ],
        },
      ],
    },
    {
      tabKey: 'testimonials',
      title: '客户证言（G）',
      sections: [
        {
          sectionKey: 'testimonials',
          title: '证言列表',
          fields: [
            {
              fieldKey: 'testimonials',
              type: 'arrayOfObject',
              label: '证言',
              minItems: 0,
              maxItems: 20,
              itemTitleField: 'authorName.zh-CN',
              addLabel: '添加一条证言',
              span: 'full',
              itemSchema: {
                fields: [
                  { fieldKey: 'id', type: 'text', label: 'ID', span: 'narrow' },
                  {
                    fieldKey: 'quote',
                    type: 'localizedText',
                    label: '引文',
                    multiLang: true,
                    required: true,
                    span: 'full',
                  },
                  {
                    fieldKey: 'authorInitials',
                    type: 'text',
                    label: '作者首字母（不翻译）',
                    placeholder: 'JD',
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'authorName',
                    type: 'localizedText',
                    label: '作者姓名',
                    multiLang: true,
                    span: 'wide',
                  },
                  {
                    fieldKey: 'authorTitle',
                    type: 'localizedText',
                    label: '作者职位',
                    multiLang: true,
                    span: 'wide',
                  },
                ],
              },
            },
          ],
        },
      ],
    },
  ],
};
