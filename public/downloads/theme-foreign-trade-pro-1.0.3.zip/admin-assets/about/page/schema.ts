/**
 * fttp 关于我们页 PanelSchemaV1 schema（节点 C D-C2 · S2.4）
 * -----------------------------------------------------------------------------
 * 接管自原 AboutPageConfigForm.tsx（1700 行手写）。
 *
 * Storage 形态（FttpAboutPageConfig · config.aboutPage）：
 *   {
 *     enabled,
 *     hero: { breadcrumbLabel, title, subtitle, style },
 *     story: { eyebrow, title, body (HTML多语), media, cornerLabel, style },
 *     stats: { items[{id,value,label}], style },
 *     purpose: {
 *       eyebrow, title, description,
 *       mission: { icon, eyebrow, title, description, bullets[{id,text}] },
 *       vision:  { icon, eyebrow, title, description },
 *       values:  { items[{id, icon, title, description}] },
 *       style
 *     },
 *     timeline: { eyebrow, title, description, items[{id, year, title, description}], style }
 *   }
 *
 * 节点 C 范围降级（节点 D / 阶段 2 入账）：
 *   - story.body 多语言富文本 → schema 仅 localizedText multiline（HTML 源码可见编辑）。
 *     原 RichTextEditor 体验丢失；阶段 2 PanelSchemaV1 加 localizedRichText 字段类型解决。
 *   - 各 section style（10+ TextStyle 段 + 多色）不暴露，从 prev 透传（adapter 嵌套 merge）。
 *   - icon `{kind, name, size?, color?}` 对象 → adapter 字段级 read/write 取 .name；prev 透传 size/color。
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

export const ABOUT_PAGE_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.about-page',
  version: 1,
  previewAdapter: 'fttp.about-page',
  title: '关于我们页',
  configPath: 'config.aboutPage',
  tabs: [
    {
      tabKey: 'overview',
      title: '总开关 · Hero',
      sections: [
        {
          sectionKey: 'master',
          title: '整块开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用本页面',
              description: '关闭后前台 /about 渲染为空。',
              defaultValue: true,
              controlsChildren: true,
              span: 'narrow',
            },
          ],
        },
        {
          sectionKey: 'hero',
          title: 'Hero 页头',
          fields: [
            {
              fieldKey: 'hero',
              type: 'object',
              label: 'Hero',
              span: 'full',
              fields: [
                { fieldKey: 'breadcrumbLabel', type: 'localizedText', label: '面包屑文字', multiLang: true, span: 'wide' },
                { fieldKey: 'title', type: 'localizedText', label: '主标题', multiLang: true, required: true, span: 'wide' },
                { fieldKey: 'subtitle', type: 'localizedText', label: '副标题', multiLang: true, span: 'full' },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'story',
      title: '公司故事',
      sections: [
        {
          sectionKey: 'story',
          title: '公司故事（多语言 HTML 正文）',
          description: 'body 字段以 HTML 多语言形式存储；可粘贴 <p>/<strong>/<br> 等富文本标记。',
          fields: [
            {
              fieldKey: 'story',
              type: 'object',
              label: '公司故事',
              span: 'full',
              fields: [
                { fieldKey: 'eyebrow', type: 'localizedText', label: '小眉题', multiLang: true, span: 'wide' },
                { fieldKey: 'title', type: 'localizedText', label: '主标题', multiLang: true, span: 'wide' },
                { fieldKey: 'body', type: 'localizedText', label: '正文（HTML 多语）', multiLang: true, multiline: true, span: 'full' },
                { fieldKey: 'media', type: 'mediaPicker', label: '配图（图/视频）', accept: ['image', 'video'], span: 'wide' },
                { fieldKey: 'cornerLabel', type: 'localizedText', label: '角标文字', multiLang: true, span: 'wide' },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'stats',
      title: '数据条',
      sections: [
        {
          sectionKey: 'stats',
          title: '数据条（多语言数值 + 标签）',
          fields: [
            {
              fieldKey: 'stats',
              type: 'object',
              label: '数据条',
              span: 'full',
              fields: [
                {
                  fieldKey: 'items',
                  type: 'arrayOfObject',
                  label: '数据项',
                  minItems: 0,
                  maxItems: 16,
                  itemTitleField: 'label',
                  addLabel: '添加一项数据',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      { fieldKey: 'id', type: 'text', label: 'ID', placeholder: 'stat-xxx', span: 'narrow' },
                      { fieldKey: 'value', type: 'localizedText', label: '数值', multiLang: true, required: true, span: 'wide' },
                      { fieldKey: 'label', type: 'localizedText', label: '标签', multiLang: true, required: true, span: 'wide' },
                    ],
                  },
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'purpose',
      title: '使命愿景价值观',
      sections: [
        {
          sectionKey: 'purpose-header',
          title: '宗旨 · 头部',
          fields: [
            {
              fieldKey: 'purpose',
              type: 'object',
              label: '宗旨',
              span: 'full',
              fields: [
                { fieldKey: 'eyebrow', type: 'localizedText', label: '小眉题', multiLang: true, span: 'wide' },
                { fieldKey: 'title', type: 'localizedText', label: '主标题', multiLang: true, span: 'wide' },
                { fieldKey: 'description', type: 'localizedText', label: '描述', multiLang: true, span: 'full' },
                {
                  fieldKey: 'mission',
                  type: 'object',
                  label: '使命',
                  span: 'full',
                  fields: [
                    { fieldKey: 'icon', type: 'icon', label: '图标', span: 'narrow' },
                    { fieldKey: 'eyebrow', type: 'localizedText', label: '小眉题', multiLang: true, span: 'wide' },
                    { fieldKey: 'title', type: 'localizedText', label: '标题', multiLang: true, span: 'wide' },
                    { fieldKey: 'description', type: 'localizedText', label: '描述', multiLang: true, span: 'full' },
                    {
                      fieldKey: 'bullets',
                      type: 'arrayOfObject',
                      label: '要点列表',
                      minItems: 0,
                      maxItems: 16,
                      itemTitleField: 'text',
                      addLabel: '添加一项要点',
                      span: 'full',
                      itemSchema: {
                        fields: [
                          { fieldKey: 'id', type: 'text', label: 'ID', placeholder: 'b-xxx', span: 'narrow' },
                          { fieldKey: 'text', type: 'localizedText', label: '文字', multiLang: true, required: true, span: 'wide' },
                        ],
                      },
                    },
                  ],
                },
                {
                  fieldKey: 'vision',
                  type: 'object',
                  label: '愿景',
                  span: 'full',
                  fields: [
                    { fieldKey: 'icon', type: 'icon', label: '图标', span: 'narrow' },
                    { fieldKey: 'eyebrow', type: 'localizedText', label: '小眉题', multiLang: true, span: 'wide' },
                    { fieldKey: 'title', type: 'localizedText', label: '标题', multiLang: true, span: 'wide' },
                    { fieldKey: 'description', type: 'localizedText', label: '描述', multiLang: true, span: 'full' },
                  ],
                },
                {
                  fieldKey: 'values',
                  type: 'object',
                  label: '价值观',
                  span: 'full',
                  fields: [
                    {
                      fieldKey: 'items',
                      type: 'arrayOfObject',
                      label: '价值观项',
                      minItems: 0,
                      maxItems: 12,
                      itemTitleField: 'title',
                      addLabel: '添加一项价值观',
                      span: 'full',
                      itemSchema: {
                        fields: [
                          { fieldKey: 'id', type: 'text', label: 'ID', placeholder: 'v-xxx', span: 'narrow' },
                          { fieldKey: 'icon', type: 'icon', label: '图标', span: 'narrow' },
                          { fieldKey: 'title', type: 'localizedText', label: '名称', multiLang: true, required: true, span: 'wide' },
                          { fieldKey: 'description', type: 'localizedText', label: '描述', multiLang: true, span: 'full' },
                        ],
                      },
                    },
                  ],
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'timeline',
      title: '发展历程',
      sections: [
        {
          sectionKey: 'timeline',
          title: '发展历程时间轴',
          fields: [
            {
              fieldKey: 'timeline',
              type: 'object',
              label: '时间轴',
              span: 'full',
              fields: [
                { fieldKey: 'eyebrow', type: 'localizedText', label: '小眉题', multiLang: true, span: 'wide' },
                { fieldKey: 'title', type: 'localizedText', label: '主标题', multiLang: true, span: 'wide' },
                { fieldKey: 'description', type: 'localizedText', label: '描述', multiLang: true, span: 'full' },
                {
                  fieldKey: 'items',
                  type: 'arrayOfObject',
                  label: '里程碑',
                  minItems: 0,
                  maxItems: 32,
                  itemTitleField: 'year',
                  addLabel: '添加一项里程碑',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      { fieldKey: 'id', type: 'text', label: 'ID', placeholder: 'm-xxx', span: 'narrow' },
                      { fieldKey: 'year', type: 'localizedText', label: '年份', multiLang: true, required: true, span: 'narrow' },
                      { fieldKey: 'title', type: 'localizedText', label: '标题', multiLang: true, required: true, span: 'wide' },
                      { fieldKey: 'description', type: 'localizedText', label: '描述', multiLang: true, span: 'full' },
                    ],
                  },
                },
              ],
            },
          ],
        },
      ],
    },
  ],
};
