import type { PanelDescriptor } from '../../_types';
import { InquiryCtaPanelClient } from './InquiryCtaPanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'homepage/inquiry-cta',
  configKey: 'inquiryCta',
  title: '首页 · 免费索取报价',
  description: '首页底部询盘 section 的「外壳」：左栏标题（eyebrow / 主标题 / 描述）+ 好处列表 + 联系方式列表（电话 / 邮箱 / WhatsApp 等）+ 视觉样式（背景色 / 表单卡背景色 / 文字样式）。**表单字段标签 / 提交按钮 / 同意条款等文案在「全站询盘表单」面板配置（首页 / 联系页共享）**。',
  dataPage: 'theme-config-fttp-inquiry-cta',
  guardMode: 'theme-key',
  PanelClient: InquiryCtaPanelClient,
};
