'use client';

/**
 * CaseStudyDetailPanelClient · 阶段 2 节点 A · A-D5 试水 2
 * 薄壳 client wrapper；page.tsx 是 Server Component。
 */

import { PanelRenderer } from '@/components/panel-renderer';
import { createFttpStorageAdapter } from '@bangnicms-theme/foreign-trade-pro/admin-assets/_storage-adapter';
import { CASE_STUDY_DETAIL_PANEL } from './schema';

interface LangOption {
  code: string;
  name: string;
}

export function CaseStudyDetailPanelClient({
  apiBase,
  extensionId,
  themeKey,
  themeName,
  initialData,
  languages,
  defaultLang,
  aiAvailable,
}: {
  apiBase: string;
  extensionId: string;
  themeKey: string;
  themeName: string;
  initialData: Record<string, unknown> | undefined;
  languages: LangOption[];
  defaultLang: string;
  aiAvailable: boolean;
}) {
  return (
    <PanelRenderer
      apiBase={apiBase}
      extensionId={extensionId}
      themeKey={themeKey}
      themeName={themeName}
      panel={CASE_STUDY_DETAIL_PANEL}
      initialData={initialData}
      languages={languages}
      defaultLang={defaultLang}
      aiAvailable={aiAvailable}
      dataAdapter={createFttpStorageAdapter(CASE_STUDY_DETAIL_PANEL.panelKey)}
    />
  );
}
