/**
 * fttp 站点地图页 PanelSchemaV1 schema（阶段 2 节点 C · C-D2）
 * -----------------------------------------------------------------------------
 * 接管自原 SitemapPageConfigForm.tsx（1496 行手写）。
 *
 * Storage 形态（config.sitemapPage）：
 *   {
 *     enabled,
 *     hero:           { eyebrow, title, subtitle } LT × 3
 *     searchPlaceholder: LT
 *     searchLabels:   { resultsCount, empty, templateBadge } LT × 3
 *     statsEnabled,
 *     stats[]:        异构（kind:'dynamic'|'custom'）
 *                     - dynamic: { kind:'dynamic', metric:'sectionsCount'|'nodesCount', label:LT }
 *                     - custom:  { kind:'custom', value:LT, label:LT }
 *     sections[]:     {
 *                       id:str, iconName:str(Lucide), tone:enum(brand/accent/...),
 *                       title:LT, blurb:LT,
 *                       items[]: {
 *                         label:LT, href:str, desc:LT,
 *                         children?: [{ label:LT, href:str, desc:LT }]   ← 第 3 层
 *                       }
 *                     }
 *     xmlEnabled, xmlCards[]: { iconName:str, href:str, title:LT, desc:LT }
 *     ctaEnabled, cta: { iconName:str, eyebrow:LT, title:LT, desc:LT,
 *                        buttonLabel:LT, buttonHref:str }
 *   }
 *
 * D1 硬限冲突 + UX 退化登记（§完工汇报 §X · 阶段 2 节点 D 评估）：
 *   - **sections.items.children 不在 schema 暴露**：原 storage 形态 sections →
 *     items → children 是 3 层 arrayOfObject 嵌套，违反 PanelSchemaV1 D1 决策
 *     "嵌套数组硬限 2 层"（validator.ts L432-444 显式拒绝）。降级方案：schema 仅
 *     暴露 sections + sections.items 两层，children 由 adapter postprocessWrite
 *     从 prev 透传保留（沿用 legal sections[].blocks passthrough 模式）。
 *     运营失去 children 编辑能力 → manifest defaultConfig 中既有 children 数据
 *     可保留，新增板块的 children 需开发者直接编辑 manifest。
 *
 *   - **stats kind 异构铺平**：原 storage stats[] 是 dynamic / custom 两种 kind
 *     的异构数组（PanelSchemaV1 arrayOfHeterogeneous 5 kind 锁死 D4 不兼容）。
 *     schema 用 arrayOfObject 全字段铺平 + kind select，运营按 kind 选取相应
 *     字段（同 CtaLink 9 字段铺平模式）。dynamic 时多余 value 字段不影响前台。
 *
 * helper 复用：
 *   - createCtaLinkObjectField · 不复用：cta.buttonHref 是裸 string（无 9 类 type）
 *
 * adapter 行为（fttp.sitemap-page · postprocessSitemapPageWrite）：
 *   - 4 ListField items[] 补 id 兜底（stats / sections / sections.items / xmlCards）
 *   - sections[i].items[j] 在 prev 中存在 children 时透传保留（schema 不暴露）
 *   - 顶层浅 merge 不损 prev 字段
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

const ITEM_ID_FIELD = {
  fieldKey: 'id',
  type: 'text',
  label: 'ID（系统生成 · 请勿修改）',
  placeholder: '保存时自动补齐',
  span: 'narrow',
} as const;

const TONE_OPTIONS = [
  { value: 'brand', label: 'Brand（品牌色）' },
  { value: 'accent', label: 'Accent（强调色）' },
  { value: 'green', label: 'Green' },
  { value: 'blue', label: 'Blue' },
  { value: 'purple', label: 'Purple' },
  { value: 'orange', label: 'Orange' },
];

const STAT_KIND_OPTIONS = [
  { value: 'dynamic', label: 'Dynamic（前台 SSR 自动计算）' },
  { value: 'custom', label: 'Custom（手填值）' },
];

const STAT_METRIC_OPTIONS = [
  { value: 'sectionsCount', label: '板块数（sectionsCount）' },
  { value: 'nodesCount', label: '页面节点总数（nodesCount）' },
];

export const SITEMAP_PAGE_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.sitemap-page',
  version: 1,
  title: '站点地图页 · 配置',
  configPath: 'config.sitemapPage',
  tabs: [
    {
      tabKey: 'hero',
      title: 'Hero & 搜索',
      sections: [
        {
          sectionKey: 'master',
          title: '总开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用站点地图页',
              description: '关闭后前台 /sitemap 渲染为空（与 fttp 其他独立页一致）。',
              defaultValue: true,
              controlsChildren: true,
              span: 'narrow',
            },
          ],
        },
        {
          sectionKey: 'hero',
          title: 'Hero 文案',
          fields: [
            {
              fieldKey: 'hero',
              type: 'object',
              label: 'Hero',
              span: 'full',
              fields: [
                { fieldKey: 'eyebrow', type: 'localizedText', label: '小标题', multiLang: true, span: 'wide' },
                { fieldKey: 'title', type: 'localizedText', label: '主标题', multiLang: true, span: 'wide' },
                { fieldKey: 'subtitle', type: 'localizedText', label: '副标题', multiLang: true, multiline: true, span: 'full' },
              ],
            },
          ],
        },
        {
          sectionKey: 'search',
          title: '搜索文案（4 段）',
          fields: [
            {
              fieldKey: 'searchPlaceholder',
              type: 'localizedText',
              label: '搜索框占位符',
              multiLang: true,
              span: 'wide',
            },
            {
              fieldKey: 'searchLabels',
              type: 'object',
              label: '搜索辅助文案',
              span: 'full',
              fields: [
                { fieldKey: 'resultsCount', type: 'localizedText', label: '结果数文案（如「找到 N 个匹配」）', multiLang: true, span: 'wide' },
                { fieldKey: 'empty', type: 'localizedText', label: '空结果文案', multiLang: true, span: 'wide' },
                { fieldKey: 'templateBadge', type: 'localizedText', label: '「模板」徽章', multiLang: true, span: 'medium' },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'stats',
      title: '统计条',
      sections: [
        {
          sectionKey: 'stats',
          title: '统计 4 项（dynamic 自动 / custom 手填 · 见 schema 头注）',
          description:
            'kind=dynamic 时填 metric+label，value 字段忽略；kind=custom 时填 value+label。',
          fields: [
            {
              fieldKey: 'statsEnabled',
              type: 'switch',
              label: '启用统计条',
              defaultValue: true,
              controlsChildren: true,
              span: 'narrow',
            },
            {
              fieldKey: 'stats',
              type: 'arrayOfObject',
              label: '统计项',
              minItems: 0,
              maxItems: 12,
              itemTitleField: 'label',
              addLabel: '添加统计项',
              span: 'full',
              itemSchema: {
                fields: [
                  ITEM_ID_FIELD,
                  {
                    fieldKey: 'kind',
                    type: 'select',
                    label: '类型',
                    defaultValue: 'custom',
                    options: STAT_KIND_OPTIONS,
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'metric',
                    type: 'select',
                    label: '动态指标（kind=dynamic 时使用）',
                    defaultValue: 'sectionsCount',
                    options: STAT_METRIC_OPTIONS,
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'value',
                    type: 'localizedText',
                    label: '数值（kind=custom 时使用）',
                    multiLang: true,
                    span: 'medium',
                  },
                  { fieldKey: 'label', type: 'localizedText', label: '说明文字', multiLang: true, span: 'wide' },
                ],
              },
            },
          ],
        },
      ],
    },
    {
      tabKey: 'sections',
      title: '板块 / 节点',
      sections: [
        {
          sectionKey: 'sections',
          title: '板块列表（含嵌套节点 · 子节点 children 由开发者维护，见 schema 头注）',
          fields: [
            {
              fieldKey: 'sections',
              type: 'arrayOfObject',
              label: '板块',
              minItems: 0,
              maxItems: 20,
              itemTitleField: 'title',
              addLabel: '添加板块',
              span: 'full',
              itemSchema: {
                fields: [
                  {
                    fieldKey: 'id',
                    type: 'text',
                    label: '板块 ID（前台 e2e 锚点 / 路由参数 · 半角字母数字）',
                    placeholder: '如 home / products / about',
                    span: 'narrow',
                  },
                  { fieldKey: 'iconName', type: 'icon', label: '图标（Lucide）', span: 'narrow' },
                  {
                    fieldKey: 'tone',
                    type: 'select',
                    label: '主色调',
                    defaultValue: 'brand',
                    options: TONE_OPTIONS,
                    span: 'narrow',
                  },
                  { fieldKey: 'title', type: 'localizedText', label: '标题', multiLang: true, span: 'wide' },
                  { fieldKey: 'blurb', type: 'localizedText', label: '简介', multiLang: true, multiline: true, span: 'full' },
                  {
                    fieldKey: 'items',
                    type: 'arrayOfObject',
                    label: '节点（页面入口）',
                    minItems: 0,
                    maxItems: 30,
                    itemTitleField: 'label',
                    addLabel: '添加节点',
                    span: 'full',
                    itemSchema: {
                      fields: [
                        ITEM_ID_FIELD,
                        { fieldKey: 'label', type: 'localizedText', label: '节点文字', multiLang: true, span: 'wide' },
                        {
                          fieldKey: 'href',
                          type: 'text',
                          label: '链接（站内路径 / 外链）',
                          placeholder: '/products',
                          span: 'wide',
                        },
                        { fieldKey: 'desc', type: 'localizedText', label: '描述', multiLang: true, multiline: true, span: 'full' },
                      ],
                    },
                  },
                ],
              },
            },
          ],
        },
      ],
    },
    {
      tabKey: 'xml',
      title: 'XML / RSS 卡',
      sections: [
        {
          sectionKey: 'xml',
          title: 'XML / RSS 资源卡',
          fields: [
            {
              fieldKey: 'xmlEnabled',
              type: 'switch',
              label: '启用 XML / RSS 卡',
              defaultValue: true,
              controlsChildren: true,
              span: 'narrow',
            },
            {
              fieldKey: 'xmlCards',
              type: 'arrayOfObject',
              label: '资源卡',
              minItems: 0,
              maxItems: 6,
              itemTitleField: 'title',
              addLabel: '添加资源卡',
              span: 'full',
              itemSchema: {
                fields: [
                  ITEM_ID_FIELD,
                  { fieldKey: 'iconName', type: 'icon', label: '图标（Lucide）', span: 'narrow' },
                  {
                    fieldKey: 'href',
                    type: 'text',
                    label: '链接（如 /sitemap.xml / /news/rss.xml）',
                    placeholder: '/sitemap.xml',
                    span: 'wide',
                  },
                  { fieldKey: 'title', type: 'localizedText', label: '标题', multiLang: true, span: 'wide' },
                  { fieldKey: 'desc', type: 'localizedText', label: '描述', multiLang: true, span: 'full' },
                ],
              },
            },
          ],
        },
      ],
    },
    {
      tabKey: 'cta',
      title: 'Contact CTA',
      sections: [
        {
          sectionKey: 'cta',
          title: 'CTA 卡',
          fields: [
            {
              fieldKey: 'ctaEnabled',
              type: 'switch',
              label: '启用 Contact CTA',
              defaultValue: true,
              controlsChildren: true,
              span: 'narrow',
            },
            {
              fieldKey: 'cta',
              type: 'object',
              label: 'CTA',
              span: 'full',
              fields: [
                { fieldKey: 'iconName', type: 'icon', label: '图标（Lucide）', span: 'narrow' },
                { fieldKey: 'eyebrow', type: 'localizedText', label: '小标题', multiLang: true, span: 'wide' },
                { fieldKey: 'title', type: 'localizedText', label: '主标题', multiLang: true, span: 'wide' },
                { fieldKey: 'desc', type: 'localizedText', label: '描述', multiLang: true, multiline: true, span: 'full' },
                { fieldKey: 'buttonLabel', type: 'localizedText', label: '按钮文字', multiLang: true, span: 'wide' },
                {
                  fieldKey: 'buttonHref',
                  type: 'text',
                  label: '按钮链接（单语 · 通常 /contact）',
                  placeholder: '/contact',
                  span: 'wide',
                },
              ],
            },
          ],
        },
      ],
    },
  ],
};
