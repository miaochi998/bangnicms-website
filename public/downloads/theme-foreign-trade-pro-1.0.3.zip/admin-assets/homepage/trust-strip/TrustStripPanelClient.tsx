'use client';

/**
 * TrustStripPanelClient · trust-strip 面板客户端 wrapper（节点 C commit-1a）
 * -----------------------------------------------------------------------------
 * page.tsx 是 Server Component（依赖 cookies() / fetchAdminApi）；PanelRenderer
 * 接受的 dataAdapter 是函数对象，跨 Server→Client boundary 时 Next.js 报
 * "Functions cannot be passed directly to Client Components"。
 *
 * 解决方案：本 client wrapper 在浏览器侧 createFttpStorageAdapter()，再渲染
 * PanelRenderer。架构上 page.tsx 仍是薄壳（裁决档 §2.1 D-C3 (A) 履约），
 * 仅多一个无状态 client 包装层。
 *
 * 节点 C commit-2 删除原 ConfigForm 时本文件保留；commit-1b 末尾或后续若把
 * 6 fttp page.tsx 统一为单一动态路由可考虑合并。
 */

import { PanelRenderer } from '@/components/panel-renderer';
import { createFttpStorageAdapter } from '@bangnicms-theme/foreign-trade-pro/admin-assets/_storage-adapter';
import { TRUST_STRIP_PANEL } from './schema';

interface LangOption {
  code: string;
  name: string;
}

export function TrustStripPanelClient({
  apiBase,
  extensionId,
  themeKey,
  themeName,
  initialData,
  languages,
  defaultLang,
  aiAvailable,
}: {
  apiBase: string;
  extensionId: string;
  themeKey: string;
  themeName: string;
  initialData: Record<string, unknown> | undefined;
  languages: LangOption[];
  defaultLang: string;
  aiAvailable: boolean;
}) {
  return (
    <PanelRenderer
      apiBase={apiBase}
      extensionId={extensionId}
      themeKey={themeKey}
      themeName={themeName}
      panel={TRUST_STRIP_PANEL}
      initialData={initialData}
      languages={languages}
      defaultLang={defaultLang}
      aiAvailable={aiAvailable}
      dataAdapter={createFttpStorageAdapter(TRUST_STRIP_PANEL.panelKey)}
    />
  );
}
