# @bangnicms/model-package-fttp-product-detail

**fttp 主题产品详情页配套内容模型包** —— 为 `ProductLocale.customFields` 登记 15 个 ModelField，让 admin 产品编辑页渲染友好表单。

## 与 fttp 主题的关系

- **配套使用**：本模型包与 `theme-foreign-trade-pro` 主题组合使用，单独激活无实际意义（其他主题不消费这些字段）
- **独立生命周期**：主题与模型包是两条扩展链路，可以独立安装 / 卸载 / 升级
- **字段契约共享**：本模型包与主题 `themes/theme-foreign-trade-pro/src/pages/product-detail/product-detail-types.ts` 共享一份 TS 类型锚（`FttpProductDetailCustomFields`），本包 `src/field-definitions.ts` 通过 `import type` 校对

## 15 个字段（分 7 大组）

| 分组 | fieldKey | fieldType | 说明 |
|---|---|---|---|
| 产品视觉 | `gallery` | `gallery` | 画廊媒体（图 + 视频） |
|  | `badges` | `parameter_group` | 主图徽章 (label / tone) |
| 库存与亮点 | `stockStatus` | `select` | 现货 / 按需生产 / 暂时缺货 |
|  | `highlightSpecs` | `parameter_group` | 高亮规格（group / label / value，相同 group 聚合） |
|  | `certificationBadges` | `select` multiple | 认证徽章多选（CE / FCC / RoHS ...） |
| 卖点与定制 | `sellingPoints` | `parameter_group` | 卖点（title / items；items 用回车分隔多行） |
|  | `customOptions` | `parameter_group` | 定制选项（结构同上） |
| 技术规格 | `technicalSpecsTable` | `parameter_group` | 技术规格主表（label / value） |
|  | `technicalSpecsSideCards` | `parameter_group` | 技术规格 Tab 右栏侧卡（title / items；items 用回车分隔多行） |
| 包装与运输 | `packagingTable` | `parameter_group` | 包装详情表 |
|  | `shippingTable` | `parameter_group` | 运输与物流表 |
|  | `shippingPartnersBanner` | `text` | 物流伙伴 banner 文案 |
| 资质认证 | `certifications` | `parameter_group` | 证书三元组（code / title / scope） |
| 常见问题 | `faq` | `parameter_group` | Q-A 对 |
| 底部 CTA | `ctaTitle` | `text` | 自定义底部 CTA 大标题 |

## 嵌套字段的扁平化

平台 `parameter_group` 只支持扁平 `Record<string, string|number>`，无法直接表达嵌套（items 数组、rows 二级聚合等）。本模型包采用如下策略：

- **多组表格**（如 `highlightSpecs` 原本 `{title, rows}` 列表）→ 新增 `group` 列扁平化，主题按 `group` 聚合还原
- **标题 + 要点数组**（如 `sellingPoints.items`）→ items 列填入"多行文本（回车分隔）"，主题按 `\n` 拆回数组
- **复杂嵌套**（如 `technicalSpecs.{table,sideCards}`、`packagingShipping.{packagingTable,shippingTable,partnersBanner}`）→ 拆成多个独立 fieldKey，由主题 `normalizeFlatModelPackageInput` 虚拟重组为嵌套结构

主题侧兼容两种输入（扁平模型包写入 / 手工 JSON 原始嵌套），见主题 `product-detail-types.ts#parseFttpCustomFields`。

## 安装方式

### 方式 A：开发态 seed（本仓开发人员）

```bash
# 把 manifest.json 投放到 apps/server/data/model-packages/
node infra/scripts/install-fttp-product-detail-model-package.mjs

# 运行 seed（只扫描 model-packages/ 目录，已存在的会 upsert）
pnpm --filter @bangnicms/server exec prisma db seed
```

投放后进入后台 `/extensions` → 找到 "fttp 产品详情页字段包" → 安装 → 激活。

### 方式 B：打包上传（生产环境 / 外部开发者）

```bash
# 把 manifest.json 打成 zip（根目录放 manifest.json，名字必须叫 package.json）
# 简易做法：
cp manifest.json /tmp/package.json
cd /tmp && zip fttp-product-detail-1.0.0.zip package.json

# 后台 /extensions → 上传模型包 → 选择 zip
```

## 激活后的效果

1. 后台「产品」编辑页，当前语言 Tab 下自动渲染 7 折叠区（按 `groupName` 分组）共 14 字段
2. 保存后写入 `ProductLocale.customFields` JSON 列
3. fttp 主题前台 `/products/:productKey` 立即消费（SSR 渲染）

## 卸载

走平台 `MODEL_PACKAGE_UNINSTALL_STRATEGIES`：
- `archive`（默认）：保留 `customFields` 数据，停用 ModelField 登记
- `purge`：彻底清理数据

## 文档

- 完整规范：`docs/sketches/fttp-product-detail-page-dev-spec-v2.md`
- 平台 ModelPackage 机制：`docs/examples/model-packages/README.md`
- 主题字段契约：`themes/theme-foreign-trade-pro/src/pages/product-detail/product-detail-types.ts`
