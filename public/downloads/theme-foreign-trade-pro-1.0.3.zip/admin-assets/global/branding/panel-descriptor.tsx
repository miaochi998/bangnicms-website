import type { PanelDescriptor } from '../../_types';
import { BrandingPanelClient } from './BrandingPanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'global/branding',
  configKey: 'config', // useRootConfig=true 时不取此键，仅作占位
  useRootConfig: true,
  title: '品牌调色',
  description: '调整 fttp 主题的品牌主色与强调色，保存后立即生效到全站视觉。',
  dataPage: 'theme-config-branding',
  notApplicableTestId: 'branding-not-applicable',
  guardMode: 'theme-key',
  PanelClient: BrandingPanelClient,
};
