/**
 * fttp 询价车页 PanelSchemaV1 schema（阶段 2 节点 C · C-D4）
 * -----------------------------------------------------------------------------
 * 接管自原 InquiryCartPageConfigForm.tsx（1328 行手写）。
 *
 * Storage 形态（config.inquiryCartPage）：
 *   {
 *     enabled,
 *     hero: { breadcrumbHome/breadcrumbCurrent/titleTemplate/subtitle: LT },
 *     steps: { enabled, items[]: { id, state:'done'|'active'|'pending', label:LT } },
 *     list: { productCountTemplate/skuLabel/stockLabel/removeLabel/clearAllLabel
 *             /continueLabel/emptyTitle/emptyDesc/browseProductsLabel: LT × 9 },
 *     form: {
 *       title/subtitle: LT,
 *       fields: { name/email/whatsapp/country/notesLabel + notesPlaceholder: LT × 6 },
 *       consentLabel/privacyLinkLabel: LT,
 *       privacyLinkHref: str,
 *       submitTemplate/submittingLabel/encryptedHint/thankYouTitle/thankYouDesc
 *         /thankYouContinue: LT × 6,
 *     },
 *     benefits: { enabled, items[]: { id, iconName, title:LT, desc:LT } },
 *     quickContacts: { enabled, items[]:{ id, iconName, label:LT, href, accent:bool } },
 *     recommended: { enabled, eyebrow:LT, title:LT, limit:number, strategy:'latest'|'featured' },
 *   }
 *
 * 形态特点：
 *   - LocalizedText 全部是裸 `{ lang: str }` 形态（非 trust-strip styled 形态）·
 *     adapter default read/write 路径 passthrough · schema 端用 localizedText{multiLang:true}
 *
 * helper 复用偏离登记（schema.ts 头注 + 完工汇报 §X）：
 *   - **createNullableObjectField 二次复用预期不匹配**（启动指令档 §1.1 #4）：
 *     inquiry-cart 无 nullable section · 所有 sub-section（steps / benefits /
 *     quickContacts / recommended / form.consent / thankYou）均为 enabled bool
 *     + 完整数据，关闭只是不渲染前台，**数据保留不为 null**。
 *     与节点 B inquiry-form / 节点 C contact 同款发现 → helper createNullableObjectField
 *     全节点 C 实际复用 0 处 · 节点 D 总收尾评估 helper 是否撤销或推迟到 P3 阶段。
 *   - createCtaLinkObjectField 不复用：privacyLinkHref / quickContacts[].href 全是
 *     裸 string，无 9 类 type 选择。
 *
 * adapter 行为（fttp.inquiry-cart-page · postprocessInquiryCartPageWrite）：
 *   - 3 ListField items[].id 兜底（steps.items / benefits.items / quickContacts.items）
 *   - 顶层浅 + section 嵌套 merge
 *   - storage 与 schema 1:1 对齐 · 不需要 preprocessRead
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

const ITEM_ID_FIELD = {
  fieldKey: 'id',
  type: 'text',
  label: 'ID（系统生成 · 请勿修改）',
  placeholder: '保存时自动补齐',
  span: 'narrow',
} as const;

const STEP_STATE_OPTIONS = [
  { value: 'pending', label: 'Pending（未完成）' },
  { value: 'active', label: 'Active（当前激活）' },
  { value: 'done', label: 'Done（已完成）' },
];

const RECOMMENDED_STRATEGY_OPTIONS = [
  { value: 'latest', label: 'Latest（最新优先）' },
  { value: 'featured', label: 'Featured（精选）' },
];

export const INQUIRY_CART_PAGE_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.inquiry-cart-page',
  version: 1,
  title: '询价车页 · 配置',
  configPath: 'config.inquiryCartPage',
  tabs: [
    {
      tabKey: 'hero',
      title: 'Hero & 步骤',
      sections: [
        {
          sectionKey: 'master',
          title: '总开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用询价车页',
              defaultValue: true,
              controlsChildren: true,
              span: 'narrow',
            },
          ],
        },
        {
          sectionKey: 'hero',
          title: 'Hero（面包屑 + 标题模板）',
          fields: [
            {
              fieldKey: 'hero',
              type: 'object',
              label: 'Hero',
              span: 'full',
              fields: [
                { fieldKey: 'breadcrumbHome', type: 'localizedText', label: '面包屑「首页」', multiLang: true, span: 'medium' },
                { fieldKey: 'breadcrumbCurrent', type: 'localizedText', label: '面包屑「询价车」', multiLang: true, span: 'medium' },
                {
                  fieldKey: 'titleTemplate',
                  type: 'localizedText',
                  label: '标题模板（含 {count} 占位符）',
                  multiLang: true,
                  span: 'wide',
                },
                { fieldKey: 'subtitle', type: 'localizedText', label: '副标题', multiLang: true, multiline: true, span: 'full' },
              ],
            },
          ],
        },
        {
          sectionKey: 'steps',
          title: '4 步骤指示器',
          fields: [
            {
              fieldKey: 'steps',
              type: 'object',
              label: '步骤',
              span: 'full',
              fields: [
                { fieldKey: 'enabled', type: 'switch', label: '启用步骤指示器', defaultValue: true, span: 'narrow' },
                {
                  fieldKey: 'items',
                  type: 'arrayOfObject',
                  label: '步骤项（建议 4 项）',
                  minItems: 0,
                  maxItems: 8,
                  itemTitleField: 'label',
                  addLabel: '添加步骤',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      ITEM_ID_FIELD,
                      {
                        fieldKey: 'state',
                        type: 'select',
                        label: '状态',
                        defaultValue: 'pending',
                        options: STEP_STATE_OPTIONS,
                        span: 'narrow',
                      },
                      { fieldKey: 'label', type: 'localizedText', label: '步骤文案', multiLang: true, span: 'wide' },
                    ],
                  },
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'list',
      title: '列表 & 表单',
      sections: [
        {
          sectionKey: 'list',
          title: '产品列表文案（9 段 LT）',
          fields: [
            {
              fieldKey: 'list',
              type: 'object',
              label: '列表',
              span: 'full',
              fields: [
                {
                  fieldKey: 'productCountTemplate',
                  type: 'localizedText',
                  label: '产品计数模板（含 {count}）',
                  multiLang: true,
                  span: 'wide',
                },
                { fieldKey: 'skuLabel', type: 'localizedText', label: 'SKU 标签', multiLang: true, span: 'medium' },
                { fieldKey: 'stockLabel', type: 'localizedText', label: '现货供应标签', multiLang: true, span: 'medium' },
                { fieldKey: 'removeLabel', type: 'localizedText', label: '移除按钮', multiLang: true, span: 'medium' },
                { fieldKey: 'clearAllLabel', type: 'localizedText', label: '清空全部按钮', multiLang: true, span: 'medium' },
                { fieldKey: 'continueLabel', type: 'localizedText', label: '继续浏览', multiLang: true, span: 'medium' },
                { fieldKey: 'emptyTitle', type: 'localizedText', label: '空态标题', multiLang: true, span: 'wide' },
                { fieldKey: 'emptyDesc', type: 'localizedText', label: '空态描述', multiLang: true, multiline: true, span: 'full' },
                { fieldKey: 'browseProductsLabel', type: 'localizedText', label: '浏览全部产品按钮', multiLang: true, span: 'wide' },
              ],
            },
          ],
        },
        {
          sectionKey: 'form',
          title: '提交表单（5 字段固定 + 提交模板 + Thank You）',
          fields: [
            {
              fieldKey: 'form',
              type: 'object',
              label: '表单',
              span: 'full',
              fields: [
                { fieldKey: 'title', type: 'localizedText', label: '表单标题', multiLang: true, span: 'wide' },
                { fieldKey: 'subtitle', type: 'localizedText', label: '表单副标题', multiLang: true, multiline: true, span: 'full' },
                {
                  fieldKey: 'fields',
                  type: 'object',
                  label: '5 字段标签 + 1 占位符（业务上不允许增删字段）',
                  span: 'full',
                  fields: [
                    { fieldKey: 'nameLabel', type: 'localizedText', label: '姓名', multiLang: true, span: 'medium' },
                    { fieldKey: 'emailLabel', type: 'localizedText', label: '邮箱', multiLang: true, span: 'medium' },
                    { fieldKey: 'whatsappLabel', type: 'localizedText', label: 'WhatsApp', multiLang: true, span: 'medium' },
                    { fieldKey: 'countryLabel', type: 'localizedText', label: '国家 / 地区', multiLang: true, span: 'medium' },
                    { fieldKey: 'notesLabel', type: 'localizedText', label: '附加需求', multiLang: true, span: 'medium' },
                    { fieldKey: 'notesPlaceholder', type: 'localizedText', label: '附加需求占位符', multiLang: true, span: 'wide' },
                  ],
                },
                {
                  fieldKey: 'consentLabel',
                  type: 'localizedText',
                  label: '隐私同意（含 {privacyLink} 占位符）',
                  multiLang: true,
                  multiline: true,
                  span: 'full',
                },
                { fieldKey: 'privacyLinkLabel', type: 'localizedText', label: '"隐私政策" 链接文案', multiLang: true, span: 'wide' },
                { fieldKey: 'privacyLinkHref', type: 'text', label: '隐私链接 URL（单语 · 通常 /privacy）', placeholder: '/privacy', span: 'wide' },
                {
                  fieldKey: 'submitTemplate',
                  type: 'localizedText',
                  label: '提交按钮模板（含 {count}）',
                  multiLang: true,
                  span: 'wide',
                },
                { fieldKey: 'submittingLabel', type: 'localizedText', label: '提交中文案', multiLang: true, span: 'medium' },
                { fieldKey: 'encryptedHint', type: 'localizedText', label: '加密提示（允许 emoji）', multiLang: true, span: 'wide' },
                { fieldKey: 'thankYouTitle', type: 'localizedText', label: 'Thank You 标题', multiLang: true, span: 'wide' },
                {
                  fieldKey: 'thankYouDesc',
                  type: 'localizedText',
                  label: 'Thank You 描述（含 {email}）',
                  multiLang: true,
                  multiline: true,
                  span: 'full',
                },
                { fieldKey: 'thankYouContinue', type: 'localizedText', label: 'Thank You 继续浏览按钮', multiLang: true, span: 'wide' },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'benefits',
      title: 'Benefits & QuickContact',
      sections: [
        {
          sectionKey: 'benefits',
          title: '4 项 Benefits',
          fields: [
            {
              fieldKey: 'benefits',
              type: 'object',
              label: 'Benefits',
              span: 'full',
              fields: [
                { fieldKey: 'enabled', type: 'switch', label: '启用 Benefits', defaultValue: true, span: 'narrow' },
                {
                  fieldKey: 'items',
                  type: 'arrayOfObject',
                  label: 'Benefit 项（建议 4 项）',
                  minItems: 0,
                  maxItems: 12,
                  itemTitleField: 'title',
                  addLabel: '添加 Benefit',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      ITEM_ID_FIELD,
                      { fieldKey: 'iconName', type: 'icon', label: '图标（Lucide）', span: 'narrow' },
                      { fieldKey: 'title', type: 'localizedText', label: '标题', multiLang: true, span: 'wide' },
                      { fieldKey: 'desc', type: 'localizedText', label: '描述', multiLang: true, multiline: true, span: 'full' },
                    ],
                  },
                },
              ],
            },
          ],
        },
        {
          sectionKey: 'quickContacts',
          title: 'QuickContact 联系方式',
          fields: [
            {
              fieldKey: 'quickContacts',
              type: 'object',
              label: 'QuickContact',
              span: 'full',
              fields: [
                { fieldKey: 'enabled', type: 'switch', label: '启用 QuickContact', defaultValue: true, span: 'narrow' },
                {
                  fieldKey: 'items',
                  type: 'arrayOfObject',
                  label: 'QuickContact 项（建议 3 项）',
                  minItems: 0,
                  maxItems: 8,
                  itemTitleField: 'label',
                  addLabel: '添加联系方式',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      ITEM_ID_FIELD,
                      { fieldKey: 'iconName', type: 'icon', label: '图标（Lucide）', span: 'narrow' },
                      { fieldKey: 'label', type: 'localizedText', label: '文案', multiLang: true, span: 'wide' },
                      {
                        fieldKey: 'href',
                        type: 'text',
                        label: '链接（mailto: / tel: / https: ...）',
                        placeholder: 'tel:+86...',
                        span: 'wide',
                      },
                      { fieldKey: 'accent', type: 'switch', label: '橙色高亮', defaultValue: false, span: 'narrow' },
                    ],
                  },
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'recommended',
      title: '推荐产品',
      sections: [
        {
          sectionKey: 'recommended',
          title: '底部推荐产品',
          fields: [
            {
              fieldKey: 'recommended',
              type: 'object',
              label: '推荐产品',
              span: 'full',
              fields: [
                { fieldKey: 'enabled', type: 'switch', label: '启用推荐区块', defaultValue: true, span: 'narrow' },
                { fieldKey: 'eyebrow', type: 'localizedText', label: 'eyebrow 小标题', multiLang: true, span: 'wide' },
                { fieldKey: 'title', type: 'localizedText', label: '主标题', multiLang: true, span: 'wide' },
                { fieldKey: 'limit', type: 'number', label: '数量上限', min: 1, max: 12, step: 1, span: 'narrow' },
                {
                  fieldKey: 'strategy',
                  type: 'select',
                  label: '策略',
                  defaultValue: 'latest',
                  options: RECOMMENDED_STRATEGY_OPTIONS,
                  span: 'narrow',
                },
              ],
            },
          ],
        },
      ],
    },
  ],
};
