# 外贸通用主题 01 PRO（theme-foreign-trade-pro）

[![CI](https://github.com/miaochi998/bangnicms-theme-foreign-trade-pro/actions/workflows/ci.yml/badge.svg)](https://github.com/miaochi998/bangnicms-theme-foreign-trade-pro/actions/workflows/ci.yml)

BangNiCMS 第一个真正可独立分发的第三方主题，面向外贸独立站场景。**阶段 6 节点 A（2026-05-12）从主仓 `themes/theme-foreign-trade-pro/` 物理迁出为独立仓**。

## 形态

- **独立仓**：本仓 = `themes/theme-foreign-trade-pro/` 子目录历史 + 自带 CI/pack 能力
- **esbuild 打包**：`pnpm pack:zip` → 产出 `dist-themes/theme-foreign-trade-pro-X.Y.Z.zip`（含 `manifest.json` + `dist/index.mjs` + `admin-assets/` + 内嵌 `model-packages/`）
- **分发**：把 zip 上传到主仓 admin → 扩展中心 → 离线安装

## 本地开发等价 CI 命令

CI（`.github/workflows/ci.yml`）在 GitHub Actions 跑：

```bash
pnpm install --frozen-lockfile
pnpm pack:zip
# 产物：dist-themes/theme-foreign-trade-pro-1.0.0.zip
```

本地同样命令即可复现 CI 全部步骤（无需后端 / 无需主仓）。

## 当前阶段

阶段 2.0 — 脚手架贯通（**仅探针路由 `/__fttp-probe`**）。

完整开发计划详见 `docs/主题开发/09-阶段2开发计划.md`。

## 开发命令

```bash
# 一次性把 manifest.json 注册到 DB（status=disabled）
pnpm dev:theme:register theme-foreign-trade-pro

# 启动 esbuild watch（持续编译 src/ 到 storage/uploads/_extensions/.../dist/index.mjs）
pnpm dev:theme theme-foreign-trade-pro

# 改动后让 active theme 重新解析路由表
bash infra/scripts/restart-local.sh
```

## customFields 消费契约（阶段 2.3+ 起生效）

> 本契约为 **R4-3 锁定**，主题代码在每处 read `ProductLocale.customFields` 时必须 try/fallback。
> 详细 schema 详见 `docs/主题开发/09-阶段2开发计划.md` §12.5。

主题消费的顶层 key（约 10 个）：

- `tradeInfo`：起订量 / 交期 / 样品 / 港口 / 付款 / 包装
- `certifications[]`：CE / FCC / RoHS / UL / FDA 认证徽章
- `tieredPricing[]`：批发阶梯价
- `customizationOptions`：颜色 / 电压 / Logo / 包装定制
- `sellingPoints[]`：买家为何选择此 SKU 要点
- `techSpecs` / `packagingInfo` / `certInfo`：5 tabs 富文本块
- `faq[]`：常见问题
- `datasheetUrl`：完整数据表 PDF
- `badges[]`：卡片角标（hot / new / custom / oem）

**降级行为**：缺失字段对应区块隐藏，不显示空表 / 不报错。

阶段 2 内**运营手动在 admin 建对应字段**（系统已有 ContentModel + ModelField + DynamicModelForm 基建）。配套 ModelPackage 自动 ensure 留待阶段 3 起。

## 许可

Internal — BangNiCMS。
