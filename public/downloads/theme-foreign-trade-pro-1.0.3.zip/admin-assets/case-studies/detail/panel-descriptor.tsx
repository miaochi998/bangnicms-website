import { FileText } from 'lucide-react';
import type { PanelDescriptor } from '../../_types';
import { iconHint } from '../../_helpers';
import { CaseStudyDetailPanelClient } from './CaseStudyDetailPanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'case-studies/detail',
  configKey: 'caseStudyDetailPage',
  title: '解决方案 · 详情页',
  description: '配置 /case-studies/:slug 详情页：Hero（深色面包屑 + 客户 + 标题 + 摘要 + 关键指标 chips）+ 主信息卡（封面 + 4 章节内容 = 挑战/方法/成果/部署产品）+ 下一案例引导 + 404 兜底。所有文案多语言。',
  dataPage: 'theme-config-fttp-case-study-detail',
  notApplicableTestId: 'case-study-detail-not-applicable',
  guardMode: 'theme-key',
  PanelClient: CaseStudyDetailPanelClient,
  hint: iconHint(
    <FileText className="h-4 w-4 shrink-0 mt-0.5" />,
    <>
      <p>
        <strong>提示</strong>：404 副文案模板中的{' '}
        <code className="px-1 py-0.5 rounded bg-muted text-foreground">{'{slug}'}</code>{' '}
        占位符会被前台自动替换为用户访问的不存在 slug。
      </p>
      <p className="mt-1">章节标题（面临的挑战 / 我们的方法 / 取得的成果 / 部署产品）按设计语言固定为 4 段，不支持新增章节段（避免案例间结构发散）。</p>
    </>,
  ),
};
