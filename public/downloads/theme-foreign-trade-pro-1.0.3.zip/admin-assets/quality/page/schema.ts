/**
 * fttp 质量管控页 PanelSchemaV1 schema（节点 C D-C3 · S2.4）
 * -----------------------------------------------------------------------------
 * 接管自原 QualityPageConfigForm.tsx（1754 行手写）。
 *
 * Storage 形态（FttpQualityPageConfig · config.qualityPage）：
 *   {
 *     enabled,
 *     hero: { breadcrumbLabel, title, subtitle, style },
 *     headlineMetrics: { eyebrow, title, items[{id, icon, value, label, trendText, trendDirection}], style },
 *     qcProcess: {
 *       eyebrow, title, description,
 *       keyFigures[{id, value, label}],
 *       items[{id, step, icon, title, description, duration, tools[{id, text}]}],  // 二级嵌套
 *       style
 *     },
 *     equipment: {
 *       eyebrow, title, description,
 *       keyFigures[{id, value, label}],
 *       columns: { desktop, tablet, mobile },
 *       items[{id, icon, name, brand, quantity, use}],
 *       style
 *     }
 *   }
 *
 * 节点 C 范围降级：
 *   - 各 section style（多 TextStyle 段 + 多色） → 不暴露，从 prev 透传（adapter 嵌套 merge）
 *   - icon `{kind, name, size?, color?}` 对象 → 字段级 read/write 取 .name；prev 透传 size/color
 *   - equipment.columns 展平为 desktopCols/tabletCols/mobileCols（adapter preprocessRead/postprocessWrite）
 *   - qcProcess.items[i].tools[] = arrayOfObject 嵌套（D1 硬限 2 层 · 合法）
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

const TREND_OPTIONS = [
  { value: 'up', label: '上升' },
  { value: 'down', label: '下降' },
  { value: 'flat', label: '持平' },
] as const;

export const QUALITY_PAGE_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.quality-page',
  version: 1,
  previewAdapter: 'fttp.quality-page',
  title: '质量管控页',
  configPath: 'config.qualityPage',
  tabs: [
    {
      tabKey: 'overview',
      title: '总开关 · Hero',
      sections: [
        {
          sectionKey: 'master',
          title: '整块开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用本页面',
              description: '关闭后前台 /quality 渲染为空。',
              defaultValue: true,
              controlsChildren: true,
              span: 'narrow',
            },
          ],
        },
        {
          sectionKey: 'hero',
          title: 'Hero 页头',
          fields: [
            {
              fieldKey: 'hero',
              type: 'object',
              label: 'Hero',
              span: 'full',
              fields: [
                { fieldKey: 'breadcrumbLabel', type: 'localizedText', label: '面包屑文字', multiLang: true, span: 'wide' },
                { fieldKey: 'title', type: 'localizedText', label: '主标题', multiLang: true, required: true, span: 'wide' },
                { fieldKey: 'subtitle', type: 'localizedText', label: '副标题', multiLang: true, span: 'full' },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'metrics',
      title: '关键指标',
      sections: [
        {
          sectionKey: 'metrics',
          title: '关键指标横幅',
          fields: [
            {
              fieldKey: 'headlineMetrics',
              type: 'object',
              label: '关键指标',
              span: 'full',
              fields: [
                { fieldKey: 'eyebrow', type: 'localizedText', label: '小眉题', multiLang: true, span: 'wide' },
                { fieldKey: 'title', type: 'localizedText', label: '主标题', multiLang: true, span: 'wide' },
                {
                  fieldKey: 'items',
                  type: 'arrayOfObject',
                  label: '指标项',
                  minItems: 0,
                  maxItems: 12,
                  itemTitleField: 'label',
                  addLabel: '添加一项指标',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      { fieldKey: 'id', type: 'text', label: 'ID', placeholder: 'm-xxx', span: 'narrow' },
                      { fieldKey: 'icon', type: 'icon', label: '图标', span: 'narrow' },
                      { fieldKey: 'value', type: 'localizedText', label: '数值', multiLang: true, required: true, span: 'wide' },
                      { fieldKey: 'label', type: 'localizedText', label: '标签', multiLang: true, required: true, span: 'wide' },
                      { fieldKey: 'trendText', type: 'localizedText', label: '趋势文字', multiLang: true, span: 'wide' },
                      {
                        fieldKey: 'trendDirection',
                        type: 'select',
                        label: '趋势方向',
                        options: [...TREND_OPTIONS],
                        defaultValue: 'flat',
                        span: 'narrow',
                      },
                    ],
                  },
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'qc-process',
      title: 'QC 流程',
      sections: [
        {
          sectionKey: 'qc-process',
          title: 'QC 检验流程（含步骤与工具）',
          description: '步骤项内含 tools[] 二级数组，编辑器自动嵌套展开。',
          fields: [
            {
              fieldKey: 'qcProcess',
              type: 'object',
              label: 'QC 流程',
              span: 'full',
              fields: [
                { fieldKey: 'eyebrow', type: 'localizedText', label: '小眉题', multiLang: true, span: 'wide' },
                { fieldKey: 'title', type: 'localizedText', label: '主标题', multiLang: true, span: 'wide' },
                { fieldKey: 'description', type: 'localizedText', label: '描述', multiLang: true, span: 'full' },
                {
                  fieldKey: 'keyFigures',
                  type: 'arrayOfObject',
                  label: '关键数字',
                  minItems: 0,
                  maxItems: 6,
                  itemTitleField: 'label',
                  addLabel: '添加一项关键数字',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      { fieldKey: 'id', type: 'text', label: 'ID', placeholder: 'kf-xxx', span: 'narrow' },
                      { fieldKey: 'value', type: 'localizedText', label: '数值', multiLang: true, required: true, span: 'wide' },
                      { fieldKey: 'label', type: 'localizedText', label: '标签', multiLang: true, required: true, span: 'wide' },
                    ],
                  },
                },
                {
                  fieldKey: 'items',
                  type: 'arrayOfObject',
                  label: '步骤项',
                  minItems: 0,
                  maxItems: 16,
                  itemTitleField: 'title',
                  addLabel: '添加一个步骤',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      { fieldKey: 'id', type: 'text', label: 'ID', placeholder: 'step-xxx', span: 'narrow' },
                      { fieldKey: 'step', type: 'localizedText', label: '编号', multiLang: true, span: 'narrow' },
                      { fieldKey: 'icon', type: 'icon', label: '图标', span: 'narrow' },
                      { fieldKey: 'title', type: 'localizedText', label: '步骤名称', multiLang: true, required: true, span: 'wide' },
                      { fieldKey: 'description', type: 'localizedText', label: '描述', multiLang: true, span: 'full' },
                      { fieldKey: 'duration', type: 'localizedText', label: '耗时说明', multiLang: true, span: 'wide' },
                      {
                        fieldKey: 'tools',
                        type: 'arrayOfObject',
                        label: '工具列表',
                        minItems: 0,
                        maxItems: 12,
                        itemTitleField: 'text',
                        addLabel: '添加一项工具',
                        span: 'full',
                        itemSchema: {
                          fields: [
                            { fieldKey: 'id', type: 'text', label: 'ID', placeholder: 't-xxx', span: 'narrow' },
                            { fieldKey: 'text', type: 'localizedText', label: '工具名', multiLang: true, required: true, span: 'wide' },
                          ],
                        },
                      },
                    ],
                  },
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'equipment',
      title: '检测设备',
      sections: [
        {
          sectionKey: 'equipment',
          title: '检测设备网格',
          fields: [
            {
              fieldKey: 'equipment',
              type: 'object',
              label: '检测设备',
              span: 'full',
              fields: [
                { fieldKey: 'eyebrow', type: 'localizedText', label: '小眉题', multiLang: true, span: 'wide' },
                { fieldKey: 'title', type: 'localizedText', label: '主标题', multiLang: true, span: 'wide' },
                { fieldKey: 'description', type: 'localizedText', label: '描述', multiLang: true, span: 'full' },
                { fieldKey: 'desktopCols', type: 'number', label: '桌面端列数', min: 1, max: 12, defaultValue: 4, span: 'narrow' },
                { fieldKey: 'tabletCols', type: 'number', label: '平板列数', min: 1, max: 12, defaultValue: 2, span: 'narrow' },
                { fieldKey: 'mobileCols', type: 'number', label: '移动端列数', min: 1, max: 12, defaultValue: 1, span: 'narrow' },
                {
                  fieldKey: 'keyFigures',
                  type: 'arrayOfObject',
                  label: '关键数字',
                  minItems: 0,
                  maxItems: 6,
                  itemTitleField: 'label',
                  addLabel: '添加一项关键数字',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      { fieldKey: 'id', type: 'text', label: 'ID', placeholder: 'kf-xxx', span: 'narrow' },
                      { fieldKey: 'value', type: 'localizedText', label: '数值', multiLang: true, required: true, span: 'wide' },
                      { fieldKey: 'label', type: 'localizedText', label: '标签', multiLang: true, required: true, span: 'wide' },
                    ],
                  },
                },
                {
                  fieldKey: 'items',
                  type: 'arrayOfObject',
                  label: '设备项',
                  minItems: 0,
                  maxItems: 32,
                  itemTitleField: 'name',
                  addLabel: '添加一项设备',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      { fieldKey: 'id', type: 'text', label: 'ID', placeholder: 'eq-xxx', span: 'narrow' },
                      { fieldKey: 'icon', type: 'icon', label: '图标', span: 'narrow' },
                      { fieldKey: 'name', type: 'localizedText', label: '设备名称', multiLang: true, required: true, span: 'wide' },
                      { fieldKey: 'brand', type: 'localizedText', label: '品牌型号', multiLang: true, span: 'wide' },
                      { fieldKey: 'quantity', type: 'localizedText', label: '数量', multiLang: true, span: 'narrow' },
                      { fieldKey: 'use', type: 'localizedText', label: '用途说明', multiLang: true, span: 'full' },
                    ],
                  },
                },
              ],
            },
          ],
        },
      ],
    },
  ],
};
