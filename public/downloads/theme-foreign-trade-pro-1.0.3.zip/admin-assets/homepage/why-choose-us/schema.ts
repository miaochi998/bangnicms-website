/**
 * fttp 首页「为什么选择我们」PanelSchemaV1 schema（节点 C commit-1b-β · S2.3）
 * -----------------------------------------------------------------------------
 * 接管自原 WhyChooseUsConfigForm.tsx。fttp storage 形态：
 *   - 顶层 headerTranslations: { [lang]: { sectionTag, sectionTitle, sectionDescription } }
 *     由 fttp-storage-adapter.preprocessRead 拍平为 header.{field}: { [lang]: string }
 *   - items[i].translations: { [lang]: { title, description, metric, visualAlt? } }
 *     由 adapter 拍平为 items[i].{ title, description, metric, visualAlt }（每个 LocalizedString）
 *
 * 已知节点 C 退化（节点 D 入账 / 阶段 2 处理）：
 *   - 6 段 textStyle（sectionTag / sectionTitle / sectionDescription / itemTitle /
 *     itemDescription / itemMetric）+ 8 个颜色字段（cardBackground / cardBorder /
 *     iconBackground / iconHoverBackground / iconColor / iconHoverColor 等）
 *     在新渲染器内不可见可编辑（PanelSchemaV1 暂无 textStyle 原语 / UX 决策不暴露），
 *     通过 prev merge 透传保留
 *   - layout.cardOrientation 暴露；layout.columnsMobile 不暴露（fttp 默认 1，无运营调整需求）
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

const WCU_FREQUENT_ICONS = [
  'Sparkles',
  'ShieldCheck',
  'Truck',
  'Award',
  'Factory',
  'BadgeCheck',
  'Globe2',
  'Users',
  'Cpu',
  'Trophy',
  'Medal',
  'Zap',
];

export const WHY_CHOOSE_US_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.why-choose-us',
  version: 1,
  previewAdapter: 'fttp.why-choose-us',
  title: '首页 · 为什么选择我们',
  configPath: 'config.whyChooseUs',
  tabs: [
    {
      tabKey: 'header',
      title: '区块标题',
      sections: [
        {
          sectionKey: 'master',
          title: '整块开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用「为什么选择我们」',
              defaultValue: true,
              controlsChildren: true,
              span: 'full',
            },
          ],
        },
        {
          sectionKey: 'header',
          title: '区块标题文案',
          description: '3 个文本字段（小标 / 主标 / 描述）三语编辑。',
          fields: [
            {
              fieldKey: 'header',
              type: 'object',
              label: '区块标题',
              span: 'full',
              fields: [
                {
                  fieldKey: 'sectionTag',
                  type: 'localizedText',
                  label: '小标（sectionTag）',
                  multiLang: true,
                  placeholder: '为什么选择我们',
                  span: 'wide',
                },
                {
                  fieldKey: 'sectionTitle',
                  type: 'localizedText',
                  label: '主标题 H2（sectionTitle）',
                  multiLang: true,
                  required: true,
                  placeholder: '让海外采购更稳、更快、更放心',
                  span: 'wide',
                },
                {
                  fieldKey: 'sectionDescription',
                  type: 'localizedText',
                  label: '描述段（sectionDescription）',
                  multiLang: true,
                  placeholder: '我们不是简单的贸易商……',
                  span: 'full',
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'items',
      title: '卡片列表',
      sections: [
        {
          sectionKey: 'items',
          title: '卡片列表',
          description: '至少 1 张 / 最多 8 张；每张含图标 + 可选配图 + 三语标题/描述/数字徽章/图片说明。',
          fields: [
            {
              fieldKey: 'items',
              type: 'arrayOfObject',
              label: '卡片项',
              minItems: 1,
              maxItems: 8,
              itemTitleField: 'title.zh-CN',
              defaultCollapsed: false,
              addLabel: '添加一张卡片',
              span: 'full',
              itemSchema: {
                fields: [
                  {
                    fieldKey: 'id',
                    type: 'text',
                    label: '稳定标识 ID',
                    description: '用于前台数据钩子；保留默认值，新建项可留空。',
                    placeholder: 'factory',
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'icon',
                    type: 'object',
                    label: '图标',
                    span: 'full',
                    fields: [
                      {
                        fieldKey: 'kind',
                        type: 'select',
                        label: '类型',
                        options: [
                          { value: 'lucide', label: 'Lucide 图标库' },
                          { value: 'upload', label: '上传自定义' },
                        ],
                        defaultValue: 'lucide',
                        span: 'narrow',
                      },
                      {
                        fieldKey: 'name',
                        type: 'icon',
                        label: 'Lucide 图标名',
                        frequentIcons: WCU_FREQUENT_ICONS,
                        defaultValue: 'Sparkles',
                        span: 'wide',
                      },
                      {
                        fieldKey: 'url',
                        type: 'mediaPicker',
                        label: '上传图片（kind=upload 时使用）',
                        accept: ['image'],
                        span: 'wide',
                      },
                      {
                        fieldKey: 'size',
                        type: 'text',
                        label: '尺寸',
                        placeholder: '20px',
                        defaultValue: '20px',
                        span: 'narrow',
                      },
                      {
                        fieldKey: 'color',
                        type: 'color',
                        label: '颜色',
                        defaultValue: '#ff6b35',
                        span: 'narrow',
                      },
                    ],
                  },
                  {
                    fieldKey: 'visualImage',
                    type: 'mediaPicker',
                    label: '配图（可选）',
                    description: '不填时卡片为「纯文字」布局；推荐 320×320，例：工厂实拍 / 质检车间 / 证书墙。',
                    accept: ['image'],
                    span: 'full',
                  },
                  {
                    fieldKey: 'title',
                    type: 'localizedText',
                    label: '标题（title）',
                    multiLang: true,
                    required: true,
                    placeholder: 'OEM / ODM 深度定制',
                    span: 'wide',
                  },
                  {
                    fieldKey: 'metric',
                    type: 'localizedText',
                    label: '数字徽章（metric · 可选）',
                    description: '右上角小型亮色徽章，如「320+ 模具自有」。',
                    multiLang: true,
                    placeholder: '80+ 国家直达',
                    span: 'wide',
                  },
                  {
                    fieldKey: 'description',
                    type: 'localizedText',
                    label: '描述（description）',
                    multiLang: true,
                    placeholder: '自有研发与模具团队，支持 Logo 贴牌……',
                    span: 'full',
                  },
                  {
                    fieldKey: 'visualAlt',
                    type: 'localizedText',
                    label: '图片说明（visualAlt · 可选）',
                    description: '用于搜索引擎和读屏软件；不填时会用「标题」。',
                    multiLang: true,
                    placeholder: '工厂实拍',
                    span: 'wide',
                  },
                ],
              },
            },
          ],
        },
      ],
    },
    {
      tabKey: 'layout',
      title: '布局排版',
      sections: [
        {
          sectionKey: 'layout',
          title: '布局',
          fields: [
            {
              fieldKey: 'layout',
              type: 'object',
              label: '布局',
              span: 'full',
              fields: [
                {
                  fieldKey: 'columnsDesktop',
                  type: 'number',
                  label: '每行卡片数（电脑端 1-3）',
                  min: 1,
                  max: 3,
                  step: 1,
                  defaultValue: 2,
                  span: 'narrow',
                },
                {
                  fieldKey: 'columnsTablet',
                  type: 'number',
                  label: '每行卡片数（平板端 1-2）',
                  min: 1,
                  max: 2,
                  step: 1,
                  defaultValue: 2,
                  span: 'narrow',
                },
                {
                  fieldKey: 'maxItems',
                  type: 'number',
                  label: '最多显示几张卡片（1-8）',
                  min: 1,
                  max: 8,
                  step: 1,
                  defaultValue: 8,
                  span: 'narrow',
                },
                {
                  fieldKey: 'cardOrientation',
                  type: 'select',
                  label: '卡片方向',
                  options: [
                    { value: 'horizontal', label: '横向（图左文右）' },
                    { value: 'vertical', label: '纵向（图上文下）' },
                  ],
                  defaultValue: 'horizontal',
                  span: 'narrow',
                },
                {
                  fieldKey: 'headerAlign',
                  type: 'select',
                  label: '标题对齐方式',
                  options: [
                    { value: 'center', label: '居中' },
                    { value: 'left', label: '左对齐' },
                  ],
                  defaultValue: 'center',
                  span: 'narrow',
                },
              ],
            },
          ],
        },
      ],
    },
  ],
};
