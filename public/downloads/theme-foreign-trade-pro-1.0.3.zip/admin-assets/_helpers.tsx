/**
 * 主题包 admin-assets 共享 hint 渲染 helper（阶段 4 节点 A）
 * -----------------------------------------------------------------------------
 * 28 个 panel-descriptor.tsx 内 hint 字段统一通过本文件 helper 渲染。
 */
import type { ReactNode } from 'react';
import { Sparkles } from 'lucide-react';

export function sparklesHint(body: ReactNode) {
  return (
    <div className="rounded-md border bg-muted/30 p-4 text-xs text-muted-foreground flex items-start gap-2">
      <Sparkles className="h-4 w-4 shrink-0 mt-0.5" />
      <div>{body}</div>
    </div>
  );
}

export function iconHint(icon: ReactNode, body: ReactNode) {
  return (
    <div className="rounded-md border bg-muted/30 p-4 text-xs text-muted-foreground flex items-start gap-2">
      {icon}
      <div>{body}</div>
    </div>
  );
}
