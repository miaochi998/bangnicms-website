import type { PanelDescriptor } from '../../_types';
import { SitemapPagePanelClient } from './SitemapPagePanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'sitemap/page',
  configKey: 'sitemapPage',
  title: '站点地图页',
  description: '配置 /sitemap：Hero + 搜索框 + 统计条 + 7 板块（含嵌套子项）+ XML/RSS 卡 + Contact CTA。所有文案多语言；运营可完整自定义板块、节点、配色。',
  dataPage: 'theme-config-fttp-sitemap-page',
  notApplicableTestId: 'sitemap-page-not-applicable',
  guardMode: 'theme-key',
  PanelClient: SitemapPagePanelClient,
};
