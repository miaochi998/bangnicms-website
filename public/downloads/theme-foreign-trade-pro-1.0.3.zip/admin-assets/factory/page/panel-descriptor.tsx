import type { PanelDescriptor } from '../../_types';
import { FactoryPagePanelClient } from './FactoryPagePanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'factory/page',
  configKey: 'factoryPage',
  title: '工厂详情页',
  description: '配置 /factory 工厂详情页：Hero 主视觉（图片或视频极简播放器） + 5 项核心能力 + 6 组关键数字 + 底部行动召唤。所有文案多语言；启用语言由「语言管理」决定。',
  dataPage: 'theme-config-fttp-factory-page',
  notApplicableTestId: 'factory-page-not-applicable',
  guardMode: 'theme-key',
  PanelClient: FactoryPagePanelClient,
};
