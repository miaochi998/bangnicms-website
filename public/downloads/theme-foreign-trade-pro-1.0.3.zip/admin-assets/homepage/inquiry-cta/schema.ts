/**
 * fttp 首页 · 免费索取报价 PanelSchemaV1 schema（节点 C commit-1b-β · S2.3）
 * -----------------------------------------------------------------------------
 * 接管自原 InquiryCtaConfigForm.tsx。fttp inquiry-cta 数据形态是**标准
 * PanelSchemaV1 LocalizedString**（`{ [lang]: string }`），preprocessRead/
 * postprocessWrite 走 fttp adapter 默认分支（浅 merge prev 保留 style 等
 * 非渲染字段）。
 *
 * 已知节点 C 退化（节点 D 入账 / 阶段 2 处理）：
 *   - 10 段 textStyle（eyebrow/title/description/benefitItem/contactTitle/...）
 *     在新渲染器内不可见可编辑（PanelSchemaV1 暂无 textStyle 原语），
 *     通过 prev merge 透传保留
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

const CONTACT_ICON_SUGGESTIONS = [
  'Phone', 'Mail', 'MessageCircle', 'MessageSquare',
  'Clock', 'MapPin', 'Globe', 'Send', 'Smartphone',
];

export const INQUIRY_CTA_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.inquiry-cta',
  version: 1,
  previewAdapter: 'fttp.inquiry-cta',
  title: '首页 · 免费索取报价',
  configPath: 'config.inquiryCta',
  tabs: [
    {
      tabKey: 'header',
      title: '区块标题',
      sections: [
        {
          sectionKey: 'master',
          title: '整块开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用首页询盘 CTA',
              defaultValue: true,
              controlsChildren: true,
              span: 'full',
            },
          ],
        },
        {
          sectionKey: 'header',
          title: '区块标题文案',
          fields: [
            {
              fieldKey: 'header',
              type: 'object',
              label: '区块标题',
              span: 'full',
              fields: [
                {
                  fieldKey: 'eyebrow',
                  type: 'localizedText',
                  label: '小标 (eyebrow)',
                  multiLang: true,
                  placeholder: '立即开始',
                  span: 'wide',
                },
                {
                  fieldKey: 'title',
                  type: 'localizedText',
                  label: '主标题 (title)',
                  multiLang: true,
                  required: true,
                  placeholder: '免费索取报价',
                  span: 'wide',
                },
                {
                  fieldKey: 'description',
                  type: 'localizedText',
                  label: '描述段 (description)',
                  multiLang: true,
                  placeholder: '把您的需求发给我们，2 小时内回应',
                  span: 'full',
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'benefits',
      title: '好处列表',
      sections: [
        {
          sectionKey: 'benefits',
          title: '好处列表',
          description: '左侧承诺要点列表（1-8 项）',
          fields: [
            {
              fieldKey: 'benefits',
              type: 'arrayOfObject',
              label: '好处项',
              minItems: 1,
              maxItems: 8,
              itemTitleField: 'text.zh-CN',
              span: 'full',
              itemSchema: {
                fields: [
                  {
                    fieldKey: 'id',
                    type: 'text',
                    label: '稳定标识 ID',
                    description: '用于前台数据钩子；保留默认值，新建项可留空。',
                    placeholder: 'response',
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'text',
                    type: 'localizedText',
                    label: '好处文案',
                    multiLang: true,
                    required: true,
                    span: 'full',
                  },
                ],
              },
            },
          ],
        },
      ],
    },
    {
      tabKey: 'contact',
      title: '联系方式',
      sections: [
        {
          sectionKey: 'contact',
          title: '联系方式',
          fields: [
            {
              fieldKey: 'contactBlock',
              type: 'object',
              label: '联系方式块',
              span: 'full',
              fields: [
                {
                  fieldKey: 'title',
                  type: 'localizedText',
                  label: '小标题',
                  multiLang: true,
                  placeholder: '直接联系我们',
                  span: 'full',
                },
                {
                  fieldKey: 'items',
                  type: 'arrayOfObject',
                  label: '联系项',
                  minItems: 1,
                  maxItems: 6,
                  itemTitleField: 'title.zh-CN',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      {
                        fieldKey: 'id',
                        type: 'text',
                        label: '稳定标识 ID',
                        description: '用于前台数据钩子；保留默认值，新建项可留空。',
                        placeholder: 'phone',
                        span: 'narrow',
                      },
                      {
                        fieldKey: 'icon',
                        type: 'icon',
                        label: 'Lucide 图标名',
                        frequentIcons: CONTACT_ICON_SUGGESTIONS,
                        defaultValue: 'Phone',
                        span: 'narrow',
                      },
                      {
                        fieldKey: 'title',
                        type: 'localizedText',
                        label: '标签文字',
                        multiLang: true,
                        placeholder: '销售热线',
                        span: 'wide',
                      },
                      {
                        fieldKey: 'value',
                        type: 'text',
                        label: '数值（电话/邮箱/链接）',
                        placeholder: '+86 ...',
                        span: 'wide',
                      },
                      {
                        fieldKey: 'href',
                        type: 'text',
                        label: '可选跳转链接',
                        placeholder: 'tel:+86... / mailto:...',
                        span: 'wide',
                      },
                    ],
                  },
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'background',
      title: '背景与样式',
      sections: [
        {
          sectionKey: 'background',
          title: '背景色',
          fields: [
            {
              fieldKey: 'background',
              type: 'object',
              label: '背景',
              span: 'full',
              fields: [
                {
                  fieldKey: 'sectionBg',
                  type: 'color',
                  label: '整段背景色',
                  defaultValue: '#0D2340',
                  span: 'narrow',
                },
                {
                  fieldKey: 'formCardBg',
                  type: 'color',
                  label: '表单卡背景色',
                  defaultValue: '#FFFFFF',
                  span: 'narrow',
                },
              ],
            },
          ],
        },
      ],
    },
  ],
};
