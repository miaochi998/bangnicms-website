import Link from 'next/link';
import { Trophy } from 'lucide-react';
import type { PanelDescriptor } from '../../_types';
import { iconHint } from '../../_helpers';
import { CaseStudiesListPanelClient } from './CaseStudiesListPanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'case-studies/list',
  configKey: 'caseStudiesListPage',
  title: '解决方案 · 列表页',
  description: '配置 /case-studies 列表页：Hero（深色面包屑 + 标题 + 描述 + 计数）+ 排序占位 + 主网格（封面 + 客户 + 摘要 + customFields chips）+ Sentinel 触底加载（客户端聚合）+ 空态。所有文案多语言。',
  dataPage: 'theme-config-fttp-case-studies-list',
  notApplicableTestId: 'case-studies-list-not-applicable',
  guardMode: 'theme-key',
  PanelClient: CaseStudiesListPanelClient,
  hint: iconHint(
    <Trophy className="h-4 w-4 shrink-0 mt-0.5" />,
    <>
      <p>
        <strong>提示</strong>：Hero 标题与 &quot;共 N 个案例&quot; 文案中的{' '}
        <code className="px-1 py-0.5 rounded bg-muted text-foreground">{'{n}'}</code>{' '}
        占位符会被前台自动替换为案例总数（来自数据库 case-study 分类的已发布文章数）。
      </p>
      <p className="mt-1">
        案例列表本身的内容（标题 / 客户 / 封面 / customFields）在{' '}
        <Link
          href="/articles"
          className="underline underline-offset-2 hover:text-foreground"
        >
          文章管理
        </Link>{' '}
        模块编辑。
      </p>
    </>,
  ),
};
