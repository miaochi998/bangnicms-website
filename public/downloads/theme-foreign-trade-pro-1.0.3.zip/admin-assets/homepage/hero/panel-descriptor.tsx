import type { PanelDescriptor } from '../../_types';
import { sparklesHint } from '../../_helpers';
import { HeroPanelClient } from './HeroPanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'homepage/hero',
  configKey: 'hero',
  title: 'Hero 大图',
  description: '首页第一屏主视觉：标题 / 特性 / 行动按钮 / 信任数据 / 旗舰产品卡 / 侧栏推广卡。',
  dataPage: 'theme-config-fttp-hero',
  notApplicableTestId: 'hero-not-applicable',
  guardMode: 'theme-key',
  PanelClient: HeroPanelClient,
  hint: sparklesHint(
    <>
      <p>
        <strong>提示</strong>：旗舰产品卡 + 侧栏推广卡均按{' '}
        <code className="font-mono">badge</code> 字符串自动从产品库读取。
        运营在「产品管理」编辑产品时，给某产品的{' '}
        <code className="font-mono">customFields.badge</code> 填上对应文字（如&quot;旗舰产品&quot;、&quot;新品上线&quot;），即可自动出现在 Hero。
      </p>
      <p className="mt-1">
        支持多语言：填中文后用顶部&quot;AI 多语言助手&quot;一键翻译到其他启用语言；只用中文站时无需翻译。
      </p>
    </>,
  ),
};
