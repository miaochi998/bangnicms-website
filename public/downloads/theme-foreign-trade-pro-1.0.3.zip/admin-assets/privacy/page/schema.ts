/**
 * fttp 隐私政策页 PanelSchemaV1 schema（节点 C commit-1b-β · S2.3）
 * -----------------------------------------------------------------------------
 * 接管自原 LegalPageConfigForm.tsx。fttp legal 页 storage 形态：
 *   {
 *     enabled, iconName,
 *     hero: { eyebrow, title, intro: { [lang]: string } },
 *     meta: { effectiveDate, lastUpdated, version, jurisdiction: { [lang]: string }, contactEmail },
 *     sections: [{ id, number, title: { [lang]: string }, blocks: 异构数组 }],
 *     bottomContact: { title, description: { [lang]: string } },
 *     relatedTitle: { [lang]: string },
 *     related: [{ title, href, desc: { [lang]: string } }]
 *   }
 *
 * **节点 C 范围降级**（已在节点 D 入账）：
 *   - sections[i].blocks 异构 5 kind 数组（p/ul/ol/callout/table）与 PanelSchemaV1
 *     的 arrayOfHeterogeneous 5 kind（paragraph/bulletList/callout/
 *     comparisonTable/numberedSteps）不兼容（kind 名 + 内部字段 + ul.items
 *     LocalizedString[] / table.rows LocalizedString[][] 多维数组形态）。
 *   - schema 暂仅暴露 sections[i] 的 id/number/title；blocks 通过
 *     fttp-storage-adapter.postprocessLegalWrite 从 prev 透传保留。
 *   - 阶段 2 / PanelSchemaV1 v1.1 升级或 panel-level transform 解决。
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

/**
 * 节点 A D-A1（S2.4）：terms/cookie 接管复用本 schema 工厂。
 * fttp privacy / terms / cookie 三页 storage 形态完全同构（manifest 验证），
 * 仅 panelKey / configPath / title 不同，因此抽出 createLegalPagePanel 工厂。
 */
export interface LegalPagePanelOptions {
  /** PanelRenderer panelKey · 例 'fttp.privacy-page' / 'fttp.terms-page' / 'fttp.cookie-page' */
  panelKey: string;
  /** Extension.config 子树路径 · 例 'config.privacyPage' / 'config.termsPage' / 'config.cookiePage' */
  configPath: string;
  /** 顶部工具条标题 · 例 '隐私政策页' / '服务条款页' / 'Cookie 政策页' */
  title: string;
}

export function createLegalPagePanel(options: LegalPagePanelOptions): PanelSchemaV1 {
  return {
    ...PRIVACY_PAGE_PANEL,
    panelKey: options.panelKey,
    previewAdapter: options.panelKey,
    title: options.title,
    configPath: options.configPath,
  };
}

export const PRIVACY_PAGE_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.privacy-page',
  version: 1,
  previewAdapter: 'fttp.privacy-page',
  title: '隐私政策页',
  configPath: 'config.privacyPage',
  tabs: [
    {
      tabKey: 'overview',
      title: '总开关 · 页头',
      sections: [
        {
          sectionKey: 'master',
          title: '整块开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用本页',
              description: '关闭后，前台 /privacy 路径将渲染为空。',
              defaultValue: true,
              controlsChildren: true,
              span: 'narrow',
            },
            {
              fieldKey: 'iconName',
              type: 'icon',
              label: '页面图标',
              defaultValue: 'Shield',
              span: 'narrow',
            },
          ],
        },
        {
          sectionKey: 'hero',
          title: '页头 Hero',
          fields: [
            {
              fieldKey: 'hero',
              type: 'object',
              label: '页头',
              span: 'full',
              fields: [
                {
                  fieldKey: 'eyebrow',
                  type: 'localizedText',
                  label: '小眉题（eyebrow）',
                  multiLang: true,
                  placeholder: '隐私政策',
                  span: 'wide',
                },
                {
                  fieldKey: 'title',
                  type: 'localizedText',
                  label: '主标题（title）',
                  multiLang: true,
                  required: true,
                  placeholder: '我们如何处理您的信息',
                  span: 'wide',
                },
                {
                  fieldKey: 'intro',
                  type: 'localizedText',
                  label: '导语（intro）',
                  multiLang: true,
                  placeholder: '您的信任是每一份贸易合作的基石……',
                  span: 'full',
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'meta',
      title: '文件信息',
      sections: [
        {
          sectionKey: 'meta',
          title: '文件元信息',
          description: '展示在页头下方的小卡片：生效日期 / 最近更新 / 版本号 / 适用法域 / 联系邮箱。',
          fields: [
            {
              fieldKey: 'meta',
              type: 'object',
              label: '文件元信息',
              span: 'full',
              fields: [
                {
                  fieldKey: 'effectiveDate',
                  type: 'date',
                  label: '生效日期',
                  span: 'narrow',
                },
                {
                  fieldKey: 'lastUpdated',
                  type: 'date',
                  label: '最近更新日期',
                  span: 'narrow',
                },
                {
                  fieldKey: 'version',
                  type: 'text',
                  label: '版本号',
                  placeholder: 'v4.2',
                  span: 'narrow',
                },
                {
                  fieldKey: 'contactEmail',
                  type: 'text',
                  label: '联系邮箱',
                  placeholder: 'privacy@bangnicms.com',
                  span: 'wide',
                },
                {
                  fieldKey: 'jurisdiction',
                  type: 'localizedText',
                  label: '适用法域',
                  multiLang: true,
                  placeholder: '中国 · GDPR · 英国 GDPR',
                  span: 'full',
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'sections',
      title: '正文章节',
      sections: [
        {
          sectionKey: 'sections',
          title: '章节列表',
          description:
            '配置每个章节的 id / 编号 / 标题。章节正文（段落 / 列表 / 提示框 / 表格）当前由模板默认值提供，本面板暂不直接编辑（计划阶段 2 升级支持）。',
          fields: [
            {
              fieldKey: 'sections',
              type: 'arrayOfObject',
              label: '章节',
              minItems: 0,
              maxItems: 30,
              itemTitleField: 'title.zh-CN',
              addLabel: '添加一个章节',
              span: 'full',
              itemSchema: {
                fields: [
                  {
                    fieldKey: 'id',
                    type: 'text',
                    label: '锚点 ID（英文，唯一）',
                    description: '用于页内目录跳转；如 introduction / data-collected。',
                    placeholder: 'section-id',
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'number',
                    type: 'text',
                    label: '编号',
                    placeholder: '01',
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'title',
                    type: 'localizedText',
                    label: '章节标题',
                    multiLang: true,
                    required: true,
                    placeholder: '概述与适用范围',
                    span: 'full',
                  },
                ],
              },
            },
          ],
        },
      ],
    },
    {
      tabKey: 'footer',
      title: '底部 · 相关链接',
      sections: [
        {
          sectionKey: 'bottomContact',
          title: '底部联系',
          fields: [
            {
              fieldKey: 'bottomContact',
              type: 'object',
              label: '底部联系卡',
              span: 'full',
              fields: [
                {
                  fieldKey: 'title',
                  type: 'localizedText',
                  label: '标题',
                  multiLang: true,
                  placeholder: '有关此文件的问题？',
                  span: 'wide',
                },
                {
                  fieldKey: 'description',
                  type: 'localizedText',
                  label: '描述',
                  multiLang: true,
                  placeholder: '我们的法务团队将在 5 个工作日内答复……',
                  span: 'full',
                },
              ],
            },
          ],
        },
        {
          sectionKey: 'related',
          title: '相关法律文件',
          fields: [
            {
              fieldKey: 'relatedTitle',
              type: 'localizedText',
              label: '相关文件区块标题',
              multiLang: true,
              placeholder: '相关法律文件',
              span: 'wide',
            },
            {
              fieldKey: 'related',
              type: 'arrayOfObject',
              label: '相关文件卡',
              minItems: 0,
              maxItems: 10,
              itemTitleField: 'title.zh-CN',
              addLabel: '添加一张相关文件卡',
              span: 'full',
              itemSchema: {
                fields: [
                  {
                    fieldKey: 'id',
                    type: 'text',
                    label: '稳定标识 ID',
                    description: '用于前台数据钩子；保留默认值，新建项可留空。',
                    placeholder: 'r-terms',
                    span: 'narrow',
                  },
                  {
                    fieldKey: 'title',
                    type: 'localizedText',
                    label: '文件标题',
                    multiLang: true,
                    required: true,
                    placeholder: '服务条款',
                    span: 'wide',
                  },
                  {
                    fieldKey: 'href',
                    type: 'text',
                    label: '跳转链接',
                    placeholder: '/terms',
                    span: 'wide',
                  },
                  {
                    fieldKey: 'desc',
                    type: 'localizedText',
                    label: '简介',
                    multiLang: true,
                    placeholder: '规范我们商业关系的规则与承诺。',
                    span: 'full',
                  },
                ],
              },
            },
          ],
        },
      ],
    },
  ],
};
