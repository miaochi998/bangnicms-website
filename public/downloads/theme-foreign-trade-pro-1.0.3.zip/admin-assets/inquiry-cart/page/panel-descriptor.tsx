import type { PanelDescriptor } from '../../_types';
import { InquiryCartPagePanelClient } from './InquiryCartPagePanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'inquiry-cart/page',
  configKey: 'inquiryCartPage',
  title: '询价车页',
  description: '配置 /inquiry-cart 询价车页：Hero（面包屑 + 标题 + 副标题）+ 4 步骤指示器 + 左侧购物车列表 + 右侧 sticky 提交表单 + Benefits + QuickContact + 底部推荐产品。所有文案多语言。',
  dataPage: 'theme-config-fttp-inquiry-cart-page',
  notApplicableTestId: 'inquiry-cart-page-not-applicable',
  guardMode: 'theme-key',
  PanelClient: InquiryCartPagePanelClient,
};
