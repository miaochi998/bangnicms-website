# Changelog

本主题遵循 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/) 格式。

## [1.0.0] - 开发中

### 阶段 2.0（脚手架贯通）

- 创建主题包目录结构（manifest / package / tsconfig / src/index.tsx 等 7 个脚手架文件）
- 注册到 `Extension` 表并挂载 `/__fttp-probe` 探针路由
- 通过 dispatcher 链路验证：esbuild → file URL dynamic import → RSC SSR 通畅
- 默认 `status=disabled`，需运营从 admin 启用

### 阶段 2.1+ 计划

详见 `docs/主题开发/09-阶段2开发计划.md` §4。
