import type { PanelDescriptor } from '../../_types';
import { ProductListPagePanelClient } from './ProductListPagePanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'product/product-list',
  configKey: 'productListPage',
  title: '产品列表页',
  description: '产品列表页 /products 整页配置：顶部横幅 + 快速筛选 + 左侧栏 + 工具栏 + 推广横幅 + 产品卡 + 分页。',
  dataPage: 'theme-config-fttp-product-list',
  notApplicableTestId: 'product-list-not-applicable',
  guardMode: 'theme-key',
  PanelClient: ProductListPagePanelClient,
};
