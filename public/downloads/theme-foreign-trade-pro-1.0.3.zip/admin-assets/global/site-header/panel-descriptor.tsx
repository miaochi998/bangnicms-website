import type { PanelDescriptor } from '../../_types';
import { SiteHeaderPanelClient } from './SiteHeaderPanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'global/site-header',
  configKey: 'siteHeader',
  title: '全站 · 网站页头（Site Header）',
  description: '配置三层 Header：① UtilityBar（顶部信息条·邮箱/电话/语言切换）② MainBar（Logo + 搜索 + 询盘车 + 主 CTA）③ NavRow（导航菜单）。所有文案多语言；启用语言由「语言管理」决定。',
  dataPage: 'theme-config-fttp-site-header',
  notApplicableTestId: 'site-header-not-applicable',
  guardMode: 'theme-key',
  PanelClient: SiteHeaderPanelClient,
};
