import { FileText } from 'lucide-react';
import type { PanelDescriptor } from '../../../_types';
import { iconHint } from '../../../_helpers';
import { NewsDetailPagePanelClient } from './NewsDetailPagePanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'news/detail/page',
  configKey: 'newsDetailPage',
  title: '新闻详情页',
  description: '配置 /news/:slug 详情页：Hero（深色面包屑 + 文章标题/摘要）+ Meta（日期 + 分类 chip + 顶部分享）+ 双栏（编辑器富文本 + TOC + 侧栏分享）+ 相关文章。所有文案多语言。',
  dataPage: 'theme-config-fttp-news-detail-page',
  notApplicableTestId: 'news-detail-page-not-applicable',
  guardMode: 'theme-key',
  PanelClient: NewsDetailPagePanelClient,
  hint: iconHint(
    <FileText className="h-4 w-4 shrink-0 mt-0.5" />,
    <>
      <p>
        <strong>提示</strong>：文章标题 / 摘要 / 正文 / 封面 / 分类全部从 Article 数据来；admin Form 仅配置框架文案与开关。
      </p>
      <p className="mt-1">
        TOC 自动从富文本 H2 提取并生成锚点；运营可关闭 TOC 显示。富文本基础排版样式由主题包注入（p / h2 / ul / blockquote / a 等）。
      </p>
      <p className="mt-1">
        若关闭「启用」开关，前台{' '}
        <code className="px-1 py-0.5 rounded bg-muted text-foreground">/news/:slug</code> 将渲染为空。
      </p>
    </>,
  ),
};
