/**
 * fttp 工厂详情页 PanelSchemaV1 schema（节点 C D-C1 · S2.4）
 * -----------------------------------------------------------------------------
 * 接管自原 FactoryPageConfigForm.tsx（980 行手写）。
 *
 * Storage 形态（FttpFactoryPageConfig · config.factoryPage）：
 *   {
 *     enabled,
 *     hero: { eyebrow, title, description, media (单 string URL · 图/视频按后缀判别) },
 *     capabilities: { eyebrow, title, description, items[{id, icon, title, description}], columns },
 *     stats:        { eyebrow, title, items[{id, value, label, description}], columns },
 *     bottomCta:    { eyebrow, title, description, primaryLabel, primaryHref }
 *   }
 *
 * 节点 C 范围降级（节点 D / 阶段 2 入账）：
 *   - `capabilities.items[i].icon` 是 `{kind, name, size?, color?}` 对象；schema 仅暴露
 *     `name`（IconField 输入），其余子字段从 prev 透传 → adapter 字段级 read/write
 *   - `capabilities.columns` / `stats.columns` `{desktop, tablet, mobile}` 网格列数 →
 *     展平为 desktopCols / tabletCols / mobileCols 三个 number 字段
 *   - `stats.items[i].value` 是 LocalizedText（不同于 homepage/factory section 的 string） → localizedText
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

export const FACTORY_PAGE_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.factory-page',
  version: 1,
  previewAdapter: 'fttp.factory-page',
  title: '工厂详情页',
  configPath: 'config.factoryPage',
  tabs: [
    {
      tabKey: 'overview',
      title: '总开关 · Hero',
      sections: [
        {
          sectionKey: 'master',
          title: '整块开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用本页面',
              description: '关闭后前台 /factory 渲染为空。',
              defaultValue: true,
              controlsChildren: true,
              span: 'narrow',
            },
          ],
        },
        {
          sectionKey: 'hero',
          title: 'Hero 主视觉',
          description: 'media 单 URL：图片直显，视频后缀（.mp4/.webm/.mov/.ogg）自动启用极简播放器。',
          fields: [
            {
              fieldKey: 'hero',
              type: 'object',
              label: 'Hero',
              span: 'full',
              fields: [
                { fieldKey: 'eyebrow', type: 'localizedText', label: '小眉题', multiLang: true, span: 'wide' },
                { fieldKey: 'title', type: 'localizedText', label: '主标题', multiLang: true, required: true, span: 'wide' },
                { fieldKey: 'description', type: 'localizedText', label: '描述', multiLang: true, span: 'full' },
                { fieldKey: 'media', type: 'mediaPicker', label: '主视觉媒体（图/视频）', accept: ['image', 'video'], span: 'full' },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'capabilities',
      title: '核心能力',
      sections: [
        {
          sectionKey: 'capabilities',
          title: '核心能力（icon + 标题 + 描述）',
          fields: [
            {
              fieldKey: 'capabilities',
              type: 'object',
              label: '核心能力',
              span: 'full',
              fields: [
                { fieldKey: 'eyebrow', type: 'localizedText', label: '小眉题', multiLang: true, span: 'wide' },
                { fieldKey: 'title', type: 'localizedText', label: '主标题', multiLang: true, span: 'wide' },
                { fieldKey: 'description', type: 'localizedText', label: '描述', multiLang: true, span: 'full' },
                { fieldKey: 'desktopCols', type: 'number', label: '桌面端列数', min: 1, max: 12, defaultValue: 4, span: 'narrow' },
                { fieldKey: 'tabletCols', type: 'number', label: '平板列数', min: 1, max: 12, defaultValue: 2, span: 'narrow' },
                { fieldKey: 'mobileCols', type: 'number', label: '移动端列数', min: 1, max: 12, defaultValue: 1, span: 'narrow' },
                {
                  fieldKey: 'items',
                  type: 'arrayOfObject',
                  label: '能力项',
                  minItems: 0,
                  maxItems: 16,
                  itemTitleField: 'title',
                  addLabel: '添加一项能力',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      { fieldKey: 'id', type: 'text', label: 'ID', placeholder: 'cap-xxx', span: 'narrow' },
                      { fieldKey: 'icon', type: 'icon', label: '图标', span: 'narrow' },
                      { fieldKey: 'title', type: 'localizedText', label: '名称', multiLang: true, required: true, span: 'wide' },
                      { fieldKey: 'description', type: 'localizedText', label: '描述', multiLang: true, span: 'full' },
                    ],
                  },
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'stats',
      title: '关键数字',
      sections: [
        {
          sectionKey: 'stats',
          title: '关键数字（多语言数值 + 标签 + 说明）',
          fields: [
            {
              fieldKey: 'stats',
              type: 'object',
              label: '关键数字',
              span: 'full',
              fields: [
                { fieldKey: 'eyebrow', type: 'localizedText', label: '小眉题', multiLang: true, span: 'wide' },
                { fieldKey: 'title', type: 'localizedText', label: '主标题', multiLang: true, span: 'wide' },
                { fieldKey: 'desktopCols', type: 'number', label: '桌面端列数', min: 1, max: 12, defaultValue: 3, span: 'narrow' },
                { fieldKey: 'tabletCols', type: 'number', label: '平板列数', min: 1, max: 12, defaultValue: 2, span: 'narrow' },
                { fieldKey: 'mobileCols', type: 'number', label: '移动端列数', min: 1, max: 12, defaultValue: 1, span: 'narrow' },
                {
                  fieldKey: 'items',
                  type: 'arrayOfObject',
                  label: '数字项',
                  minItems: 0,
                  maxItems: 16,
                  itemTitleField: 'label',
                  addLabel: '添加一项数字',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      { fieldKey: 'id', type: 'text', label: 'ID', placeholder: 'stat-xxx', span: 'narrow' },
                      { fieldKey: 'value', type: 'localizedText', label: '数值', multiLang: true, required: true, span: 'wide' },
                      { fieldKey: 'label', type: 'localizedText', label: '标签', multiLang: true, required: true, span: 'wide' },
                      { fieldKey: 'description', type: 'localizedText', label: '说明', multiLang: true, span: 'full' },
                    ],
                  },
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'cta',
      title: '底部 CTA',
      sections: [
        {
          sectionKey: 'cta',
          title: '底部行动召唤',
          fields: [
            {
              fieldKey: 'bottomCta',
              type: 'object',
              label: '底部 CTA',
              span: 'full',
              fields: [
                { fieldKey: 'eyebrow', type: 'localizedText', label: '小眉题', multiLang: true, span: 'wide' },
                { fieldKey: 'title', type: 'localizedText', label: '主标题', multiLang: true, span: 'wide' },
                { fieldKey: 'description', type: 'localizedText', label: '描述', multiLang: true, span: 'full' },
                { fieldKey: 'primaryLabel', type: 'localizedText', label: '按钮文字', multiLang: true, span: 'wide' },
                { fieldKey: 'primaryHref', type: 'text', label: '按钮链接', placeholder: '/contact?subject=factory-tour', span: 'wide' },
              ],
            },
          ],
        },
      ],
    },
  ],
};
