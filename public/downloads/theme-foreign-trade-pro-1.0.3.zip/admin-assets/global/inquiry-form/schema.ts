/**
 * fttp 全站通用询盘表单 PanelSchemaV1 schema（阶段 2 节点 B · B-D5）
 * -----------------------------------------------------------------------------
 * 接管自原 InquiryFormConfigForm.tsx（742 行手写）。
 *
 * Storage 形态（BangNiCmsThemeInquiryFormConfig · config.inquiryForm）：
 *   {
 *     formCardTitle, requiredHint, submitLabel, submittingLabel, resetLabel,
 *     successTitle, successMessage, successMore, securityNote,                     // 9 LT
 *     fields:        { name, email, phone, country, message },                      // 5 LT
 *     placeholders:  { name?, email?, phone?, country?, message? },                 // 5 LT 可选
 *     errors:        { nameRequired, messageRequired, contactRequired, submitFailed }, // 4 LT
 *     consent:       { text, privacyLabel, privacyHref:string },                    // 2 LT + 1 text
 *   }
 *
 * 形态特点：纯 LocalizedText × 25 + 1 plain text（consent.privacyHref）
 *   - storage 与 schema 1:1 对齐 · createFttpStorageAdapter 走 default 分支
 *   - 无 ListField（5 字段固定 · 业务上不允许增删 · 见 shared-types 注释）
 *
 * 启动指令档预期 createNullableObjectField 首场实战（"nullable 同意条款 section"）→
 * 实测 schema 不匹配：consent 段是必填的（含必填 text + privacyLabel + privacyHref），
 * 不存在「禁用 → null」语义。节点 B 完工汇报 §X 登记此发现。
 *
 * UX 退化登记（节点 B 完工汇报 §X）：
 *   - 原 ConfigForm 全站表单始终启用（顶部 enabled toolbar 锁死 true）；新版 master
 *     enabled 开关允许切（toggle 仅写 storage `enabled` 字段，前台不消费），UX 多余
 *     开关；登记节点 D 总收尾时评估是否补 readonly master 模式。
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

export const INQUIRY_FORM_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.inquiry-form',
  version: 1,
  title: '全站通用 · 询盘表单文案',
  configPath: 'config.inquiryForm',
  tabs: [
    {
      tabKey: 'basic',
      title: '基础文案',
      sections: [
        {
          sectionKey: 'master',
          title: '总开关（虚拟 · 前台不消费 · 见 schema 注释 UX 退化登记）',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用询盘表单',
              defaultValue: true,
              controlsChildren: true,
              span: 'narrow',
            },
          ],
        },
        {
          sectionKey: 'card',
          title: '表单卡片基础文案',
          fields: [
            { fieldKey: 'formCardTitle', type: 'localizedText', label: '表单卡片标题', multiLang: true, span: 'wide' },
            { fieldKey: 'requiredHint', type: 'localizedText', label: '"必填" 提示语', multiLang: true, span: 'wide' },
            { fieldKey: 'submitLabel', type: 'localizedText', label: '提交按钮（默认态）', multiLang: true, span: 'medium' },
            { fieldKey: 'submittingLabel', type: 'localizedText', label: '提交按钮（loading 态）', multiLang: true, span: 'medium' },
            { fieldKey: 'resetLabel', type: 'localizedText', label: '重置按钮（仅首页 InquiryCTA 风格使用）', multiLang: true, span: 'medium' },
            { fieldKey: 'securityNote', type: 'localizedText', label: '表单底部安全提示', multiLang: true, span: 'full' },
          ],
        },
      ],
    },
    {
      tabKey: 'fields',
      title: '字段标签 & 占位符',
      sections: [
        {
          sectionKey: 'fieldLabels',
          title: '5 个字段标签（业务上不允许增删）',
          fields: [
            {
              fieldKey: 'fields',
              type: 'object',
              label: '字段标签',
              span: 'full',
              fields: [
                { fieldKey: 'name', type: 'localizedText', label: '姓名', multiLang: true, required: true, span: 'medium' },
                { fieldKey: 'email', type: 'localizedText', label: '邮箱', multiLang: true, required: true, span: 'medium' },
                { fieldKey: 'phone', type: 'localizedText', label: 'WhatsApp / 电话', multiLang: true, required: true, span: 'medium' },
                { fieldKey: 'country', type: 'localizedText', label: '国家 / 地区', multiLang: true, required: true, span: 'medium' },
                { fieldKey: 'message', type: 'localizedText', label: '询盘详细说明', multiLang: true, required: true, span: 'wide' },
              ],
            },
          ],
        },
        {
          sectionKey: 'placeholders',
          title: '5 个字段占位符（可选 · 留空时用字段标签兜底）',
          fields: [
            {
              fieldKey: 'placeholders',
              type: 'object',
              label: '占位符',
              span: 'full',
              fields: [
                { fieldKey: 'name', type: 'localizedText', label: '姓名占位符', multiLang: true, span: 'medium' },
                { fieldKey: 'email', type: 'localizedText', label: '邮箱占位符', multiLang: true, span: 'medium' },
                { fieldKey: 'phone', type: 'localizedText', label: 'WhatsApp 占位符', multiLang: true, span: 'medium' },
                { fieldKey: 'country', type: 'localizedText', label: '国家 / 地区占位符', multiLang: true, span: 'medium' },
                { fieldKey: 'message', type: 'localizedText', label: '询盘详细说明占位符', multiLang: true, span: 'wide' },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'feedback',
      title: '反馈 & 错误',
      sections: [
        {
          sectionKey: 'success',
          title: '提交成功面板文案',
          fields: [
            { fieldKey: 'successTitle', type: 'localizedText', label: '成功面板标题', multiLang: true, span: 'wide' },
            { fieldKey: 'successMessage', type: 'localizedText', label: '成功面板说明', multiLang: true, multiline: true, span: 'full' },
            { fieldKey: 'successMore', type: 'localizedText', label: '附加提示', multiLang: true, multiline: true, span: 'full' },
          ],
        },
        {
          sectionKey: 'errors',
          title: '错误信息（4 类）',
          fields: [
            {
              fieldKey: 'errors',
              type: 'object',
              label: '错误信息',
              span: 'full',
              fields: [
                { fieldKey: 'nameRequired', type: 'localizedText', label: '姓名必填', multiLang: true, span: 'medium' },
                { fieldKey: 'messageRequired', type: 'localizedText', label: '说明必填', multiLang: true, span: 'medium' },
                { fieldKey: 'contactRequired', type: 'localizedText', label: '邮箱或 WhatsApp 至少填一', multiLang: true, span: 'wide' },
                { fieldKey: 'submitFailed', type: 'localizedText', label: '提交失败', multiLang: true, span: 'wide' },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'consent',
      title: '同意条款',
      sections: [
        {
          sectionKey: 'consent',
          title: '同意条款（含隐私政策链接）',
          description: 'consent.text 中使用 {privacyLink} 占位符 → 前台拆分并嵌入 a 标签，链接到 consent.privacyHref。',
          fields: [
            {
              fieldKey: 'consent',
              type: 'object',
              label: '同意条款',
              span: 'full',
              fields: [
                { fieldKey: 'text', type: 'localizedText', label: '同意条款文案模板（含 {privacyLink} 占位）', multiLang: true, multiline: true, required: true, span: 'full' },
                { fieldKey: 'privacyLabel', type: 'localizedText', label: '链接显示文字（多语言）', multiLang: true, required: true, span: 'wide' },
                { fieldKey: 'privacyHref', type: 'text', label: '链接地址（不多语言 · 通常 /privacy）', placeholder: '/privacy', required: true, span: 'wide' },
              ],
            },
          ],
        },
      ],
    },
  ],
};
