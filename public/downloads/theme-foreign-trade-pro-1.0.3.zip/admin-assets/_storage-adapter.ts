/**
 * fttp 主题专属数据形态适配器（节点 C 阻断裁决 · S2.3）
 * -----------------------------------------------------------------------------
 * 隔离 fttp 主题历史数据形态与底层 PanelSchemaV1 标准形态之间的差异。
 *
 * 阻断裁决档 §2.2 + commit-1b-α 阻断报告 §3 方案 A：
 *   - **唯一文件**：`apps/admin/src/components/theme-config/fttp-storage-adapter.ts`
 *   - 命名前缀 `fttp-` 明确 fttp 专属
 *   - 阶段 2 fttp 全量迁移完成时**整文件删除** + CI 白名单第 12 条移除
 *
 * 处理规则（按 panelKey 分支）：
 *
 *   - **fttp.trust-strip**（per-field { translations, style }）：
 *     字段级 read/write 处理 LocalizedText（commit-1a 验证通过）
 *
 *   - **fttp.featured-products**（per-lang 反向嵌套）：
 *     storage `translations: { [lang]: { sectionTag, sectionTitle, ... } }`
 *     ↔ render 顶层 `sectionTag: { [lang]: string }, sectionTitle: ...`
 *     使用 preprocessRead 拍平 + postprocessWrite 归并；style/layout 等非渲染
 *     字段通过 prev merge 保留
 *
 *   - **fttp.why-choose-us**（混合：header per-lang + items[i] per-lang）：
 *     header.translations 拍平为 `headerSectionTag/...`；items[i].translations
 *     拍平为 items[i].title/description/...；其它 passthrough
 *
 *   - **fttp.inquiry-cta**（标准 PanelSchemaV1 LocalizedString）：
 *     字段级 identity；style 非渲染字段通过 prev merge 保留
 *
 *   - **fttp.hero / fttp.legal**：commit-1b-β 后续填充
 *
 * 已知退化（节点 D 入账 / 阶段 2 处理）：
 *   - LocalizedText.style / panel.style 子字段在新渲染器内不可见、不可编辑；
 *     运营保存后通过 prev merge 透传保留
 */

import type { PanelDataAdapter } from '@/components/panel-renderer/types';
import {
  readStyledLocalizedText,
  writeStyledLocalizedText,
} from '@/components/theme-config/styled-localized-text-adapter';

function isObjectRecord(v: unknown): v is Record<string, unknown> {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/* ─── per-lang 反向嵌套 ↔ per-field { lang: value } 工具 ────────────── */

/**
 * 把 `translations: { [lang]: { [fieldKey]: string } }` 拍平为
 * `{ [fieldKey]: { [lang]: string } }`。返回展平后的 map（原 storage 不变）。
 */
function flattenLangNested(
  translations: Record<string, Record<string, string>>,
): Record<string, Record<string, string>> {
  const out: Record<string, Record<string, string>> = {};
  for (const lang of Object.keys(translations)) {
    const langObj = translations[lang];
    if (!isObjectRecord(langObj)) continue;
    for (const fieldKey of Object.keys(langObj)) {
      const v = langObj[fieldKey];
      if (typeof v !== 'string') continue;
      if (!out[fieldKey]) out[fieldKey] = {};
      out[fieldKey][lang] = v;
    }
  }
  return out;
}

/**
 * 反向：把 `{ [fieldKey]: { [lang]: string } }` 归并为
 * `translations: { [lang]: { [fieldKey]: string } }`。
 *
 * `fieldKeys` 限定哪些字段属于 LocalizedText 集合（避免误把 layout 等非语言字段卷进 translations）。
 */
function unflattenLangNested(
  walked: Record<string, unknown>,
  fieldKeys: ReadonlyArray<string>,
): Record<string, Record<string, string>> {
  const translations: Record<string, Record<string, string>> = {};
  for (const fieldKey of fieldKeys) {
    const langMap = walked[fieldKey];
    if (!isObjectRecord(langMap)) continue;
    for (const lang of Object.keys(langMap)) {
      const v = langMap[lang];
      if (typeof v !== 'string') continue;
      if (!translations[lang]) translations[lang] = {};
      translations[lang][fieldKey] = v;
    }
  }
  return translations;
}

/* ─── featured-products 专属 transform ────────────────────────────── */

const FEATURED_PRODUCTS_LANG_FIELDS = [
  'sectionTag',
  'sectionTitle',
  'sectionDescription',
  'viewAllLabel',
  'inquiryCtaLabel',
] as const;

function preprocessFeaturedProductsRead(
  storedRoot: Record<string, unknown>,
): Record<string, unknown> {
  const translations = storedRoot.translations;
  if (!isObjectRecord(translations)) return storedRoot;
  const flat = flattenLangNested(translations as Record<string, Record<string, string>>);
  // 把 translations 拆出来，5 个字段拍到顶层，其它 keys（enabled / style / layout）保留
  const { translations: _t, ...rest } = storedRoot;
  return { ...rest, ...flat };
}

function postprocessFeaturedProductsWrite(
  walked: Record<string, unknown>,
  prevStoredRoot: Record<string, unknown>,
): Record<string, unknown> {
  const translations = unflattenLangNested(walked, FEATURED_PRODUCTS_LANG_FIELDS);
  // 移除 walked 顶层 5 个 lang 字段（已归并到 translations），保留其它（enabled / layout）
  const filtered: Record<string, unknown> = {};
  for (const k of Object.keys(walked)) {
    if (!(FEATURED_PRODUCTS_LANG_FIELDS as ReadonlyArray<string>).includes(k)) {
      filtered[k] = walked[k];
    }
  }
  return {
    ...prevStoredRoot, // 保留 prev 中 schema 不感知的字段（如 style）
    ...filtered, // 覆盖 enabled / layout 等
    translations, // 归并后的 per-lang 反向嵌套
  };
}

/* ─── why-choose-us 专属 transform ────────────────────────────── */

const WHY_CHOOSE_US_HEADER_FIELDS = [
  'sectionTag',
  'sectionTitle',
  'sectionDescription',
] as const;
const WHY_CHOOSE_US_ITEM_FIELDS = ['title', 'description', 'metric', 'visualAlt'] as const;

function preprocessWhyChooseUsRead(
  storedRoot: Record<string, unknown>,
): Record<string, unknown> {
  const out: Record<string, unknown> = { ...storedRoot };
  // 顶层 headerTranslations: { [lang]: { sectionTag, ... } } → header.{ [field]: { [lang]: string } }
  const headerTranslations = storedRoot.headerTranslations;
  if (isObjectRecord(headerTranslations)) {
    const flat = flattenLangNested(
      headerTranslations as Record<string, Record<string, string>>,
    );
    delete out.headerTranslations;
    out.header = flat;
  }
  // items[i].translations 拍平到 items[i].{ title, description, ... }
  const items = storedRoot.items;
  if (Array.isArray(items)) {
    out.items = items.map((it) => {
      if (!isObjectRecord(it)) return it;
      const itemTranslations = it.translations;
      if (!isObjectRecord(itemTranslations)) return it;
      const flat = flattenLangNested(
        itemTranslations as Record<string, Record<string, string>>,
      );
      const { translations: _t, ...itemRest } = it;
      return { ...itemRest, ...flat };
    });
  }
  return out;
}

function postprocessWhyChooseUsWrite(
  walked: Record<string, unknown>,
  prevStoredRoot: Record<string, unknown>,
): Record<string, unknown> {
  const out: Record<string, unknown> = { ...prevStoredRoot, ...walked };
  // header → headerTranslations 反向归并
  const walkedHeader = walked.header;
  if (isObjectRecord(walkedHeader)) {
    const headerTranslations = unflattenLangNested(
      walkedHeader,
      WHY_CHOOSE_US_HEADER_FIELDS,
    );
    delete out.header;
    out.headerTranslations = headerTranslations;
  }
  // items 反向归并 + id 兜底
  if (Array.isArray(walked.items)) {
    const prevItems = Array.isArray(prevStoredRoot.items) ? prevStoredRoot.items : [];
    out.items = walked.items.map((it: unknown, i: number) => {
      if (!isObjectRecord(it)) return it;
      const translations = unflattenLangNested(it, WHY_CHOOSE_US_ITEM_FIELDS);
      const filtered: Record<string, unknown> = {};
      for (const k of Object.keys(it)) {
        if (!(WHY_CHOOSE_US_ITEM_FIELDS as ReadonlyArray<string>).includes(k)) {
          filtered[k] = it[k];
        }
      }
      const prevItem = isObjectRecord(prevItems[i]) ? prevItems[i] : {};
      const ensuredId =
        (filtered.id as string | undefined) ??
        (prevItem.id as string | undefined) ??
        `item-${Math.random().toString(36).slice(2, 8)}-${Date.now().toString(36)}`;
      return { ...prevItem, ...filtered, id: ensuredId, translations };
    });
  }
  return out;
}

/* ─── hero 专属 transform（只补 id 兜底，无形态转换）──────────────── */

const HERO_ID_ARRAYS = ['bullets', 'trustStats', 'sideSlides'] as const;

function postprocessHeroWrite(
  walked: Record<string, unknown>,
  prevStoredRoot: Record<string, unknown>,
): Record<string, unknown> {
  const out: Record<string, unknown> = { ...prevStoredRoot, ...walked };
  for (const arrKey of HERO_ID_ARRAYS) {
    const walkedArr = walked[arrKey];
    if (!Array.isArray(walkedArr)) continue;
    const prevArr = Array.isArray(prevStoredRoot[arrKey])
      ? (prevStoredRoot[arrKey] as unknown[])
      : [];
    out[arrKey] = walkedArr.map((it, i) => {
      if (!isObjectRecord(it)) return it;
      const ensuredId =
        (typeof it.id === 'string' && it.id) ||
        (isObjectRecord(prevArr[i]) && typeof prevArr[i].id === 'string'
          ? (prevArr[i].id as string)
          : `${arrKey}-${Math.random().toString(36).slice(2, 8)}-${Date.now().toString(36)}`);
      return { ...it, id: ensuredId };
    });
  }
  return out;
}

/* ─── factory section 专属 transform（节点 B D-B1 · S2.4）──────── */
//
// 三处退步需要 adapter 兜底（详见 homepage/factory/schema.ts 头注）：
//   1. `thumbnails: string[]` vs arrayOfObject `[{id,url}]` → read/write 互转
//   2. `hero.media.{image,video,poster}` 前台消费纯 string URL；mediaPicker
//      onChange 生成 `{url, focalPoint?}` 对象 → write 时取 renderValue.url 降级
//   3. `style` 9 段 TextStyle schema 不暴露 → 从 prev 透传保留
//
// 字段级 mediaPicker 降级由 write hook 内 ctx.fieldType 分支处理（对所有
// factory-page 内 mediaPicker 统一生效）。

function preprocessFactoryRead(storedRoot: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = { ...storedRoot };
  // thumbnails: string[] → [{id, url}]
  const thumbs = storedRoot.thumbnails;
  if (Array.isArray(thumbs)) {
    out.thumbnails = thumbs
      .filter((u) => typeof u === 'string')
      .map((u, i) => ({ id: `thumb-${i}-${Math.random().toString(36).slice(2, 6)}`, url: u }));
  } else {
    out.thumbnails = [];
  }
  return out;
}

function postprocessFactoryWrite(
  walked: Record<string, unknown>,
  prevStoredRoot: Record<string, unknown>,
): Record<string, unknown> {
  const out: Record<string, unknown> = { ...prevStoredRoot, ...walked };
  // thumbnails: [{id,url}] → string[]（过滤空 url）
  if (Array.isArray(walked.thumbnails)) {
    out.thumbnails = walked.thumbnails
      .filter(isObjectRecord)
      .map((t) => {
        const url = (t as Record<string, unknown>).url;
        return typeof url === 'string' ? url : '';
      })
      .filter((u) => u.length > 0);
  }
  // style 9 段不在 schema 暴露 → 从 prev 保留（…prevStoredRoot 已覆盖，此处不需额外处理）
  return out;
}

/* ─── factoryPage / aboutPage / qualityPage 共用 columns 展平工具（节点 C · S2.4）─ */
//
// 三独立页 storage 形态有 `columns: { desktop, tablet, mobile }`（部分子段）。
// PanelSchemaV1 不支持嵌套对象内裸 number 三件套，schema 改为 desktopCols /
// tabletCols / mobileCols 三个顶层 number 字段，adapter 双向转换。

const COLUMN_KEYS = ['desktop', 'tablet', 'mobile'] as const;

function flattenColumns(
  parent: Record<string, unknown>,
): Record<string, unknown> {
  const cols = parent.columns;
  if (!isObjectRecord(cols)) return parent;
  const out = { ...parent };
  delete out.columns;
  for (const k of COLUMN_KEYS) {
    const v = cols[k];
    if (typeof v === 'number') out[`${k}Cols`] = v;
  }
  return out;
}

function unflattenColumns(
  walked: Record<string, unknown>,
  prev: Record<string, unknown> | undefined,
): Record<string, unknown> {
  const out: Record<string, unknown> = { ...walked };
  const prevCols = isObjectRecord(prev?.columns) ? (prev!.columns as Record<string, unknown>) : {};
  const cols: Record<string, unknown> = { ...prevCols };
  let touched = false;
  for (const k of COLUMN_KEYS) {
    const flatKey = `${k}Cols`;
    if (flatKey in walked) {
      const v = walked[flatKey];
      if (typeof v === 'number') cols[k] = v;
      delete out[flatKey];
      touched = true;
    }
  }
  if (touched) out.columns = cols;
  return out;
}

/* ─── factoryPage 专属 transform（节点 C D-C1 · S2.4）──────────────── */
//
// storage 形态：{ enabled, hero{...}, capabilities{..., columns}, stats{..., columns}, bottomCta{...} }
// schema 暴露 capabilities/stats 的 columns 展平为 desktopCols/tabletCols/mobileCols。
// items[i].icon 形态可能是 string 或 {kind,name,size?,color?} → 字段级 icon read/write 在
// 通用 createFttpStorageAdapter().read/write 内通过 ctx.fieldType==='icon' 分支处理（参 §write）。

function preprocessFactoryPageRead(storedRoot: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = { ...storedRoot };
  const caps = storedRoot.capabilities;
  if (isObjectRecord(caps)) out.capabilities = flattenColumns(caps);
  const stats = storedRoot.stats;
  if (isObjectRecord(stats)) out.stats = flattenColumns(stats);
  return out;
}

function postprocessFactoryPageWrite(
  walked: Record<string, unknown>,
  prevStoredRoot: Record<string, unknown>,
): Record<string, unknown> {
  const out: Record<string, unknown> = { ...prevStoredRoot, ...walked };
  if (isObjectRecord(walked.capabilities)) {
    const prevCaps = isObjectRecord(prevStoredRoot.capabilities) ? prevStoredRoot.capabilities : undefined;
    out.capabilities = { ...(prevCaps ?? {}), ...unflattenColumns(walked.capabilities, prevCaps) };
  }
  if (isObjectRecord(walked.stats)) {
    const prevStats = isObjectRecord(prevStoredRoot.stats) ? prevStoredRoot.stats : undefined;
    out.stats = { ...(prevStats ?? {}), ...unflattenColumns(walked.stats, prevStats) };
  }
  return out;
}

/* ─── aboutPage 专属 transform（节点 C D-C2 · S2.4）─────────────────── */
//
// storage 形态：{ enabled, hero, story, stats{items}, purpose{mission,vision,values{items}}, timeline{items} }
// 无 columns 字段；icon 子字段全是 {kind,name,size?,color?} 对象 → 字段级 icon read/write。
// hero/story/stats/purpose/timeline 各自的 style 段不暴露，从 prev 透传（顶层浅 merge 已覆盖）。

function postprocessAboutPageWrite(
  walked: Record<string, unknown>,
  prevStoredRoot: Record<string, unknown>,
): Record<string, unknown> {
  // 顶层浅 merge：保留 prev 中各 section 的 style 子段（schema 不暴露）。但需要按 section 嵌套 merge
  // 否则 walked.purpose 会整段覆盖 prev.purpose（丢 style）。
  const out: Record<string, unknown> = { ...prevStoredRoot };
  for (const k of Object.keys(walked)) {
    const wv = walked[k];
    const pv = prevStoredRoot[k];
    if (isObjectRecord(wv) && isObjectRecord(pv)) {
      out[k] = { ...pv, ...wv };
    } else {
      out[k] = wv;
    }
  }
  return out;
}

/* ─── qualityPage 专属 transform（节点 C D-C3 · S2.4）──────────────── */
//
// storage 形态：{ enabled, hero, headlineMetrics{items}, qcProcess{items[i].tools[]}, equipment{columns,items} }
// equipment.columns 展平；qcSteps[i].tools[] 二级嵌套（PanelSchemaV1 D2 决策 nestedArray 2 层硬限）。
// 各 section style 段不暴露（同 aboutPage）。

function preprocessQualityPageRead(storedRoot: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = { ...storedRoot };
  const eq = storedRoot.equipment;
  if (isObjectRecord(eq)) out.equipment = flattenColumns(eq);
  return out;
}

function postprocessQualityPageWrite(
  walked: Record<string, unknown>,
  prevStoredRoot: Record<string, unknown>,
): Record<string, unknown> {
  const out: Record<string, unknown> = { ...prevStoredRoot };
  for (const k of Object.keys(walked)) {
    const wv = walked[k];
    const pv = prevStoredRoot[k];
    if (k === 'equipment' && isObjectRecord(wv) && isObjectRecord(pv)) {
      out.equipment = { ...pv, ...unflattenColumns(wv, pv) };
    } else if (isObjectRecord(wv) && isObjectRecord(pv)) {
      out[k] = { ...pv, ...wv };
    } else {
      out[k] = wv;
    }
  }
  return out;
}

/* ─── legal 专属 transform（sections[i].blocks 透传保留）──────────── */
//
// fttp legal page 的 sections[i].blocks 是 5 kind 异构数组（p/ul/ol/callout/table），
// 与 PanelSchemaV1 的 arrayOfHeterogeneous 5 kind（paragraph/bulletList/callout/
// comparisonTable/numberedSteps）不兼容（kind 名 + 内部字段双双不一致；ul.items
// 是 LocalizedString[] 裸数组，table.rows 是 LocalizedString[][] 二维数组）。
//
// 节点 C 范围降级：legal schema 仅暴露 sections[i] 的 id/number/title；blocks
// 通过 postprocessWrite 从 prev 透传保留；阶段 2 / 节点 D 入账由 PanelSchemaV1
// v1.1 升级或 panel-level transform 解决。

function postprocessLegalWrite(
  walked: Record<string, unknown>,
  prevStoredRoot: Record<string, unknown>,
): Record<string, unknown> {
  const out: Record<string, unknown> = { ...prevStoredRoot, ...walked };
  if (Array.isArray(walked.sections)) {
    const prevSections = Array.isArray(prevStoredRoot.sections)
      ? (prevStoredRoot.sections as unknown[])
      : [];
    out.sections = walked.sections.map((it: unknown, i: number) => {
      if (!isObjectRecord(it)) return it;
      const prevItem = isObjectRecord(prevSections[i]) ? prevSections[i] : {};
      const prevBlocks = (prevItem as Record<string, unknown>).blocks;
      // 保留 prev.blocks（schema 不暴露，运营改不动 blocks），并覆盖其它字段（id/number/title 等）
      return {
        ...prevItem,
        ...it,
        ...(prevBlocks !== undefined ? { blocks: prevBlocks } : {}),
      };
    });
  }
  return out;
}

/* ─── site-header 专属 transform（阶段 2 节点 B · B-D1）──────────────── */
//
// storage 形态：{ enabled, utilityBar:{enabled, showLanguageSwitcher,
//   contactItems[], quickLinks[]}, mainBar:{search, inquiryCartLink, showInquiryCount},
//   navRow:{showAllCategoriesButton, trustBadges[]} }
//
// 三个 ListField（contactItems / quickLinks / trustBadges）每项含 `label`（兜底
// 字符串）+ `labelTranslations`（多语言 map）。原 ConfigForm 编辑 labelTranslations
// 时自动同步 label = labelTranslations[defaultLang]，前台消费链 `labelTranslations
// [lang] ?? label` 因此始终拿到最新值。
//
// 节点 B 为保留该 UX 不退步：schema 仅暴露 labelTranslations（多语言原语），
// 不暴露 label 字段；postprocessWrite 内同步 label = labelTranslations[defaultLang]
// ?? prevItem.label ?? ''，保证 round-trip 内 label 与默认语言翻译一致。
//
// 同时 items[].id 写回时若为空则补 `${prefix}-${rand}-${ts}` 兜底（沿用 hero/
// why-choose-us pattern · S2.3 节点 D round-trip 守护要求 id 序列保留）。

const SITE_HEADER_ITEM_ID_PREFIX = {
  contactItems: 'c',
  quickLinks: 'q',
  trustBadges: 't',
} as const;

function ensureItemId(
  walked: Record<string, unknown>,
  prev: Record<string, unknown> | undefined,
  prefix: string,
): string {
  const w = walked.id;
  if (typeof w === 'string' && w) return w;
  const p = prev?.id;
  if (typeof p === 'string' && p) return p;
  return `${prefix}-${Math.random().toString(36).slice(2, 8)}-${Date.now().toString(36)}`;
}

function syncSiteHeaderLabel(
  walked: Record<string, unknown>,
  prev: Record<string, unknown> | undefined,
  defaultLang: string,
): string {
  const translations = walked.labelTranslations;
  if (isObjectRecord(translations)) {
    const v = translations[defaultLang];
    if (typeof v === 'string' && v) return v;
  }
  if (typeof walked.label === 'string' && walked.label) return walked.label;
  if (prev && typeof prev.label === 'string') return prev.label;
  return '';
}

function postprocessSiteHeaderWrite(
  walked: Record<string, unknown>,
  prevStoredRoot: Record<string, unknown>,
  defaultLang: string,
): Record<string, unknown> {
  const out: Record<string, unknown> = { ...prevStoredRoot };
  for (const k of Object.keys(walked)) {
    const wv = walked[k];
    const pv = prevStoredRoot[k];
    if (isObjectRecord(wv) && isObjectRecord(pv)) {
      out[k] = { ...pv, ...wv };
    } else {
      out[k] = wv;
    }
  }
  // utilityBar.contactItems / quickLinks · 同步 label + 补 id
  if (isObjectRecord(out.utilityBar)) {
    const utility = out.utilityBar as Record<string, unknown>;
    const prevUtility = isObjectRecord(prevStoredRoot.utilityBar)
      ? (prevStoredRoot.utilityBar as Record<string, unknown>)
      : {};
    for (const arrKey of ['contactItems', 'quickLinks'] as const) {
      const walkedArr = utility[arrKey];
      if (!Array.isArray(walkedArr)) continue;
      const prevArr = Array.isArray(prevUtility[arrKey])
        ? (prevUtility[arrKey] as unknown[])
        : [];
      utility[arrKey] = walkedArr.map((it: unknown, i: number) => {
        if (!isObjectRecord(it)) return it;
        const prevItem = isObjectRecord(prevArr[i]) ? (prevArr[i] as Record<string, unknown>) : undefined;
        return {
          ...it,
          id: ensureItemId(it, prevItem, SITE_HEADER_ITEM_ID_PREFIX[arrKey]),
          label: syncSiteHeaderLabel(it, prevItem, defaultLang),
        };
      });
    }
  }
  // navRow.trustBadges · 同步 label + 补 id
  if (isObjectRecord(out.navRow)) {
    const nav = out.navRow as Record<string, unknown>;
    const prevNav = isObjectRecord(prevStoredRoot.navRow)
      ? (prevStoredRoot.navRow as Record<string, unknown>)
      : {};
    if (Array.isArray(nav.trustBadges)) {
      const prevArr = Array.isArray(prevNav.trustBadges)
        ? (prevNav.trustBadges as unknown[])
        : [];
      nav.trustBadges = nav.trustBadges.map((it: unknown, i: number) => {
        if (!isObjectRecord(it)) return it;
        const prevItem = isObjectRecord(prevArr[i]) ? (prevArr[i] as Record<string, unknown>) : undefined;
        return {
          ...it,
          id: ensureItemId(it, prevItem, SITE_HEADER_ITEM_ID_PREFIX.trustBadges),
          label: syncSiteHeaderLabel(it, prevItem, defaultLang),
        };
      });
    }
  }
  return out;
}

/* ─── site-footer 专属 transform（阶段 2 节点 B · B-D2）──────────────── */
//
// storage 形态：{ enabled, newsletter:{...}, contact:{enabled, items[],
//   socialLinks[]}, bottomStrip:{enabled, legalLinks[], showTradeTerms,
//   tradeTerms:string[]}, style:{...} }
//
// 三个 ListField：
//   - contact.items[]:    {id, icon, type?, text, localizedText?, href?, enabled}
//     · `text` 为兜底字符串 + `localizedText` 多语言 map（命名与 site-header 不同！）
//   - contact.socialLinks[]: {id, platform, url, label?, icon?, openInNewTab?, enabled}
//     · 无多语言字段，passthrough
//   - bottomStrip.legalLinks[]: {id, labelTranslations?, labelI18nKey?, label?, link, enabled}
//     · `label` + `labelTranslations` 同 site-header 模式
//
// postprocessSiteFooterWrite 同步：
//   · contact.items[i].text = localizedText[defaultLang] ?? prevText ?? ''
//   · bottomStrip.legalLinks[i].label = labelTranslations[defaultLang] ?? prevLabel ?? ''
//   · 三 array items[].id 兜底（ensureItemId · 沿用 hero/site-header pattern）

const SITE_FOOTER_ITEM_ID_PREFIX = {
  items: 'f',
  socialLinks: 's',
  legalLinks: 'l',
} as const;

function syncSiteFooterContactText(
  walked: Record<string, unknown>,
  prev: Record<string, unknown> | undefined,
  defaultLang: string,
): string {
  const localizedText = walked.localizedText;
  if (isObjectRecord(localizedText)) {
    const v = localizedText[defaultLang];
    if (typeof v === 'string' && v) return v;
  }
  if (typeof walked.text === 'string' && walked.text) return walked.text;
  if (prev && typeof prev.text === 'string') return prev.text;
  return '';
}

function postprocessSiteFooterWrite(
  walked: Record<string, unknown>,
  prevStoredRoot: Record<string, unknown>,
  defaultLang: string,
): Record<string, unknown> {
  const out: Record<string, unknown> = { ...prevStoredRoot };
  for (const k of Object.keys(walked)) {
    const wv = walked[k];
    const pv = prevStoredRoot[k];
    if (isObjectRecord(wv) && isObjectRecord(pv)) {
      out[k] = { ...pv, ...wv };
    } else {
      out[k] = wv;
    }
  }
  // contact.items / contact.socialLinks
  if (isObjectRecord(out.contact)) {
    const contact = out.contact as Record<string, unknown>;
    const prevContact = isObjectRecord(prevStoredRoot.contact)
      ? (prevStoredRoot.contact as Record<string, unknown>)
      : {};
    if (Array.isArray(contact.items)) {
      const prevArr = Array.isArray(prevContact.items) ? (prevContact.items as unknown[]) : [];
      contact.items = contact.items.map((it: unknown, i: number) => {
        if (!isObjectRecord(it)) return it;
        const prevItem = isObjectRecord(prevArr[i]) ? (prevArr[i] as Record<string, unknown>) : undefined;
        return {
          ...it,
          id: ensureItemId(it, prevItem, SITE_FOOTER_ITEM_ID_PREFIX.items),
          text: syncSiteFooterContactText(it, prevItem, defaultLang),
        };
      });
    }
    if (Array.isArray(contact.socialLinks)) {
      const prevArr = Array.isArray(prevContact.socialLinks) ? (prevContact.socialLinks as unknown[]) : [];
      contact.socialLinks = contact.socialLinks.map((it: unknown, i: number) => {
        if (!isObjectRecord(it)) return it;
        const prevItem = isObjectRecord(prevArr[i]) ? (prevArr[i] as Record<string, unknown>) : undefined;
        return {
          ...it,
          id: ensureItemId(it, prevItem, SITE_FOOTER_ITEM_ID_PREFIX.socialLinks),
        };
      });
    }
  }
  // bottomStrip.legalLinks
  if (isObjectRecord(out.bottomStrip)) {
    const bottom = out.bottomStrip as Record<string, unknown>;
    const prevBottom = isObjectRecord(prevStoredRoot.bottomStrip)
      ? (prevStoredRoot.bottomStrip as Record<string, unknown>)
      : {};
    if (Array.isArray(bottom.legalLinks)) {
      const prevArr = Array.isArray(prevBottom.legalLinks) ? (prevBottom.legalLinks as unknown[]) : [];
      bottom.legalLinks = bottom.legalLinks.map((it: unknown, i: number) => {
        if (!isObjectRecord(it)) return it;
        const prevItem = isObjectRecord(prevArr[i]) ? (prevArr[i] as Record<string, unknown>) : undefined;
        return {
          ...it,
          id: ensureItemId(it, prevItem, SITE_FOOTER_ITEM_ID_PREFIX.legalLinks),
          label: syncSiteHeaderLabel(it, prevItem, defaultLang),
        };
      });
    }
  }
  return out;
}

/* ─── news-list-page 专属 transform（阶段 2 节点 B · B-D3）────────────── */
//
// storage 形态：{ enabled, hero{...}, filter{...}, grid{...},
//   sidebar:{enabled, popularTagsLabel, popularTagsSource:'categories'|'custom',
//            popularTagsCustom: LocalizedText[], popularTagsLimit:number,
//            recentLabel, recentLimit:number}, empty{...} }
//
// 关键转换：sidebar.popularTagsCustom 在 storage 形态是裸 LocalizedText[]
// （`[{ 'zh-CN': '...', en: '...'}, ...]`），但 PanelSchemaV1 的 arrayOfObject
// 需要 itemSchema 含命名字段。adapter 双向：
//   - read:  storage `[lt0, lt1]` → render `[{id, value: lt0}, {id, value: lt1}]`
//   - write: render `[{id, value: lt0}, ...]` → storage `[lt0, lt1]`（剥 wrapper）

function preprocessNewsListPageRead(
  storedRoot: Record<string, unknown>,
): Record<string, unknown> {
  const out: Record<string, unknown> = { ...storedRoot };
  const sidebar = storedRoot.sidebar;
  if (isObjectRecord(sidebar) && Array.isArray(sidebar.popularTagsCustom)) {
    out.sidebar = {
      ...sidebar,
      popularTagsCustom: sidebar.popularTagsCustom.map((lt: unknown, i: number) => ({
        id: `tag-${i}-${Math.random().toString(36).slice(2, 6)}`,
        value: isObjectRecord(lt) ? lt : {},
      })),
    };
  }
  // grid.perPage: storage 是 number 10/20/50，schema 用 select（string options）
  // → read 时把 number 强转 string；write 时再强转回 number。
  const grid = out.grid;
  if (isObjectRecord(grid) && typeof grid.perPage === 'number') {
    out.grid = { ...grid, perPage: String(grid.perPage) };
  }
  return out;
}

function postprocessNewsListPageWrite(
  walked: Record<string, unknown>,
  prevStoredRoot: Record<string, unknown>,
): Record<string, unknown> {
  const out: Record<string, unknown> = { ...prevStoredRoot };
  for (const k of Object.keys(walked)) {
    const wv = walked[k];
    const pv = prevStoredRoot[k];
    if (isObjectRecord(wv) && isObjectRecord(pv)) {
      out[k] = { ...pv, ...wv };
    } else {
      out[k] = wv;
    }
  }
  // popularTagsCustom: [{id, value: LocalizedText}] → LocalizedText[]
  if (isObjectRecord(out.sidebar)) {
    const sidebar = out.sidebar as Record<string, unknown>;
    if (Array.isArray(sidebar.popularTagsCustom)) {
      sidebar.popularTagsCustom = sidebar.popularTagsCustom.map((it: unknown) => {
        if (!isObjectRecord(it)) return {};
        return isObjectRecord(it.value) ? it.value : {};
      });
    }
  }
  // grid.perPage: schema 用 select（string） → storage 强转回 number
  if (isObjectRecord(out.grid)) {
    const grid = out.grid as Record<string, unknown>;
    if (typeof grid.perPage === 'string') {
      const n = Number(grid.perPage);
      if (Number.isFinite(n)) grid.perPage = n;
    }
  }
  return out;
}

/* ─── contact-page 专属 transform（阶段 2 节点 C · C-D1）──────────────── */
//
// storage 形态：{ enabled, header{...}, departments{eyebrow, title, items[]:
//   {id, icon:{kind,name,size,color}, accent, badge, title, description,
//    email, phone, hours}}, formCard{...}, map{...}, sidebar{title,
//   items[]:{id, icon:enum, value, bold}, drivingDirectionsLabel,
//   drivingDirectionsHref}, trustCells:{items[]:{id, icon, title, sub}},
//   faq{eyebrow, title, description, sideBox:{title, description, ctaLabel,
//   ctaHref}, items[]:{id, question, answer}}, style{hero, departments,
//   formCard, faq} 嵌套 4 段 }
//
// helper 复用偏离登记（schema.ts 头注 + 完工汇报 §X）：
//   - createNullableObjectField · 不复用：contact 无 nullable section
//   - createCtaLinkObjectField · 不复用：contact href 全是裸 string
//
// adapter 仅做：4 ListField items[] 补 id 兜底（ensureItemId · 沿用 site-footer
// pattern）+ 顶层浅 merge（保 schema 不感知字段，与 inquiry-form / site-footer 同形）。

const CONTACT_PAGE_ITEM_ID_PREFIX = {
  departments: 'dept',
  sidebar: 'sb',
  trust: 'trust',
  faq: 'faq',
} as const;

function ensureContactItems(
  walked: Record<string, unknown>,
  prev: Record<string, unknown> | undefined,
  arrKey: string,
  prefix: string,
): unknown[] | undefined {
  const walkedArr = walked[arrKey];
  if (!Array.isArray(walkedArr)) return undefined;
  const prevArr = prev && Array.isArray(prev[arrKey]) ? (prev[arrKey] as unknown[]) : [];
  return walkedArr.map((it: unknown, i: number) => {
    if (!isObjectRecord(it)) return it;
    const prevItem = isObjectRecord(prevArr[i]) ? (prevArr[i] as Record<string, unknown>) : undefined;
    return { ...it, id: ensureItemId(it, prevItem, prefix) };
  });
}

function postprocessContactPageWrite(
  walked: Record<string, unknown>,
  prevStoredRoot: Record<string, unknown>,
): Record<string, unknown> {
  // 顶层浅 merge：保 prev 中 schema 不感知的字段（如 future style 段子字段）
  const out: Record<string, unknown> = { ...prevStoredRoot };
  for (const k of Object.keys(walked)) {
    const wv = walked[k];
    const pv = prevStoredRoot[k];
    if (isObjectRecord(wv) && isObjectRecord(pv)) {
      out[k] = { ...pv, ...wv };
    } else {
      out[k] = wv;
    }
  }
  // departments.items
  if (isObjectRecord(out.departments)) {
    const dept = out.departments as Record<string, unknown>;
    const prevDept = isObjectRecord(prevStoredRoot.departments)
      ? (prevStoredRoot.departments as Record<string, unknown>)
      : undefined;
    const next = ensureContactItems(dept, prevDept, 'items', CONTACT_PAGE_ITEM_ID_PREFIX.departments);
    if (next) dept.items = next;
  }
  // sidebar.items
  if (isObjectRecord(out.sidebar)) {
    const sb = out.sidebar as Record<string, unknown>;
    const prevSb = isObjectRecord(prevStoredRoot.sidebar)
      ? (prevStoredRoot.sidebar as Record<string, unknown>)
      : undefined;
    const next = ensureContactItems(sb, prevSb, 'items', CONTACT_PAGE_ITEM_ID_PREFIX.sidebar);
    if (next) sb.items = next;
  }
  // trustCells.items
  if (isObjectRecord(out.trustCells)) {
    const tc = out.trustCells as Record<string, unknown>;
    const prevTc = isObjectRecord(prevStoredRoot.trustCells)
      ? (prevStoredRoot.trustCells as Record<string, unknown>)
      : undefined;
    const next = ensureContactItems(tc, prevTc, 'items', CONTACT_PAGE_ITEM_ID_PREFIX.trust);
    if (next) tc.items = next;
  }
  // faq.items
  if (isObjectRecord(out.faq)) {
    const faq = out.faq as Record<string, unknown>;
    const prevFaq = isObjectRecord(prevStoredRoot.faq)
      ? (prevStoredRoot.faq as Record<string, unknown>)
      : undefined;
    const next = ensureContactItems(faq, prevFaq, 'items', CONTACT_PAGE_ITEM_ID_PREFIX.faq);
    if (next) faq.items = next;
  }
  return out;
}

/* ─── sitemap-page 专属 transform（阶段 2 节点 C · C-D2）──────────────── */
//
// storage 形态：{ enabled, hero{...}, searchPlaceholder, searchLabels{...},
//   statsEnabled, stats[]:{kind,...}, sections[]:{id, iconName, tone, title,
//   blurb, items[]:{label, href, desc, children?:[{label, href, desc}]}},
//   xmlEnabled, xmlCards[]:{...}, ctaEnabled, cta:{...} }
//
// schema 取舍（schema.ts 头注 + 完工汇报 §X · UX 退化登记）：
//   - sections.items.children 不在 schema 暴露（D1 决策硬限 2 层 · 第 3 层
//     arrayOfObject 嵌套被 validator.ts 拒绝）。adapter postprocess 内：
//     按 id 序列从 prev.sections[i].items[j].children 透传保留。
//   - stats kind 异构铺平（同 CtaLink 9 字段铺平）→ adapter 不需 kind-aware 过滤。
//
// adapter 行为：
//   - 4 ListField items[] 补 id（stats / sections / sections.items / xmlCards）
//   - sections[i].items[j].children 透传保留（基于 prev 中相同 i/j 的 children）
//   - 顶层浅 merge

const SITEMAP_PAGE_ITEM_ID_PREFIX = {
  stats: 'stat',
  sections: 'sec',
  items: 'node',
  xmlCards: 'xml',
} as const;

function postprocessSitemapPageWrite(
  walked: Record<string, unknown>,
  prevStoredRoot: Record<string, unknown>,
): Record<string, unknown> {
  // 顶层浅 merge
  const out: Record<string, unknown> = { ...prevStoredRoot };
  for (const k of Object.keys(walked)) {
    const wv = walked[k];
    const pv = prevStoredRoot[k];
    if (isObjectRecord(wv) && isObjectRecord(pv)) {
      out[k] = { ...pv, ...wv };
    } else {
      out[k] = wv;
    }
  }
  // stats[].id
  if (Array.isArray(walked.stats)) {
    const prevArr = Array.isArray(prevStoredRoot.stats) ? (prevStoredRoot.stats as unknown[]) : [];
    out.stats = walked.stats.map((it: unknown, i: number) => {
      if (!isObjectRecord(it)) return it;
      const prevItem = isObjectRecord(prevArr[i]) ? (prevArr[i] as Record<string, unknown>) : undefined;
      return { ...it, id: ensureItemId(it, prevItem, SITEMAP_PAGE_ITEM_ID_PREFIX.stats) };
    });
  }
  // xmlCards[].id
  if (Array.isArray(walked.xmlCards)) {
    const prevArr = Array.isArray(prevStoredRoot.xmlCards) ? (prevStoredRoot.xmlCards as unknown[]) : [];
    out.xmlCards = walked.xmlCards.map((it: unknown, i: number) => {
      if (!isObjectRecord(it)) return it;
      const prevItem = isObjectRecord(prevArr[i]) ? (prevArr[i] as Record<string, unknown>) : undefined;
      return { ...it, id: ensureItemId(it, prevItem, SITEMAP_PAGE_ITEM_ID_PREFIX.xmlCards) };
    });
  }
  // sections[].id（已 schema 暴露 id 字段，主要兜底空 id）
  // + sections[i].items[j] · 补 items[].id + 透传 prev.children
  if (Array.isArray(walked.sections)) {
    const prevSections = Array.isArray(prevStoredRoot.sections)
      ? (prevStoredRoot.sections as unknown[])
      : [];
    out.sections = walked.sections.map((sec: unknown, i: number) => {
      if (!isObjectRecord(sec)) return sec;
      const prevSec = isObjectRecord(prevSections[i]) ? (prevSections[i] as Record<string, unknown>) : undefined;
      const prevItems = prevSec && Array.isArray(prevSec.items) ? (prevSec.items as unknown[]) : [];
      const ensuredId = ensureItemId(sec, prevSec, SITEMAP_PAGE_ITEM_ID_PREFIX.sections);
      const walkedItems = sec.items;
      let nextItems: unknown[] | unknown = walkedItems;
      if (Array.isArray(walkedItems)) {
        nextItems = walkedItems.map((it: unknown, j: number) => {
          if (!isObjectRecord(it)) return it;
          const prevItem = isObjectRecord(prevItems[j]) ? (prevItems[j] as Record<string, unknown>) : undefined;
          const merged: Record<string, unknown> = {
            ...it,
            id: ensureItemId(it, prevItem, SITEMAP_PAGE_ITEM_ID_PREFIX.items),
          };
          // children 透传（schema 不暴露第 3 层）
          if (prevItem && Array.isArray(prevItem.children)) {
            merged.children = prevItem.children;
          }
          return merged;
        });
      }
      return { ...sec, id: ensuredId, items: nextItems };
    });
  }
  return out;
}

/* ─── product-list-page 专属 transform（阶段 2 节点 C · C-D3）──────────── */
//
// storage 形态：见 schema.ts 头注。
//
// preprocessRead:
//   - pagination.pageSizeOptions: number[] → string[]（tagInput 仅支持 string[]）
//
// postprocessWrite:
//   - pagination.pageSizeOptions: string[] → number[]（强转 + 过滤 NaN）
//   - 3 ListField items[] 补 id（header.stats / quickChips.fixed / toolbar.sortOptions）
//   - 顶层浅 + section 嵌套 merge（保 prev 中 schema 不感知字段）
//
// 字段级 mediaPicker 降级（write hook · panelKey === 'fttp.product-list-page'）：
//   - featuredBanner.leftImage / rightImage：mediaPicker onChange 产 {url} 对象
//     → 写回 storage string URL（沿用 fttp.factory pattern）

const PRODUCT_LIST_PAGE_ITEM_ID_PREFIX = {
  stats: 'stat',
  fixed: 'chip',
  sortOptions: 'sort',
} as const;

function preprocessProductListPageRead(
  storedRoot: Record<string, unknown>,
): Record<string, unknown> {
  const out: Record<string, unknown> = { ...storedRoot };
  const pagination = storedRoot.pagination;
  if (isObjectRecord(pagination) && Array.isArray(pagination.pageSizeOptions)) {
    out.pagination = {
      ...pagination,
      pageSizeOptions: pagination.pageSizeOptions
        .filter((n) => typeof n === 'number' && Number.isFinite(n))
        .map((n) => String(n)),
    };
  }
  return out;
}

function postprocessProductListPageWrite(
  walked: Record<string, unknown>,
  prevStoredRoot: Record<string, unknown>,
): Record<string, unknown> {
  const out: Record<string, unknown> = { ...prevStoredRoot };
  for (const k of Object.keys(walked)) {
    const wv = walked[k];
    const pv = prevStoredRoot[k];
    if (isObjectRecord(wv) && isObjectRecord(pv)) {
      out[k] = { ...pv, ...wv };
    } else {
      out[k] = wv;
    }
  }
  // pagination.pageSizeOptions: string[] → number[]
  if (isObjectRecord(out.pagination)) {
    const pagination = out.pagination as Record<string, unknown>;
    if (Array.isArray(pagination.pageSizeOptions)) {
      pagination.pageSizeOptions = pagination.pageSizeOptions
        .map((s) => (typeof s === 'string' ? Number(s) : typeof s === 'number' ? s : NaN))
        .filter((n) => Number.isFinite(n) && n > 0);
    }
  }
  // header.stats[].id
  if (isObjectRecord(out.header)) {
    const header = out.header as Record<string, unknown>;
    const prevHeader = isObjectRecord(prevStoredRoot.header)
      ? (prevStoredRoot.header as Record<string, unknown>)
      : undefined;
    if (Array.isArray(header.stats)) {
      const prevArr = prevHeader && Array.isArray(prevHeader.stats) ? (prevHeader.stats as unknown[]) : [];
      header.stats = header.stats.map((it: unknown, i: number) => {
        if (!isObjectRecord(it)) return it;
        const prevItem = isObjectRecord(prevArr[i]) ? (prevArr[i] as Record<string, unknown>) : undefined;
        return { ...it, id: ensureItemId(it, prevItem, PRODUCT_LIST_PAGE_ITEM_ID_PREFIX.stats) };
      });
    }
  }
  // quickChips.fixed[].id
  if (isObjectRecord(out.quickChips)) {
    const qc = out.quickChips as Record<string, unknown>;
    const prevQc = isObjectRecord(prevStoredRoot.quickChips)
      ? (prevStoredRoot.quickChips as Record<string, unknown>)
      : undefined;
    if (Array.isArray(qc.fixed)) {
      const prevArr = prevQc && Array.isArray(prevQc.fixed) ? (prevQc.fixed as unknown[]) : [];
      qc.fixed = qc.fixed.map((it: unknown, i: number) => {
        if (!isObjectRecord(it)) return it;
        const prevItem = isObjectRecord(prevArr[i]) ? (prevArr[i] as Record<string, unknown>) : undefined;
        return { ...it, id: ensureItemId(it, prevItem, PRODUCT_LIST_PAGE_ITEM_ID_PREFIX.fixed) };
      });
    }
  }
  // toolbar.sortOptions[].id（已用 select 限定，主要兜底空值）
  if (isObjectRecord(out.toolbar)) {
    const tb = out.toolbar as Record<string, unknown>;
    const prevTb = isObjectRecord(prevStoredRoot.toolbar)
      ? (prevStoredRoot.toolbar as Record<string, unknown>)
      : undefined;
    if (Array.isArray(tb.sortOptions)) {
      const prevArr = prevTb && Array.isArray(prevTb.sortOptions) ? (prevTb.sortOptions as unknown[]) : [];
      tb.sortOptions = tb.sortOptions.map((it: unknown, i: number) => {
        if (!isObjectRecord(it)) return it;
        const prevItem = isObjectRecord(prevArr[i]) ? (prevArr[i] as Record<string, unknown>) : undefined;
        // sortOptions[].id 是固定 select 'newest'/'oldest'/'manual'，不可空
        return prevItem && !it.id ? { ...it, id: prevItem.id ?? PRODUCT_LIST_PAGE_ITEM_ID_PREFIX.sortOptions } : it;
      });
    }
  }
  return out;
}

/* ─── inquiry-cart-page 专属 transform（阶段 2 节点 C · C-D4）────────── */
//
// storage 形态：见 schema.ts 头注。3 ListField：steps.items / benefits.items / quickContacts.items。
// LocalizedText 是裸 `{ lang: str }` 形态 · adapter default 路径 passthrough。
//
// adapter 仅做：3 ListField items[].id 兜底 + 顶层浅 + section 嵌套 merge。

const INQUIRY_CART_ITEM_ID_PREFIX = {
  steps: 'step',
  benefits: 'b',
  quickContacts: 'qc',
} as const;

function postprocessInquiryCartPageWrite(
  walked: Record<string, unknown>,
  prevStoredRoot: Record<string, unknown>,
): Record<string, unknown> {
  const out: Record<string, unknown> = { ...prevStoredRoot };
  for (const k of Object.keys(walked)) {
    const wv = walked[k];
    const pv = prevStoredRoot[k];
    if (isObjectRecord(wv) && isObjectRecord(pv)) {
      out[k] = { ...pv, ...wv };
    } else {
      out[k] = wv;
    }
  }
  // form.fields 二级嵌套需 nested merge（避免整段覆盖丢字段）
  if (isObjectRecord(out.form) && isObjectRecord(prevStoredRoot.form)) {
    const form = out.form as Record<string, unknown>;
    const prevForm = prevStoredRoot.form as Record<string, unknown>;
    if (isObjectRecord(form.fields) && isObjectRecord(prevForm.fields)) {
      form.fields = { ...(prevForm.fields as Record<string, unknown>), ...(form.fields as Record<string, unknown>) };
    }
  }
  // 3 ListField items[].id 兜底
  for (const sectionKey of ['steps', 'benefits', 'quickContacts'] as const) {
    if (!isObjectRecord(out[sectionKey])) continue;
    const section = out[sectionKey] as Record<string, unknown>;
    const prevSection = isObjectRecord(prevStoredRoot[sectionKey])
      ? (prevStoredRoot[sectionKey] as Record<string, unknown>)
      : undefined;
    if (!Array.isArray(section.items)) continue;
    const prevArr = prevSection && Array.isArray(prevSection.items) ? (prevSection.items as unknown[]) : [];
    const prefix = INQUIRY_CART_ITEM_ID_PREFIX[sectionKey];
    section.items = section.items.map((it: unknown, i: number) => {
      if (!isObjectRecord(it)) return it;
      const prevItem = isObjectRecord(prevArr[i]) ? (prevArr[i] as Record<string, unknown>) : undefined;
      return { ...it, id: ensureItemId(it, prevItem, prefix) };
    });
  }
  return out;
}

/* ─── downloads-list-page 专属 transform（阶段 2 节点 C · C-D5）──────── */
//
// storage 形态：见 schema.ts 头注。2 ListField：tiles.categoryVisuals / infoPanels.items。
// LocalizedText 裸 { lang: str } 形态 · adapter default 路径 passthrough。
//
// adapter 仅做：2 ListField items[].id 兜底 + 顶层 + section 嵌套 merge。

const DOWNLOADS_LIST_ITEM_ID_PREFIX = {
  categoryVisuals: 'cat',
  items: 'info',
} as const;

function postprocessDownloadsListPageWrite(
  walked: Record<string, unknown>,
  prevStoredRoot: Record<string, unknown>,
): Record<string, unknown> {
  const out: Record<string, unknown> = { ...prevStoredRoot };
  for (const k of Object.keys(walked)) {
    const wv = walked[k];
    const pv = prevStoredRoot[k];
    if (isObjectRecord(wv) && isObjectRecord(pv)) {
      out[k] = { ...pv, ...wv };
    } else {
      out[k] = wv;
    }
  }
  // tiles.categoryVisuals[].id
  if (isObjectRecord(out.tiles)) {
    const tiles = out.tiles as Record<string, unknown>;
    const prevTiles = isObjectRecord(prevStoredRoot.tiles)
      ? (prevStoredRoot.tiles as Record<string, unknown>)
      : undefined;
    if (Array.isArray(tiles.categoryVisuals)) {
      const prevArr = prevTiles && Array.isArray(prevTiles.categoryVisuals)
        ? (prevTiles.categoryVisuals as unknown[])
        : [];
      tiles.categoryVisuals = tiles.categoryVisuals.map((it: unknown, i: number) => {
        if (!isObjectRecord(it)) return it;
        const prevItem = isObjectRecord(prevArr[i]) ? (prevArr[i] as Record<string, unknown>) : undefined;
        return { ...it, id: ensureItemId(it, prevItem, DOWNLOADS_LIST_ITEM_ID_PREFIX.categoryVisuals) };
      });
    }
  }
  // infoPanels.items[].id
  if (isObjectRecord(out.infoPanels)) {
    const info = out.infoPanels as Record<string, unknown>;
    const prevInfo = isObjectRecord(prevStoredRoot.infoPanels)
      ? (prevStoredRoot.infoPanels as Record<string, unknown>)
      : undefined;
    if (Array.isArray(info.items)) {
      const prevArr = prevInfo && Array.isArray(prevInfo.items) ? (prevInfo.items as unknown[]) : [];
      info.items = info.items.map((it: unknown, i: number) => {
        if (!isObjectRecord(it)) return it;
        const prevItem = isObjectRecord(prevArr[i]) ? (prevArr[i] as Record<string, unknown>) : undefined;
        return { ...it, id: ensureItemId(it, prevItem, DOWNLOADS_LIST_ITEM_ID_PREFIX.items) };
      });
    }
  }
  return out;
}

/* ─── 工厂 ─────────────────────────────────────────────────────────── */

/**
 * 创建 fttp 主题专属数据形态适配器。
 *
 * @param panelKey 当前 panel 的 panelKey（决定 preprocess/postprocess 分支）。
 *   未识别的 panelKey 走最小默认（仅 LocalizedText 字段级转换 + prev merge）。
 * @param opts.defaultLang 默认语言代码（仅 site-header 等需要 label 同步的 panel
 *   使用；缺省 'en'，由 PanelClient 从站点设置 ↔ defaultLang 注入）。
 */
export function createFttpStorageAdapter(
  panelKey: string,
  opts?: { defaultLang?: string },
): PanelDataAdapter {
  const defaultLang = opts?.defaultLang ?? 'en';
  return {
    preprocessRead: (storedRoot) => {
      switch (panelKey) {
        case 'fttp.featured-products':
          return preprocessFeaturedProductsRead(storedRoot);
        case 'fttp.why-choose-us':
          return preprocessWhyChooseUsRead(storedRoot);
        case 'fttp.factory':
          return preprocessFactoryRead(storedRoot);
        case 'fttp.factory-page':
          return preprocessFactoryPageRead(storedRoot);
        case 'fttp.quality-page':
          return preprocessQualityPageRead(storedRoot);
        case 'fttp.news-list-page':
          return preprocessNewsListPageRead(storedRoot);
        case 'fttp.product-list-page':
          return preprocessProductListPageRead(storedRoot);
        default:
          return storedRoot;
      }
    },
    postprocessWrite: (walked, prevStoredRoot) => {
      switch (panelKey) {
        case 'fttp.featured-products':
          return postprocessFeaturedProductsWrite(walked, prevStoredRoot);
        case 'fttp.why-choose-us':
          return postprocessWhyChooseUsWrite(walked, prevStoredRoot);
        case 'fttp.hero':
          return postprocessHeroWrite(walked, prevStoredRoot);
        case 'fttp.factory':
          return postprocessFactoryWrite(walked, prevStoredRoot);
        case 'fttp.factory-page':
          return postprocessFactoryPageWrite(walked, prevStoredRoot);
        case 'fttp.about-page':
          return postprocessAboutPageWrite(walked, prevStoredRoot);
        case 'fttp.quality-page':
          return postprocessQualityPageWrite(walked, prevStoredRoot);
        case 'fttp.site-header':
          return postprocessSiteHeaderWrite(walked, prevStoredRoot, defaultLang);
        case 'fttp.site-footer':
          return postprocessSiteFooterWrite(walked, prevStoredRoot, defaultLang);
        case 'fttp.news-list-page':
          return postprocessNewsListPageWrite(walked, prevStoredRoot);
        case 'fttp.contact-page':
          return postprocessContactPageWrite(walked, prevStoredRoot);
        case 'fttp.sitemap-page':
          return postprocessSitemapPageWrite(walked, prevStoredRoot);
        case 'fttp.product-list-page':
          return postprocessProductListPageWrite(walked, prevStoredRoot);
        case 'fttp.inquiry-cart-page':
          return postprocessInquiryCartPageWrite(walked, prevStoredRoot);
        case 'fttp.downloads-list-page':
          return postprocessDownloadsListPageWrite(walked, prevStoredRoot);
        case 'fttp.privacy-page':
        case 'fttp.terms-page':
        case 'fttp.cookie-page':
          // 节点 A D-A1（S2.4）：terms/cookie 与 privacy 三页 storage 形态完全同构，
          // 复用 postprocessLegalWrite（sections[i].blocks 异构数组从 prev 透传保留）。
          return postprocessLegalWrite(walked, prevStoredRoot);
        default:
          // 默认浅 merge 保留 prev 中 schema 不感知的字段（如 style）
          return { ...prevStoredRoot, ...walked };
      }
    },
    read: (storedValue, ctx) => {
      if (ctx.fieldType === 'icon') {
        // 节点 C（S2.4）：fttp 三独立页 storage 形态可能是 string（旧 factoryPage）或
        // {kind, name, size?, color?} 对象（aboutPage / qualityPage）。IconField
        // 期望 string（图标名）→ 抽出 .name；string passthrough。
        if (typeof storedValue === 'string') return storedValue;
        if (isObjectRecord(storedValue) && typeof storedValue.name === 'string') {
          return storedValue.name;
        }
        return '';
      }
      if (ctx.fieldType === 'localizedText') {
        // fttp trust-strip 形态：{ translations, style } → { [lang]: string }
        // 标准形态（inquiry-cta）/ 已被 preprocessRead 拍平的：直接 passthrough
        // 通用层 styled-localized-text-adapter 同时处理两种形态（S3 节点 A 拆分）
        return readStyledLocalizedText(storedValue);
      }
      return storedValue;
    },
    write: (renderValue, ctx) => {
      if (ctx.fieldType === 'icon') {
        // 节点 C（S2.4）：根据 prev 形态写回 string 或 {kind, name, ...prev}。
        const prev = ctx.previousStoredValue;
        const name = typeof renderValue === 'string' ? renderValue : '';
        if (isObjectRecord(prev)) {
          return { ...prev, kind: prev.kind ?? 'lucide', name };
        }
        // prev 是 string 或缺失：写回 string（factoryPage capabilities[i].icon 旧形态）
        return name;
      }
      // 节点 C（S2.4 / 阶段 2 C-D3）：factoryPage / aboutPage hero.media + product-list
      // featuredBanner.leftImage/rightImage 是单 string URL，mediaPicker onChange
      // 产生 {url, focalPoint?}。写回时取 .url 降级为 string。
      if (
        ctx.fieldType === 'mediaPicker' &&
        (panelKey === 'fttp.factory-page' ||
          panelKey === 'fttp.about-page' ||
          panelKey === 'fttp.product-list-page')
      ) {
        if (renderValue && typeof renderValue === 'object' && !Array.isArray(renderValue)) {
          const url = (renderValue as Record<string, unknown>).url;
          return typeof url === 'string' ? url : '';
        }
        return typeof renderValue === 'string' ? renderValue : '';
      }
      // 节点 B D-B1（S2.4）：factory section mediaPicker 字段级降级。
      // 前台 `Factory.tsx` 消费 `config.hero.media.{image,video,poster}` 纯 string URL；
      // `config.thumbnails` 是 string[]。MediaPickerFieldComponent onChange 产生
      // `{url, focalPoint?}` 对象 → 写回时取 .url 降级为 string，避免前台 break。
      if (
        ctx.fieldType === 'mediaPicker' &&
        panelKey === 'fttp.factory'
      ) {
        if (renderValue && typeof renderValue === 'object' && !Array.isArray(renderValue)) {
          const url = (renderValue as Record<string, unknown>).url;
          return typeof url === 'string' ? url : '';
        }
        return typeof renderValue === 'string' ? renderValue : '';
      }
      if (ctx.fieldType === 'localizedText') {
        // trust-strip 形态：prev 是 { translations, style? } → 写回包装形态
        // 标准形态 / preprocessRead 拍平后形态：passthrough
        // 通用层 styled-localized-text-adapter 同时处理两种形态（S3 节点 A 拆分）
        return writeStyledLocalizedText(renderValue, ctx.previousStoredValue);
      }
      return renderValue;
    },
  };
}
