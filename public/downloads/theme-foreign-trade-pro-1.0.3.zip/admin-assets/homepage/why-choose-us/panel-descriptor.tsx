import type { PanelDescriptor } from '../../_types';
import { WhyChooseUsPanelClient } from './WhyChooseUsPanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'homepage/why-choose-us',
  configKey: 'whyChooseUs',
  title: '首页 · 为什么选择我们',
  description: "配置首页「为什么选择我们」区块的卡片列表（典型场景：工厂规模、研发能力、品控体系、认证齐全、物流时效、售后支持）。每张卡片含图标、可选配图、多语言文案。",
  dataPage: 'theme-config-fttp-why-choose-us',
  guardMode: 'theme-key',
  PanelClient: WhyChooseUsPanelClient,
};
