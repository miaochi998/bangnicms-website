import type { PanelDescriptor } from '../../_types';
import { ContactPagePanelClient } from './ContactPagePanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'contact/page',
  configKey: 'contactPage',
  title: '联系我们页',
  description: '配置 /contact 联系我们页：Hero（深色面包屑 + 标题 + 副标题）+ 4 张联系方式卡 + 询盘表单（嵌入「全站询盘表单」配置）+ FAQ 4 项 + 地址/工时卡。所有文案多语言。',
  dataPage: 'theme-config-fttp-contact-page',
  notApplicableTestId: 'contact-page-not-applicable',
  guardMode: 'theme-key',
  PanelClient: ContactPagePanelClient,
};
