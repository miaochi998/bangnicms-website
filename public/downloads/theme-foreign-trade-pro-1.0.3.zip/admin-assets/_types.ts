/**
 * 主题包 admin-assets 共享类型（阶段 4 节点 A）
 * -----------------------------------------------------------------------------
 * 主题包内 28 个 panel-descriptor.tsx 与 admin catch-all 路由共用此类型契约。
 *
 * 设计原则（裁决档 §4 约束）：
 * - panel-descriptor.tsx 内 JSX 仅允许 admin 通用 UI 原语 + Lucide Icon + 内部 HTML
 * - 不允许 import 主题包 src/ 任何前台视觉组件
 * - 文件大小硬限 ≤ 200 行
 */
import type { ComponentType, ReactNode } from 'react';

export type PanelClientProps = {
  apiBase: string;
  extensionId: string;
  themeKey: string;
  themeName: string;
  initialData: Record<string, unknown> | undefined;
  languages: { code: string; name: string }[];
  defaultLang: string;
  aiAvailable: boolean;
};

export type PanelDescriptor = {
  /** catch-all 路径段（与 manifest configPanels[].route 一致） */
  panelRoute: string;
  /** theme.config[configKey] 数据键（useRootConfig=true 时被忽略） */
  configKey: string;
  /**
   * 根合并模式：true 时 initialData = 整 theme.config（不取子键），
   * 用于历史 storage 形态把字段写到 config 顶层而非子段的 panel（如 branding 的
   * primaryColor / accentColor 顶层键）。schema 端配合 configPath: 'config' 工作。
   * 默认 false（取 configKey 子段）。
   */
  useRootConfig?: boolean;
  title: string;
  /** 已激活时显示的 description；未激活时回落 not-applicable 文案 */
  description: string;
  /** <div data-page="..."> 标识 */
  dataPage: string;
  /**
   * not-applicable 块 data-testid。
   * - 'theme-key' 模式：使用此 testid 渲染失配占位
   * - 'theme-exists' 模式：未激活任何主题时渲染通用占位（无 testid）
   */
  notApplicableTestId?: string;
  /**
   * - `theme-key`（默认）：要求 theme.extensionKey === [themeKey]，否则 not-applicable
   * - `theme-exists`：仅要求有任意激活主题（节点 A D4 后 28 panel 全部 'theme-key'）
   */
  guardMode?: 'theme-key' | 'theme-exists';
  /** 顶部提示卡（部分 panel 含运营提示） */
  hint?: ReactNode;
  /** breadcrumb 区域追加额外链接（如 featured-products 的"产品管理"快捷） */
  breadcrumbExtras?: ReactNode;
  PanelClient: ComponentType<PanelClientProps>;
};
