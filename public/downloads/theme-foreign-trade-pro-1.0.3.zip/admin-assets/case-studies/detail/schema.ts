/**
 * fttp 解决方案 · 详情页 PanelSchemaV1 schema（阶段 2 节点 A · A-D5 试水 2）
 * -----------------------------------------------------------------------------
 * 接管自原 CaseStudyDetailConfigForm.tsx（442 行手写）。
 *
 * Storage 形态（FttpCaseStudyDetailPageConfig · config.caseStudyDetailPage）：
 *   {
 *     enabled,
 *     breadcrumb: { listLabel: LocalizedText },
 *     missing:   { title, subtitleTpl, backLabel },     // 全 LocalizedText
 *     challengeEyebrow,                                  // LocalizedText 顶层
 *     solutionEyebrow,
 *     outcomeEyebrow,
 *     productsUsedTitle,
 *     ctaBox: {
 *       title, description, buttonLabel: LocalizedText,
 *       buttonHref: string,                              // 单语 URL（/contact 等）· 不升 CtaLinkObject（前台直接消费 string · 启动裁决禁区不动 web 业务）
 *     },
 *     related: { eyebrow, title, viewAllLabel: LocalizedText },
 *   }
 *
 * 形态特点：
 *   - **全标准 PanelSchemaV1 LocalizedString 形态**（buttonHref 单语 string 例外）
 *   - 无 fttp 历史污染（无 per-field { translations, style } / per-lang 反向嵌套）
 *   - createFttpStorageAdapter('fttp.case-study-detail') 走 default 分支
 *
 * 节点 A 试水范围：
 *   - 章节标题段固定 4 个（design language 锁定 · 不开放 arrayOfObject）
 *   - 不暴露 TextStyle / 颜色字段（原 ConfigForm 也未暴露）
 *   - buttonHref 保持单语 string 不升 CtaLinkObject（启动裁决 §4 禁区 · 见自检请示补充 #2 §1）
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

export const CASE_STUDY_DETAIL_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.case-study-detail',
  version: 1,
  previewAdapter: 'fttp.case-study-detail',
  title: '解决方案 · 详情页',
  configPath: 'config.caseStudyDetailPage',
  tabs: [
    {
      tabKey: 'sections',
      title: '章节标题 · 总开关',
      sections: [
        {
          sectionKey: 'master',
          title: '整块开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用本页面',
              description: '关闭后前台 /case-studies/:slug 渲染为空。',
              defaultValue: true,
              controlsChildren: true,
              span: 'narrow',
            },
          ],
        },
        {
          sectionKey: 'sections',
          title: '4 段章节小标题（eyebrow）',
          description: '前台案例详情页固定 4 段：面临的挑战 / 我们的方法 / 取得的成果 / 部署产品。',
          fields: [
            {
              fieldKey: 'challengeEyebrow',
              type: 'localizedText',
              label: '挑战段标题',
              placeholder: '面临的挑战',
              multiLang: true,
              span: 'wide',
            },
            {
              fieldKey: 'solutionEyebrow',
              type: 'localizedText',
              label: '方法段标题',
              placeholder: '我们的方法',
              multiLang: true,
              span: 'wide',
            },
            {
              fieldKey: 'outcomeEyebrow',
              type: 'localizedText',
              label: '成果段标题',
              placeholder: '取得的成果',
              multiLang: true,
              span: 'wide',
            },
            {
              fieldKey: 'productsUsedTitle',
              type: 'localizedText',
              label: '部署产品段标题',
              placeholder: '部署产品',
              multiLang: true,
              span: 'wide',
            },
          ],
        },
      ],
    },
    {
      tabKey: 'cta',
      title: 'CTA 块',
      sections: [
        {
          sectionKey: 'cta',
          title: '案例底部 CTA 块',
          description: '案例详情底部统一 CTA：标题 / 描述 / 按钮文字 / 跳转 URL。',
          fields: [
            {
              fieldKey: 'ctaBox',
              type: 'object',
              label: 'CTA 块',
              span: 'full',
              fields: [
                {
                  fieldKey: 'title',
                  type: 'localizedText',
                  label: '标题',
                  multiLang: true,
                  span: 'wide',
                },
                {
                  fieldKey: 'description',
                  type: 'localizedText',
                  label: '描述',
                  multiLang: true,
                  multiline: true,
                  span: 'full',
                },
                {
                  fieldKey: 'buttonLabel',
                  type: 'localizedText',
                  label: '按钮文字',
                  multiLang: true,
                  span: 'wide',
                },
                {
                  fieldKey: 'buttonHref',
                  type: 'text',
                  label: '按钮跳转 URL（单语）',
                  placeholder: '/contact',
                  span: 'wide',
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'related',
      title: '相关案例区',
      sections: [
        {
          sectionKey: 'related',
          title: '相关案例区文案',
          fields: [
            {
              fieldKey: 'related',
              type: 'object',
              label: '相关案例',
              span: 'full',
              fields: [
                {
                  fieldKey: 'eyebrow',
                  type: 'localizedText',
                  label: '小标签',
                  multiLang: true,
                  span: 'wide',
                },
                {
                  fieldKey: 'title',
                  type: 'localizedText',
                  label: '大标题',
                  multiLang: true,
                  span: 'wide',
                },
                {
                  fieldKey: 'viewAllLabel',
                  type: 'localizedText',
                  label: '"全部案例"链接文字',
                  multiLang: true,
                  span: 'wide',
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'misc',
      title: '面包屑 / 404',
      sections: [
        {
          sectionKey: 'breadcrumb',
          title: '面包屑',
          fields: [
            {
              fieldKey: 'breadcrumb',
              type: 'object',
              label: '面包屑',
              span: 'full',
              fields: [
                {
                  fieldKey: 'listLabel',
                  type: 'localizedText',
                  label: '列表页标签',
                  placeholder: '解决方案',
                  multiLang: true,
                  span: 'wide',
                },
              ],
            },
          ],
        },
        {
          sectionKey: 'missing',
          title: '404 状态页（slug 不存在时）',
          description: 'subtitleTpl 中 {slug} 占位符 → 前台自动替换为用户访问的不存在 slug。',
          fields: [
            {
              fieldKey: 'missing',
              type: 'object',
              label: '404 状态页',
              span: 'full',
              fields: [
                {
                  fieldKey: 'title',
                  type: 'localizedText',
                  label: '标题',
                  placeholder: '案例不存在',
                  multiLang: true,
                  span: 'wide',
                },
                {
                  fieldKey: 'subtitleTpl',
                  type: 'localizedText',
                  label: '副文案模板（含 {slug}）',
                  placeholder: '我们没有找到 slug={slug} 的案例。',
                  multiLang: true,
                  multiline: true,
                  span: 'full',
                },
                {
                  fieldKey: 'backLabel',
                  type: 'localizedText',
                  label: '返回按钮文字',
                  placeholder: '返回案例列表',
                  multiLang: true,
                  span: 'wide',
                },
              ],
            },
          ],
        },
      ],
    },
  ],
};
