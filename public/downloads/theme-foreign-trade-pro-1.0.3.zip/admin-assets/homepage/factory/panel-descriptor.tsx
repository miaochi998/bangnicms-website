import type { PanelDescriptor } from '../../_types';
import { FactoryPanelClient } from './FactoryPanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'homepage/factory',
  configKey: 'factory',
  title: '首页 · 我们的工厂',
  description: '配置首页「我们的工厂」区块：主视觉图/视频、浮动数据徽章、头部文案、数据统计列表以及缩略图墙。',
  dataPage: 'theme-config-fttp-factory',
  notApplicableTestId: 'factory-not-applicable',
  guardMode: 'theme-key',
  PanelClient: FactoryPanelClient,
};
