'use client';

/**
 * InquiryFormPanelClient · 阶段 2 节点 B · B-D5
 * 薄壳 client wrapper；page.tsx 是 Server Component。
 */

import { PanelRenderer } from '@/components/panel-renderer';
import { createFttpStorageAdapter } from '@bangnicms-theme/foreign-trade-pro/admin-assets/_storage-adapter';
import { INQUIRY_FORM_PANEL } from './schema';

interface LangOption {
  code: string;
  name: string;
}

export function InquiryFormPanelClient({
  apiBase,
  extensionId,
  themeKey,
  themeName,
  initialData,
  languages,
  defaultLang,
  aiAvailable,
}: {
  apiBase: string;
  extensionId: string;
  themeKey: string;
  themeName: string;
  initialData: Record<string, unknown> | undefined;
  languages: LangOption[];
  defaultLang: string;
  aiAvailable: boolean;
}) {
  return (
    <PanelRenderer
      apiBase={apiBase}
      extensionId={extensionId}
      themeKey={themeKey}
      themeName={themeName}
      panel={INQUIRY_FORM_PANEL}
      initialData={initialData}
      languages={languages}
      defaultLang={defaultLang}
      aiAvailable={aiAvailable}
      dataAdapter={createFttpStorageAdapter(INQUIRY_FORM_PANEL.panelKey, { defaultLang })}
    />
  );
}
