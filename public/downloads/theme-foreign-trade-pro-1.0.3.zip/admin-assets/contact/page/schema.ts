/**
 * fttp 联系我们页 PanelSchemaV1 schema（阶段 2 节点 C · C-D1）
 * -----------------------------------------------------------------------------
 * 接管自原 ContactPageConfigForm.tsx（1570 行手写）。
 *
 * Storage 形态（config.contactPage）：
 *   {
 *     enabled,
 *     header:        { breadcrumbLabel, eyebrow, title, description } LT × 4
 *     departments:   { eyebrow, title } LT × 2 + items[]:
 *                      { id, icon:{kind,name,size,color}, accent:bool,
 *                        badge:LT, title:LT, description:LT,
 *                        email:str, phone:str, hours:LT }
 *     formCard:      { eyebrow, title, description, submitLabel,
 *                      encryptedHint, privacyText, privacyLinkLabel } LT × 7
 *                    + privacyLinkHref:str
 *     map:           { imageUrl:str(URL), regionLabel, cityLabel, statusText, pinLabel } LT × 4
 *     sidebar:       { title:LT, drivingDirectionsLabel:LT, drivingDirectionsHref:str }
 *                    + items[]: { id, icon:enum, value:LT, bold:bool }
 *     trustCells:    items[]: { id, icon:{kind,name,size,color}, title:LT, sub:LT }
 *     faq:           { eyebrow, title, description } LT × 3
 *                    + sideBox: { title:LT, description:LT, ctaLabel:LT, ctaHref:str }
 *                    + items[]: { id, question:LT, answer:LT }
 *     style:         { hero:{ background, title:{color}, description:{color} },
 *                      departments:{ background, cardAccentColor },
 *                      formCard:{ background },
 *                      faq:{ background } }
 *   }
 *
 * 启动指令档（§1.1 #1）预期 helper 复用：
 *   - **createNullableObjectField 首场实战** · 实测不匹配：contact 形态
 *     无 nullable section（仅 top-level enabled 总开关），承同节点 B
 *     inquiry-form 同款发现登记 · helper 首场转移到 inquiry-cart（C-D4）
 *   - **createCtaLinkObjectField** · 实测不匹配：contact 单语 href 字段
 *     全是裸 string（privacyLinkHref / drivingDirectionsHref / sideBox.ctaHref），
 *     不含 9 类 type 选择 · 不复用 helper · 完工汇报登记
 *
 * adapter 行为（fttp.contact-page · postprocessContactPageWrite）：
 *   - 4 ListField items[] 补 id 兜底（沿用 site-footer ensureItemId pattern）
 *   - 顶层浅 merge 不损 prev 字段（与 site-header / site-footer / news-list 同形）
 *   - 字段级 icon read/write 走 default 分支（read 抽 .name / write 包 {...prev, kind, name}）
 *   - storage 与 schema 1:1 对齐，不需要 preprocessRead
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

const ITEM_ID_FIELD = {
  fieldKey: 'id',
  type: 'text',
  label: 'ID（系统生成 · 请勿修改）',
  placeholder: '保存时自动补齐',
  span: 'narrow',
} as const;

const SIDEBAR_ICON_OPTIONS = [
  { value: 'MapPin', label: 'MapPin（地址）' },
  { value: 'Phone', label: 'Phone（电话）' },
  { value: 'Mail', label: 'Mail（邮件）' },
  { value: 'MessageCircle', label: 'MessageCircle（即时消息）' },
];

export const CONTACT_PAGE_PANEL: PanelSchemaV1 = {
  panelKey: 'fttp.contact-page',
  version: 1,
  title: '联系我们页 · 配置',
  configPath: 'config.contactPage',
  tabs: [
    {
      tabKey: 'hero',
      title: 'Hero 页头',
      sections: [
        {
          sectionKey: 'master',
          title: '总开关',
          fields: [
            {
              fieldKey: 'enabled',
              type: 'switch',
              label: '启用联系我们页',
              description: '关闭后前台 /contact 渲染为空（独立页约定）。',
              defaultValue: true,
              controlsChildren: true,
              span: 'narrow',
            },
          ],
        },
        {
          sectionKey: 'header',
          title: 'Hero 文案（4 段多语言）',
          fields: [
            {
              fieldKey: 'header',
              type: 'object',
              label: 'Hero',
              span: 'full',
              fields: [
                { fieldKey: 'breadcrumbLabel', type: 'localizedText', label: '面包屑（当前页名）', multiLang: true, span: 'wide' },
                { fieldKey: 'eyebrow', type: 'localizedText', label: '小标题（eyebrow）', multiLang: true, span: 'wide' },
                { fieldKey: 'title', type: 'localizedText', label: '主标题', multiLang: true, span: 'wide' },
                { fieldKey: 'description', type: 'localizedText', label: '副描述', multiLang: true, multiline: true, span: 'full' },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'departments',
      title: '部门联系',
      sections: [
        {
          sectionKey: 'departments',
          title: '部门区（顶部文案 + 项列表）',
          fields: [
            {
              fieldKey: 'departments',
              type: 'object',
              label: '部门联系',
              span: 'full',
              fields: [
                { fieldKey: 'eyebrow', type: 'localizedText', label: '区小标题', multiLang: true, span: 'wide' },
                { fieldKey: 'title', type: 'localizedText', label: '区主标题', multiLang: true, span: 'wide' },
                {
                  fieldKey: 'items',
                  type: 'arrayOfObject',
                  label: '部门项（建议 4 项以匹配响应式列）',
                  description: '可任选 1 项标记「最活跃」（橙色高亮 + 徽章）。',
                  minItems: 1,
                  maxItems: 12,
                  itemTitleField: 'title',
                  addLabel: '添加部门项',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      ITEM_ID_FIELD,
                      { fieldKey: 'icon', type: 'icon', label: '图标（Lucide）', span: 'narrow' },
                      {
                        fieldKey: 'accent',
                        type: 'switch',
                        label: '高亮显示为最活跃部门（橙色背景 + 徽章）',
                        defaultValue: false,
                        span: 'wide',
                      },
                      { fieldKey: 'badge', type: 'localizedText', label: '徽章文案（仅高亮时显示）', multiLang: true, span: 'wide' },
                      { fieldKey: 'title', type: 'localizedText', label: '标题', multiLang: true, span: 'wide' },
                      { fieldKey: 'description', type: 'localizedText', label: '描述', multiLang: true, multiline: true, span: 'full' },
                      { fieldKey: 'email', type: 'text', label: '邮箱（单语）', placeholder: 'sales@bangnicms.com', span: 'medium' },
                      { fieldKey: 'phone', type: 'text', label: '电话（单语）', placeholder: '+86 400-888-8888', span: 'medium' },
                      { fieldKey: 'hours', type: 'localizedText', label: '营业时间', multiLang: true, span: 'wide' },
                    ],
                  },
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'formcard',
      title: '询盘表单',
      sections: [
        {
          sectionKey: 'formCard',
          title: '询盘表单文案（5 字段固定 · 由 InquiryForm bridge 桥接到后端）',
          description: '表单字段构成不可调；本面板只配 7 段文案 + 1 段隐私链接 URL。',
          fields: [
            {
              fieldKey: 'formCard',
              type: 'object',
              label: '表单卡片',
              span: 'full',
              fields: [
                { fieldKey: 'eyebrow', type: 'localizedText', label: '小标题（eyebrow）', multiLang: true, span: 'wide' },
                { fieldKey: 'title', type: 'localizedText', label: '主标题', multiLang: true, span: 'wide' },
                { fieldKey: 'description', type: 'localizedText', label: '描述', multiLang: true, multiline: true, span: 'full' },
                { fieldKey: 'submitLabel', type: 'localizedText', label: '提交按钮文字', multiLang: true, span: 'medium' },
                {
                  fieldKey: 'encryptedHint',
                  type: 'localizedText',
                  label: '加密提示（允许 emoji，如「🔒 已加密」）',
                  multiLang: true,
                  span: 'wide',
                },
                {
                  fieldKey: 'privacyText',
                  type: 'localizedText',
                  label: '隐私文本（必须含 {privacyLink} 占位符）',
                  multiLang: true,
                  multiline: true,
                  span: 'full',
                },
                { fieldKey: 'privacyLinkLabel', type: 'localizedText', label: '隐私政策链接文字', multiLang: true, span: 'wide' },
                {
                  fieldKey: 'privacyLinkHref',
                  type: 'text',
                  label: '隐私政策链接 URL（单语）',
                  placeholder: '/privacy',
                  span: 'wide',
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'map',
      title: '地图与侧栏',
      sections: [
        {
          sectionKey: 'map',
          title: '地图区',
          fields: [
            {
              fieldKey: 'map',
              type: 'object',
              label: '地图',
              span: 'full',
              fields: [
                {
                  fieldKey: 'imageUrl',
                  type: 'mediaPicker',
                  label: '地图图片（空时使用渐变占位）',
                  accept: ['image'],
                  span: 'wide',
                },
                { fieldKey: 'regionLabel', type: 'localizedText', label: '区域标签（如「总部」）', multiLang: true, span: 'medium' },
                { fieldKey: 'cityLabel', type: 'localizedText', label: '城市标签', multiLang: true, span: 'medium' },
                { fieldKey: 'statusText', type: 'localizedText', label: '状态文字', multiLang: true, span: 'medium' },
                { fieldKey: 'pinLabel', type: 'localizedText', label: '大头针标签', multiLang: true, span: 'medium' },
              ],
            },
          ],
        },
        {
          sectionKey: 'sidebar',
          title: '侧栏（联系信息）',
          fields: [
            {
              fieldKey: 'sidebar',
              type: 'object',
              label: '侧栏',
              span: 'full',
              fields: [
                { fieldKey: 'title', type: 'localizedText', label: '侧栏标题（如「总部 · 中国广州」）', multiLang: true, span: 'wide' },
                {
                  fieldKey: 'items',
                  type: 'arrayOfObject',
                  label: '联系方式条目',
                  minItems: 1,
                  maxItems: 12,
                  itemTitleField: 'value',
                  addLabel: '添加联系方式',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      ITEM_ID_FIELD,
                      {
                        fieldKey: 'icon',
                        type: 'select',
                        label: '图标',
                        defaultValue: 'MapPin',
                        options: SIDEBAR_ICON_OPTIONS,
                        span: 'narrow',
                      },
                      { fieldKey: 'value', type: 'localizedText', label: '文字', multiLang: true, span: 'wide' },
                      { fieldKey: 'bold', type: 'switch', label: '加粗', defaultValue: false, span: 'narrow' },
                    ],
                  },
                },
                {
                  fieldKey: 'drivingDirectionsLabel',
                  type: 'localizedText',
                  label: '路线链接文字',
                  multiLang: true,
                  span: 'wide',
                },
                {
                  fieldKey: 'drivingDirectionsHref',
                  type: 'text',
                  label: '路线链接 URL（单语）',
                  placeholder: 'https://maps.google.com/...',
                  span: 'wide',
                },
              ],
            },
          ],
        },
        {
          sectionKey: 'trustCells',
          title: '信任三宫格（建议 3 项）',
          fields: [
            {
              fieldKey: 'trustCells',
              type: 'object',
              label: '信任三宫格',
              span: 'full',
              fields: [
                {
                  fieldKey: 'items',
                  type: 'arrayOfObject',
                  label: '信任卡',
                  minItems: 1,
                  maxItems: 6,
                  itemTitleField: 'title',
                  addLabel: '添加信任卡',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      ITEM_ID_FIELD,
                      { fieldKey: 'icon', type: 'icon', label: '图标（Lucide）', span: 'narrow' },
                      { fieldKey: 'title', type: 'localizedText', label: '数值（如「2 小时」）', multiLang: true, span: 'wide' },
                      { fieldKey: 'sub', type: 'localizedText', label: '副文（如「响应时间」）', multiLang: true, span: 'wide' },
                    ],
                  },
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'faq',
      title: 'FAQ',
      sections: [
        {
          sectionKey: 'faq',
          title: 'FAQ 文案 + 侧栏盒 + 条目',
          fields: [
            {
              fieldKey: 'faq',
              type: 'object',
              label: 'FAQ',
              span: 'full',
              fields: [
                { fieldKey: 'eyebrow', type: 'localizedText', label: '区小标题', multiLang: true, span: 'wide' },
                { fieldKey: 'title', type: 'localizedText', label: '区主标题', multiLang: true, span: 'wide' },
                { fieldKey: 'description', type: 'localizedText', label: '区描述', multiLang: true, multiline: true, span: 'full' },
                {
                  fieldKey: 'sideBox',
                  type: 'object',
                  label: 'FAQ 侧栏盒（CTA）',
                  span: 'full',
                  fields: [
                    { fieldKey: 'title', type: 'localizedText', label: '标题', multiLang: true, span: 'wide' },
                    { fieldKey: 'description', type: 'localizedText', label: '描述', multiLang: true, multiline: true, span: 'full' },
                    { fieldKey: 'ctaLabel', type: 'localizedText', label: 'CTA 按钮文字', multiLang: true, span: 'wide' },
                    {
                      fieldKey: 'ctaHref',
                      type: 'text',
                      label: 'CTA 链接 URL（单语）',
                      placeholder: 'https://wa.me/...',
                      span: 'wide',
                    },
                  ],
                },
                {
                  fieldKey: 'items',
                  type: 'arrayOfObject',
                  label: 'FAQ 条目',
                  minItems: 1,
                  maxItems: 30,
                  itemTitleField: 'question',
                  addLabel: '添加 FAQ 条目',
                  span: 'full',
                  itemSchema: {
                    fields: [
                      ITEM_ID_FIELD,
                      { fieldKey: 'question', type: 'localizedText', label: '问题', multiLang: true, span: 'wide' },
                      {
                        fieldKey: 'answer',
                        type: 'localizedText',
                        label: '答案',
                        multiLang: true,
                        multiline: true,
                        span: 'full',
                      },
                    ],
                  },
                },
              ],
            },
          ],
        },
      ],
    },
    {
      tabKey: 'style',
      title: '外观样式',
      sections: [
        {
          sectionKey: 'style',
          title: '4 段背景 / 颜色覆盖（留空 = 用主题默认）',
          description: '颜色支持 hex 或 CSS token（如 var(--accent)）。',
          fields: [
            {
              fieldKey: 'style',
              type: 'object',
              label: '样式覆盖',
              span: 'full',
              fields: [
                {
                  fieldKey: 'hero',
                  type: 'object',
                  label: 'Hero 页头',
                  span: 'full',
                  fields: [
                    { fieldKey: 'background', type: 'color', label: '区块背景', span: 'narrow' },
                    {
                      fieldKey: 'title',
                      type: 'object',
                      label: '主标题',
                      span: 'narrow',
                      fields: [{ fieldKey: 'color', type: 'color', label: '主标题颜色', span: 'narrow' }],
                    },
                    {
                      fieldKey: 'description',
                      type: 'object',
                      label: '副描述',
                      span: 'narrow',
                      fields: [{ fieldKey: 'color', type: 'color', label: '副描述颜色', span: 'narrow' }],
                    },
                  ],
                },
                {
                  fieldKey: 'departments',
                  type: 'object',
                  label: '部门联系',
                  span: 'full',
                  fields: [
                    { fieldKey: 'background', type: 'color', label: '区块背景', span: 'narrow' },
                    {
                      fieldKey: 'cardAccentColor',
                      type: 'color',
                      label: '高亮卡强调色（默认主题橙色）',
                      span: 'narrow',
                    },
                  ],
                },
                {
                  fieldKey: 'formCard',
                  type: 'object',
                  label: '询盘表单',
                  span: 'full',
                  fields: [{ fieldKey: 'background', type: 'color', label: '区块背景', span: 'narrow' }],
                },
                {
                  fieldKey: 'faq',
                  type: 'object',
                  label: 'FAQ',
                  span: 'full',
                  fields: [{ fieldKey: 'background', type: 'color', label: '区块背景', span: 'narrow' }],
                },
              ],
            },
          ],
        },
      ],
    },
  ],
};
