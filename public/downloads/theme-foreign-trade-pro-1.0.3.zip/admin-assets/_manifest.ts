/**
 * 主题包 admin-assets panel 显式注册表（阶段 4 节点 A · D2）
 * -----------------------------------------------------------------------------
 * 28 个 panel-descriptor.tsx 集中静态 import 并以 panelRoute 为 key 暴露 Map，
 * 供 admin catch-all loader 单点 import 使用。
 *
 * 设计动机：
 *   webpack 5 对 dynamic import partial（含模板字符串变量段）+ ESM exports map 的
 *   组合解析存在边界问题（"Package path ./admin-assets is not exported" 报错）。
 *   显式 import map 与 partial import 在 build-time 字节码打入效果等价（裁决档 §2.1），
 *   且稳定性更高，作为节点 A α 方案的落地实现。
 *
 * 主题作者新增 panel 时需同步在此处添加 import + 表项；阶段 5 SOP 候选 #10
 * 评估自动生成 / 远程 SSR 等替代方案后可移除本文件。
 */
import type { PanelDescriptor } from './_types';

import { descriptor as aboutPage } from './about/page/panel-descriptor';
import { descriptor as caseStudyDetail } from './case-studies/detail/panel-descriptor';
import { descriptor as caseStudiesList } from './case-studies/list/panel-descriptor';
import { descriptor as contactPage } from './contact/page/panel-descriptor';
import { descriptor as cookiePage } from './cookie/page/panel-descriptor';
import { descriptor as downloadsDetailPage } from './downloads/detail/page/panel-descriptor';
import { descriptor as downloadsListPage } from './downloads/list/page/panel-descriptor';
import { descriptor as factoryPage } from './factory/page/panel-descriptor';
import { descriptor as branding } from './global/branding/panel-descriptor';
import { descriptor as inquiryForm } from './global/inquiry-form/panel-descriptor';
import { descriptor as siteFooter } from './global/site-footer/panel-descriptor';
import { descriptor as siteHeader } from './global/site-header/panel-descriptor';
import { descriptor as homepageCertifications } from './homepage/certifications/panel-descriptor';
import { descriptor as homepageClients } from './homepage/clients/panel-descriptor';
import { descriptor as homepageFactory } from './homepage/factory/panel-descriptor';
import { descriptor as homepageFeaturedProducts } from './homepage/featured-products/panel-descriptor';
import { descriptor as homepageHero } from './homepage/hero/panel-descriptor';
import { descriptor as homepageInquiryCta } from './homepage/inquiry-cta/panel-descriptor';
import { descriptor as homepageTrustStrip } from './homepage/trust-strip/panel-descriptor';
import { descriptor as homepageWhyChooseUs } from './homepage/why-choose-us/panel-descriptor';
import { descriptor as inquiryCartPage } from './inquiry-cart/page/panel-descriptor';
import { descriptor as newsDetailPage } from './news/detail/page/panel-descriptor';
import { descriptor as newsListPage } from './news/list/page/panel-descriptor';
import { descriptor as privacyPage } from './privacy/page/panel-descriptor';
import { descriptor as productDetailPage } from './product/product-detail/panel-descriptor';
import { descriptor as productListPage } from './product/product-list/panel-descriptor';
import { descriptor as qualityPage } from './quality/page/panel-descriptor';
import { descriptor as sitemapPage } from './sitemap/page/panel-descriptor';
import { descriptor as termsPage } from './terms/page/panel-descriptor';

/** 按 panelRoute 索引的描述符注册表（29 项 · 阶段 5 节点 B D-γ branding 入账） */
export const PANEL_DESCRIPTORS: Readonly<Record<string, PanelDescriptor>> = {
  'about/page': aboutPage,
  'case-studies/detail': caseStudyDetail,
  'case-studies/list': caseStudiesList,
  'contact/page': contactPage,
  'cookie/page': cookiePage,
  'downloads/detail/page': downloadsDetailPage,
  'downloads/list/page': downloadsListPage,
  'factory/page': factoryPage,
  'global/branding': branding,
  'global/inquiry-form': inquiryForm,
  'global/site-footer': siteFooter,
  'global/site-header': siteHeader,
  'homepage/certifications': homepageCertifications,
  'homepage/clients': homepageClients,
  'homepage/factory': homepageFactory,
  'homepage/featured-products': homepageFeaturedProducts,
  'homepage/hero': homepageHero,
  'homepage/inquiry-cta': homepageInquiryCta,
  'homepage/trust-strip': homepageTrustStrip,
  'homepage/why-choose-us': homepageWhyChooseUs,
  'inquiry-cart/page': inquiryCartPage,
  'news/detail/page': newsDetailPage,
  'news/list/page': newsListPage,
  'privacy/page': privacyPage,
  'product/product-detail': productDetailPage,
  'product/product-list': productListPage,
  'quality/page': qualityPage,
  'sitemap/page': sitemapPage,
  'terms/page': termsPage,
};
