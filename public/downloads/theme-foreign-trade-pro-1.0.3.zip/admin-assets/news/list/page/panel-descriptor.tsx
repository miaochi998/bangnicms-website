import { Newspaper } from 'lucide-react';
import type { PanelDescriptor } from '../../../_types';
import { iconHint } from '../../../_helpers';
import { NewsListPagePanelClient } from './NewsListPagePanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'news/list/page',
  configKey: 'newsListPage',
  title: '新闻列表页',
  description: '配置 /news 列表页：Hero（深色面包屑 + 三语标题 + 描述）+ 动态分类筛选 chip + 客户端搜索 + 排序占位 + 主网格 + 侧栏（热门标签 + 最新文章）+ 静态分页。所有文案多语言。',
  dataPage: 'theme-config-fttp-news-list-page',
  notApplicableTestId: 'news-list-page-not-applicable',
  guardMode: 'theme-key',
  PanelClient: NewsListPagePanelClient,
  hint: iconHint(
    <Newspaper className="h-4 w-4 shrink-0 mt-0.5" />,
    <>
      <p>
        <strong>提示</strong>：分类 chip 由文章实际 categories 动态聚合（按出现次数降序），无需在此配置；可改的是「全部」chip 文案。
      </p>
      <p className="mt-1">
        「显示模板」`grid.showingTemplate` 中的 `{'{total}'}` `{'{filtered}'}` 为占位符；
        <strong>请保留 `data-news-shown` 属性</strong>否则客户端实时计数失效。
      </p>
      <p className="mt-1">
        若关闭「启用」开关，前台{' '}
        <code className="px-1 py-0.5 rounded bg-muted text-foreground">/news</code> 将渲染为空。
      </p>
    </>,
  ),
};
