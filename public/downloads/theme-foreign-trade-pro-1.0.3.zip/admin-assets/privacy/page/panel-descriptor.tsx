import { Shield } from 'lucide-react';
import type { PanelDescriptor } from '../../_types';
import { iconHint } from '../../_helpers';
import { PrivacyPagePanelClient } from './PrivacyPagePanelClient';

export const descriptor: PanelDescriptor = {
  panelRoute: 'privacy/page',
  configKey: 'privacyPage',
  title: '隐私政策页',
  description: '配置 /privacy 法律页：Hero 页头 + 文件信息卡 + 异构正文 sections（段落/列表/Callout/表格）+ TOC 目录 + 底部联系 + 相关法律文件卡。所有文案多语言。',
  dataPage: 'theme-config-fttp-privacy-page',
  notApplicableTestId: 'privacy-page-not-applicable',
  guardMode: 'theme-key',
  PanelClient: PrivacyPagePanelClient,
  hint: iconHint(
    <Shield className="h-4 w-4 shrink-0 mt-0.5" />,
    <>
      <p>
        <strong>提示</strong>：正文章节由异构 blocks 数组组成，支持 5 种类型：段落（P）/ 无序列表（UL）/ 有序列表（OL）/ 提示框（Callout）/ 表格（Table）。
      </p>
      <p className="mt-1">
        段落文本支持简单内联标签{' '}
        <code className="px-1 py-0.5 rounded bg-muted text-foreground">&lt;b&gt;</code>{' '}
        <code className="px-1 py-0.5 rounded bg-muted text-foreground">&lt;a href&gt;</code>{' '}
        <code className="px-1 py-0.5 rounded bg-muted text-foreground">&lt;br/&gt;</code>。表格 cell 同样支持。
      </p>
      <p className="mt-1">
        若关闭「启用」开关，前台{' '}
        <code className="px-1 py-0.5 rounded bg-muted text-foreground">/privacy</code>{' '}
        将渲染为空（该主题所有独立页共用此约定）。
      </p>
    </>,
  ),
};
