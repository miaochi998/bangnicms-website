/**
 * 品牌调色 PanelSchemaV1 schema（阶段 5 节点 B · D-γ 迁主题包）
 * -----------------------------------------------------------------------------
 * 数据存储约定：
 *   - storage 形态：`Extension.config.{primaryColor, accentColor}`（**根级**，
 *     非子键）。前台 `themes/theme-foreign-trade-pro/src/components/ThemeCssOverride.tsx`
 *     直接读取 `themeConfig.primaryColor` / `themeConfig.accentColor` 派生
 *     CSS 变量；admin 侧用 `configPath: 'config'` 的「根合并模式」对接
 *     （PanelRenderer 与 useThemeConfigSave 自 S3 节点 A 起支持）。
 *
 *   - 主题守卫由通用 catch-all 路由按 themeKey 比对（panel-descriptor.guardMode='theme-key'）。
 *
 * 字段：
 *   - `primaryColor`（color · 默认 `#1F2937`）：深色按钮 / Footer 背景等强调位
 *   - `accentColor` （color · 默认 `#F97316`）：CTA 按钮 / 链接 hover / 标签等高亮位
 *
 * 无 i18n、无 ListField、无 master switch（branding 为视觉调色，整块禁用语义不适用）。
 */

import type { PanelSchemaV1 } from '@/components/panel-renderer/types';

export const BRANDING_PANEL: PanelSchemaV1 = {
  panelKey: 'theme-export-basic.branding',
  version: 1,
  previewAdapter: 'theme-export-basic.branding',
  title: '品牌调色',
  /**
   * 根合并模式：draft 字段（primaryColor / accentColor）按 `{...prevConfig, ...draft}`
   * 写回 `Extension.config` 顶层，与原 BrandingConfigForm 行为完全等价。
   */
  configPath: 'config',
  tabs: [
    {
      tabKey: 'colors',
      title: '配色',
      sections: [
        {
          sectionKey: 'palette',
          title: '品牌色板',
          description:
            '改色后所有页面首屏 SSR 立即派生新 CSS 变量，无需 hard refresh；颜色必须为合法 hex（如 #1F2937）。',
          fields: [
            {
              fieldKey: 'primaryColor',
              type: 'color',
              label: '主色（primary）',
              description: '深色按钮、Footer 背景等强调位',
              defaultValue: '#1F2937',
              span: 'narrow',
            },
            {
              fieldKey: 'accentColor',
              type: 'color',
              label: '强调色（accent）',
              description: 'CTA 按钮、链接 hover、标签等高亮位',
              defaultValue: '#F97316',
              span: 'narrow',
            },
          ],
        },
      ],
    },
  ],
};
